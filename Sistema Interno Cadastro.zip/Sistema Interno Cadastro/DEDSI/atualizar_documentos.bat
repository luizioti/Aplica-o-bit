@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Join-Path (Get-Location) 'documentos'; if(!(Test-Path $p)){New-Item -ItemType Directory -Force -Path $p|Out-Null}; $docs=Get-ChildItem -Path $p -File | Where-Object { $_.Extension.ToLower() -in @('.pdf','.doc','.docx','.rtf','.txt','.xlsx','.xls') } | Sort-Object Name | ForEach-Object { [pscustomobject]@{ nome=$_.Name; arquivo=$_.Name } }; $json=$docs | ConvertTo-Json -Depth 3; if([string]::IsNullOrWhiteSpace($json)){ $json='[]' }; Set-Content -Path (Join-Path $p 'documentos.js') -Value \"window.PETROS_DOCUMENTOS = $json;\" -Encoding UTF8"
echo Documentos atualizados.
pause

