﻿window.PETROS_DOCUMENTOS = [
    {
        "nome":  "Demonstrativo Estatistico - Detalhado 3.docx",
        "arquivo":  "Demonstrativo Estatistico - Detalhado 3.docx"
    },
    {
        "nome":  "REQUISITO_TECNICO_VALIDADOR_DE_DSI.docx",
        "arquivo":  "REQUISITO_TECNICO_VALIDADOR_DE_DSI.docx"
    }
];
