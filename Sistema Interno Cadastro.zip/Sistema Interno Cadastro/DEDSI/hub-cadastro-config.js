window.HUB_CADASTRO_CONFIG = {
  "apps": [
    {
      "status": "available",
      "accent": "#00806f",
      "accentSoft": "#e6f6f3",
      "icon": "document",
      "version": "1.0.0",
      "environment": "Produção",
      "lastUpdate": "12/05/2025",
      "security": "Conforme",
      "docs": [
        {
          "title": "Manual do Usuário",
          "subtitle": "Guia completo de utilização do sistema",
          "file": "Manual do Usuário.docx"
        },
        {
          "title": "Política de Acesso",
          "subtitle": "Regras e permissões de acesso",
          "file": "Política de Acesso.docx"
        },
        {
          "title": "FAQ",
          "subtitle": "Perguntas frequentes",
          "file": "FAQ.docx"
        },
        {
          "title": "Template Padrão",
          "subtitle": "Modelo oficial de carta de isenção",
          "file": "Template Padrão.docx"
        }
      ],
      "updates": [
        {
          "date": "12/05/2025",
          "type": "good",
          "label": "Melhoria",
          "text": "Ajustes na geração de PDF e desempenho"
        },
        {
          "date": "28/04/2025",
          "type": "fix",
          "label": "Correção",
          "text": "Correção de validações no template padrão"
        },
        {
          "date": "10/04/2025",
          "type": "info",
          "label": "Atualização",
          "text": "Nova versão do template de carta"
        }
      ],
      "blurName": false,
      "id": "gerador-carta-isencao",
      "name": "Gerador de Carta de Isenção",
      "description": "Geração padronizada de cartas de isenção em PDF, com templates validados e controle de versões.",
      "path": "./Gerador de Carta Isenção/index.html",
      "metaFile": "./Gerador de Carta Isenção/versao.txt",
      "docsBase": "./Gerador de Carta Isenção/Documentos/"
    },
    {
      "status": "homologation",
      "accent": "#2563eb",
      "accentSoft": "#eaf2ff",
      "icon": "project",
      "version": "0.9.0",
      "environment": "Homologação",
      "lastUpdate": "18/06/2026",
      "security": "Em validação",
      "docs": [
        {
          "title": "Guia de Acompanhamento",
          "subtitle": "Rotina de atualização dos projetos",
          "file": "Guia de Acompanhamento.docx"
        },
        {
          "title": "Modelo de Status Report",
          "subtitle": "Padrão de comunicação executiva",
          "file": "Modelo de Status Report.docx"
        },
        {
          "title": "Critérios de Priorização",
          "subtitle": "Regras para organização da carteira",
          "file": "Critérios de Priorização.docx"
        }
      ],
      "updates": [
        {
          "date": "18/06/2026",
          "type": "info",
          "label": "Homologação",
          "text": "Painel executivo em validação pelo setor"
        },
        {
          "date": "14/06/2026",
          "type": "good",
          "label": "Melhoria",
          "text": "Organização de indicadores operacionais"
        }
      ],
      "blurName": false,
      "id": "gestao-projetos",
      "name": "Gestão de Projetos",
      "description": "Acompanhamento executivo e operacional dos projetos internos do setor.",
      "path": "./Gestão de Projetos/index.html",
      "metaFile": "./Gestão de Projetos/versao.txt",
      "docsBase": "./Gestão de Projetos/Documentos/"
    },
    {
      "status": "development",
      "accent": "#7c3aed",
      "accentSoft": "#f3ecff",
      "icon": "spark",
      "version": "Planejado",
      "environment": "Desenvolvimento",
      "lastUpdate": "Planejado",
      "security": "Pendente",
      "docs": [
        {
          "title": "Escopo do Programa",
          "subtitle": "Objetivos e frentes previstas",
          "file": "Escopo do Programa.docx"
        },
        {
          "title": "Mapa de Dados",
          "subtitle": "Fontes e indicadores cadastrais",
          "file": "Mapa de Dados.docx"
        }
      ],
      "updates": [
        {
          "date": "Planejado",
          "type": "info",
          "label": "Backlog",
          "text": "Aplicação ainda em desenho funcional"
        }
      ],
      "blurName": true,
      "id": "inteligencia-cadastral",
      "name": "Programa de Inteligência Cadastral",
      "description": "Ambiente para iniciativas de inteligência, dados e qualidade cadastral.",
      "path": "",
      "metaFile": "./Programa de Inteligência Cadastral/versao.txt",
      "docsBase": "./Programa de Inteligência Cadastral/Documentos/"
    },
    {
      "status": "homologation",
      "accent": "#0891b2",
      "accentSoft": "#e6f7fb",
      "icon": "calendar",
      "version": "0.9.0",
      "environment": "Homologação",
      "lastUpdate": "17/06/2026",
      "security": "Em validação",
      "docs": [
        {
          "title": "Calendário Operacional",
          "subtitle": "Regras para organização dos períodos",
          "file": "Calendário Operacional.docx"
        },
        {
          "title": "Fluxo de Aprovação",
          "subtitle": "Etapas de validação interna",
          "file": "Fluxo de Aprovação.docx"
        }
      ],
      "updates": [
        {
          "date": "17/06/2026",
          "type": "good",
          "label": "Melhoria",
          "text": "Ajustes de visualização do calendário"
        },
        {
          "date": "13/06/2026",
          "type": "info",
          "label": "Atualização",
          "text": "Inclusão de filtros por equipe"
        }
      ],
      "blurName": false,
      "id": "planejamento-ferias",
      "name": "Planejamento de Férias",
      "description": "Organização e acompanhamento do planejamento de férias da equipe.",
      "path": "F:\\DADOS\\CADASTRO\\NÚCLEO ANALYTICS\\Sistema Interno Cadastro\\calendario-ferias\\Aplicação Férias.html",
      "metaFile": "./calendario-ferias/versao.txt",
      "docsBase": "./calendario-ferias/Documentos/"
    },
    {
      "status": "homologation",
      "accent": "#0d9488",
      "accentSoft": "#e8f8f6",
      "icon": "archive",
      "version": "0.9.0",
      "environment": "Homologação",
      "lastUpdate": "16/06/2026",
      "security": "Em validação",
      "docs": [
        {
          "title": "Procedimento Operacional",
          "subtitle": "Cadastro e baixa de documentos",
          "file": "Procedimento Operacional.docx"
        },
        {
          "title": "RPA de Tratamento",
          "subtitle": "Orientações para execução assistida",
          "file": "RPA de Tratamento.docx"
        },
        {
          "title": "Plano de Contingência",
          "subtitle": "Rotina manual em caso de indisponibilidade",
          "file": "Plano de Contingência.docx"
        }
      ],
      "updates": [
        {
          "date": "16/06/2026",
          "type": "info",
          "label": "Homologação",
          "text": "Validação do caminho local e fluxo RPA"
        },
        {
          "date": "09/06/2026",
          "type": "fix",
          "label": "Correção",
          "text": "Ajustes de registro em lote"
        }
      ],
      "blurName": false,
      "id": "gestao-documentos-fisicos",
      "name": "Gestão de Documentos Físicos",
      "description": "Controle dos registros de documentos físicos recebidos, com tratamento manual ou via RPA.",
      "path": "file:///F:/DADOS/CADASTRO/N%C3%9ACLEO%20ANALYTICS/Sistema%20Interno%20Cadastro/Gest%C3%A3o%20de%20Documentos%20F%C3%ADsicos/index.html",
      "metaFile": "./Gestão de Documentos Físicos/versao.txt",
      "docsBase": "./Gestão de Documentos Físicos/Documentos/"
    },
    {
      "status": "available",
      "accent": "#b45309",
      "accentSoft": "#fff4e6",
      "icon": "phone",
      "version": "Produção",
      "environment": "Produção",
      "lastUpdate": "25/06/2026",
      "security": "Pendente",
      "docs": [
        {
          "title": "Roteiro de Atendimento",
          "subtitle": "Script previsto para contatos",
          "file": "Roteiro de Atendimento.docx"
        },
        {
          "title": "Critérios de Elegibilidade",
          "subtitle": "Público e priorização das ações",
          "file": "Critérios de Elegibilidade.docx"
        }
      ],
      "updates": [
        {
          "date": "Planejado",
          "type": "info",
          "label": "Backlog",
          "text": "Módulo aguardando definição de fluxo"
        }
      ],
      "blurName": false,
      "id": "contato-ativo",
      "name": "Contato Ativo",
      "description": "Gestão e acompanhamento das ações de contato ativo com participantes.",
      "path": "https://fundacaopetros.sharepoint.com/:l:/s/CadastroAnalytics/JACerq9hYMgpTJd24-mzygjCAQNdMWCm8jQs5UhU1hwqIyk?nav=OWEwODVlMTMtMDc3NC00NzMwLTk4YTctZDYwYTQ3NDE4YTk4",
      "metaFile": "./Contato Ativo/versao.txt",
      "docsBase": "./Contato Ativo/Documentos/"
    },
    {
      "status": "available",
      "accent": "#00806f",
      "accentSoft": "#e6f6f3",
      "icon": "idcard",
      "version": "1.0.0",
      "environment": "Produção",
      "lastUpdate": "25/06/2026",
      "security": "",
      "docs": [],
      "updates": [
        {
          "date": "Atual",
          "type": "info",
          "label": "Novo",
          "text": "Aplicação cadastrada pelo Admin do Hub"
        }
      ],
      "blurName": false,
      "id": "app-1782395822619",
      "name": "Forms Priorização CSP",
      "description": "Formulário utilizado para realizar a priorização de CSP's da Squad Cadastro e Atendimento",
      "path": "https://forms.cloud.microsoft/r/1UTheDcTwD",
      "docsBase": ""
    },
    {
      "status": "development",
      "accent": "#00806f",
      "accentSoft": "#e6f6f3",
      "icon": "checklist",
      "version": "1.0.0",
      "environment": "Produção",
      "lastUpdate": "30/06/2026",
      "security": "",
      "docs": [],
      "updates": [
        {
          "date": "Atual",
          "type": "info",
          "label": "Novo",
          "text": "Aplicação cadastrada pelo Admin do Hub"
        }
      ],
      "blurName": false,
      "id": "app-1782846045966",
      "name": "DE e DSI",
      "description": "Descreva a finalidade da aplicação.",
      "path": "./DEDSI/index.html",
      "docsBase": ""
    }
  ],
  "agents": [
    {
      "id": "agente-planos",
      "name": "Agente de Planos",
      "subtitle": "Assistente previdenciário",
      "url": "https://teams.microsoft.com/l/app/f6405520-7907-4464-8f6e-9889e2fb7d8f?source=app-profile-card&templateInstanceId=7566dbf1-c20b-4fed-89be-a43f335d68fe&environment=Default-84c09349-8a90-4f46-b88a-2a034acb8b25&threadId=19%3A9b3eec44-42a0-4616-9a72-c7c77f8eda63_ec568c3f-ae35-4fb9-9cca-f0599babdd97%40unq.gbl.spaces",
      "icon": "bot",
      "variant": "dark"
    },
    {
      "id": "calculadora-tvp",
      "name": "Calculadora de TVP",
      "subtitle": "Envie o documento e calcule",
      "url": "https://teams.microsoft.com/l/app/?titleId=T_ef70940d-8cad-49db-42f3-20784b3ff43c",
      "icon": "calculator",
      "variant": "light"
    },
    {
      "id": "agente-1782935924441",
      "name": "Protocolo",
      "subtitle": "Localize a documentação enviada",
      "url": "https://teams.microsoft.com/l/app/?titleId=T_05677336-d4bf-838b-a474-0ec6d9177108",
      "icon": "archive",
      "variant": "dark"
    }
  ]
};
