# Gerador de Documentos

Aplicacao web local para geracao de documentos em PDF e DOCX, com previa A4 editavel e preenchimento assistido. O primeiro modelo disponivel e a Carta de Deferimento de Isencao de IR.

## Como executar

1. Abra a pasta `gerador-carta-isencao`.
2. De duplo clique em `index.html` ou abra o arquivo no Microsoft Edge/Google Chrome.
3. Preencha os campos obrigatorios no painel lateral.
4. Revise e edite a carta diretamente na previa A4, se necessario.
5. Clique em `Gerar PDF` ou `Salvar DOCX`.

Os arquivos serao baixados com o padrao:

`Carta de Deferimento de Isencao - Matricula Petros XXXXXXX.pdf`
`Carta de Deferimento de Isencao - Matricula Petros XXXXXXX.docx`

## Estrutura

```text
gerador-carta-isencao/
|-- index.html
|-- css/
|   `-- styles.css
|-- js/
|   |-- app.js
|   |-- cabecalho-petros-data.js
|   `-- selo-assinatura-data.js
|-- libs/
|   `-- html2pdf.bundle.min.js
|-- assets/
|   |-- logo-petros.png
|   |-- cabecalho-petros.png
|   |-- selo-assinatura.png
|   |-- rodape.png
|   `-- assinatura.png
`-- README.md
```

## Seguranca e privacidade

A ferramenta foi desenhada para processamento local de dados sensiveis. Ela nao usa internet, CDN, backend, banco de dados, cookies, `localStorage`, `sessionStorage` ou `IndexedDB`. Nenhum nome, matricula ou conteudo da carta e salvo automaticamente no navegador ou enviado para fora do computador.

## Cabecalho oficial

O cabecalho da carta deve ser uma imagem real no caminho:

`assets/cabecalho-petros.png`

No HTML, a imagem fica dentro da folha A4 como uma tag `<img>`, para que a previa, o PDF e o DOCX usem o mesmo cabecalho visual. Nao existe fallback textual para o cabecalho no PDF.

O arquivo `js/cabecalho-petros-data.js` contem uma copia local em `data:image` gerada a partir do mesmo PNG. Essa copia evita falhas de captura em navegadores corporativos ao abrir o app via `file://`.

Ao substituir o cabecalho oficial, atualize tambem `js/cabecalho-petros-data.js` com o novo arquivo. Em PowerShell, a partir da pasta `gerador-carta-isencao`, use:

```powershell
$b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes("assets\cabecalho-petros.png"))
'window.PETROS_HEADER_DATA_URL = "data:image/png;base64,' + $b64 + '";' | Set-Content -Encoding UTF8 "js\cabecalho-petros-data.js"
```

## Outros assets oficiais

- `logo-petros.png`: logo isolado, reservado para evolucoes futuras da interface.
- `selo-assinatura.png`: selo exibido na segunda pagina do PDF e do DOCX, na lista de assinaturas eletronicas.
- `rodape.png`: imagem de rodape oficial, caso seja utilizada futuramente.
- `assinatura.png`: assinatura em imagem, caso a assinatura textual seja substituida.

Se o selo for substituido, regenere o arquivo local `js\selo-assinatura-data.js`:

```powershell
$b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes("assets\selo-assinatura.png"))
'window.PETROS_SIGNATURE_SEAL_DATA_URL = "data:image/png;base64,' + $b64 + '";' | Set-Content -Encoding UTF8 "js\selo-assinatura-data.js"
```

## Biblioteca de PDF

A biblioteca local fica em `libs/html2pdf.bundle.min.js` e expoe a interface `html2pdf().set(...).from(...).save()`. A versao incluida gera o PDF A4 diretamente no navegador, sem rede.

Para trocar por uma versao oficial de `html2pdf.js`, baixe o bundle em ambiente controlado, valide internamente, substitua o arquivo em `libs/` e teste a geracao de PDF offline antes de distribuir.

## Exportacao DOCX

A exportacao DOCX e feita em memoria pelo proprio `js/app.js`, sem API externa e sem gravar dados no navegador. O arquivo Word inclui o cabecalho, o texto editado da carta, a assinatura textual e a segunda pagina com a lista de assinaturas eletronicas.

## Observacoes de uso

- A data da carta e calculada automaticamente na abertura do arquivo.
- A data de deferimento pode ser digitada em `dd/mm/aaaa` ou selecionada no calendario.
- A matricula aceita no maximo 7 digitos; o hifen e opcional.
- A carta deve caber em uma unica pagina A4 para exportacao em PDF. Se o texto editado ultrapassar a pagina, a geracao do PDF sera bloqueada com uma mensagem amigavel.
- O botao `Restaurar Modelo` pede confirmacao antes de apagar edicoes manuais feitas na previa.
