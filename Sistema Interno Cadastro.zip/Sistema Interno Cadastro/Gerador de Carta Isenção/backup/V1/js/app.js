(function () {
  "use strict";

  var months = [
    "JANEIRO",
    "FEVEREIRO",
    "MARÇO",
    "ABRIL",
    "MAIO",
    "JUNHO",
    "JULHO",
    "AGOSTO",
    "SETEMBRO",
    "OUTUBRO",
    "NOVEMBRO",
    "DEZEMBRO"
  ];

  var monthNamesLower = [
    "janeiro",
    "fevereiro",
    "março",
    "abril",
    "maio",
    "junho",
    "julho",
    "agosto",
    "setembro",
    "outubro",
    "novembro",
    "dezembro"
  ];

  var els = {};
  var originalTemplate = "";
  var isUpdatingProgrammatically = false;
  var manualDocumentEdited = false;

  document.addEventListener("DOMContentLoaded", init);

  function init() {
    els.letterPage = document.getElementById("letterPage");
    els.participantName = document.getElementById("participantName");
    els.matriculaPetros = document.getElementById("matriculaPetros");
    els.deferDateText = document.getElementById("deferDateText");
    els.deferDatePicker = document.getElementById("deferDatePicker");
    els.vigenciaMes = document.getElementById("vigenciaMes");
    els.vigenciaAno = document.getElementById("vigenciaAno");
    els.generatePdf = document.getElementById("generatePdf");
    els.clearFields = document.getElementById("clearFields");
    els.restoreModel = document.getElementById("restoreModel");
    els.messageBox = document.getElementById("messageBox");
    els.headerAssetWarning = document.getElementById("headerAssetWarning");
    els.editIndicator = document.getElementById("editIndicator");
    els.pageNumber = document.querySelector(".page-number");
    els.stepItems = document.querySelectorAll(".stepper li");

    fillMonthSelect();
    fillYearSelect();
    setTodayOnLetter();
    checkAssets();
    originalTemplate = els.letterPage.innerHTML;
    bindEvents();
    updateLetterFromForm();
    updateDocumentStatus();
  }

  function bindEvents() {
    ["input", "change"].forEach(function (eventName) {
      els.participantName.addEventListener(eventName, handleFormChange);
      els.vigenciaMes.addEventListener(eventName, handleFormChange);
      els.vigenciaAno.addEventListener(eventName, handleFormChange);
    });

    els.matriculaPetros.addEventListener("input", function () {
      els.matriculaPetros.value = limitMatricula(els.matriculaPetros.value);
      handleFormChange();
    });

    els.matriculaPetros.addEventListener("change", function () {
      els.matriculaPetros.value = limitMatricula(els.matriculaPetros.value);
      handleFormChange();
    });

    els.deferDateText.addEventListener("input", function () {
      els.deferDateText.value = formatDateTyping(els.deferDateText.value);
      syncPickerFromText();
      handleFormChange();
    });

    els.deferDateText.addEventListener("keydown", handleDateSeparatorKey);

    els.deferDateText.addEventListener("paste", function (event) {
      var text = getClipboardText(event);
      var date = parseFlexibleBrazilianDate(text);
      if (!date) {
        return;
      }
      event.preventDefault();
      els.deferDateText.value = date;
      syncPickerFromText();
      handleFormChange();
    });

    els.deferDateText.addEventListener("blur", function () {
      var date = parseFlexibleBrazilianDate(els.deferDateText.value);
      if (date) {
        els.deferDateText.value = date;
        syncPickerFromText();
        handleFormChange();
      }
    });

    els.deferDatePicker.addEventListener("change", function () {
      if (els.deferDatePicker.value) {
        els.deferDateText.value = isoToBrazilianDate(els.deferDatePicker.value);
      }
      handleFormChange();
    });

    els.generatePdf.addEventListener("click", generatePdf);
    els.clearFields.addEventListener("click", clearFields);
    els.restoreModel.addEventListener("click", restoreModel);

    els.letterPage.addEventListener("input", function () {
      if (isUpdatingProgrammatically) {
        return;
      }
      manualDocumentEdited = true;
      setEditIndicator(true);
      updateDocumentStatus();
      clearMessage();
    });

    els.letterPage.addEventListener("paste", handleLetterPaste);

    document.addEventListener("keydown", function (event) {
      if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
        event.preventDefault();
        if (!els.generatePdf.disabled) {
          generatePdf();
        }
      }
    });
  }

  function handleFormChange() {
    clearMessage();
    clearInvalidStates();
    updateLetterFromForm();
  }

  function fillMonthSelect() {
    months.forEach(function (month) {
      var option = document.createElement("option");
      option.value = month;
      option.textContent = month;
      els.vigenciaMes.appendChild(option);
    });
  }

  function fillYearSelect() {
    var currentYear = new Date().getFullYear();
    for (var year = currentYear - 3; year <= currentYear + 5; year += 1) {
      var option = document.createElement("option");
      option.value = String(year);
      option.textContent = String(year);
      els.vigenciaAno.appendChild(option);
    }
  }

  function setTodayOnLetter() {
    setField("data-carta", formatLongRioDate(new Date()));
  }

  function formatLongRioDate(date) {
    var day = String(date.getDate()).padStart(2, "0");
    var month = monthNamesLower[date.getMonth()];
    var year = date.getFullYear();
    return "Rio de Janeiro, " + day + " de " + month + " de " + year + ".";
  }

  function updateLetterFromForm() {
    isUpdatingProgrammatically = true;

    var name = els.participantName.value.trim();
    var matricula = els.matriculaPetros.value.trim();
    var deferDate = normalizeBrazilianDate(els.deferDateText.value.trim());
    var vigencia = getVigenciaText();

    setField("nome-participante", name ? name.toUpperCase() : "[NOME DO PARTICIPANTE]");
    setField("matricula-petros", matricula || "[MATRÍCULA PETROS]");
    setField("data-deferimento", deferDate || "[DATA DE DEFERIMENTO]");
    setField("vigencia", vigencia || "[VIGÊNCIA]");
    setTodayOnLetter();
    updateDocumentStatus();

    isUpdatingProgrammatically = false;
  }

  function setField(fieldName, value) {
    var nodes = els.letterPage.querySelectorAll('[data-field="' + fieldName + '"]');
    Array.prototype.forEach.call(nodes, function (node) {
      node.textContent = value;
    });
  }

  function handleLetterPaste(event) {
    event.preventDefault();
    insertPlainText(getClipboardText(event));
    manualDocumentEdited = true;
    setEditIndicator(true);
    updateDocumentStatus();
    clearMessage();
  }

  function getClipboardText(event) {
    var clipboard = event.clipboardData || window.clipboardData;
    return clipboard ? clipboard.getData("text/plain") : "";
  }

  function insertPlainText(text) {
    if (document.queryCommandSupported && document.queryCommandSupported("insertText")) {
      document.execCommand("insertText", false, text);
      return;
    }

    var selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) {
      return;
    }

    var range = selection.getRangeAt(0);
    range.deleteContents();
    range.insertNode(document.createTextNode(text));
    range.collapse(false);
    selection.removeAllRanges();
    selection.addRange(range);
  }

  function getVigenciaText() {
    if (!els.vigenciaMes.value || !els.vigenciaAno.value) {
      return "";
    }
    return els.vigenciaMes.value + "/" + els.vigenciaAno.value;
  }

  function limitMatricula(value) {
    var output = "";
    var digitCount = 0;
    var hasHyphen = false;
    var clean = String(value || "").replace(/[^\d-]/g, "");

    for (var i = 0; i < clean.length; i += 1) {
      var char = clean.charAt(i);
      if (/\d/.test(char)) {
        if (digitCount >= 7) {
          continue;
        }
        digitCount += 1;
        output += char;
      } else if (char === "-" && !hasHyphen && output.length > 0) {
        hasHyphen = true;
        output += char;
      }
    }

    return output;
  }

  function formatDateTyping(value) {
    var digits = value.replace(/\D/g, "").slice(0, 8);
    if (digits.length <= 2) {
      return digits;
    }
    if (digits.length <= 4) {
      return digits.slice(0, 2) + "/" + digits.slice(2);
    }
    return digits.slice(0, 2) + "/" + digits.slice(2, 4) + "/" + digits.slice(4);
  }

  function handleDateSeparatorKey(event) {
    if (!/[\/.-]/.test(event.key)) {
      return;
    }

    var parts = els.deferDateText.value.split("/");
    if (parts.length === 1 && parts[0]) {
      event.preventDefault();
      els.deferDateText.value = parts[0].padStart(2, "0") + "/";
      return;
    }

    if (parts.length === 2 && parts[1]) {
      event.preventDefault();
      els.deferDateText.value = parts[0].padStart(2, "0") + "/" + parts[1].padStart(2, "0") + "/";
    }
  }

  function parseFlexibleBrazilianDate(value) {
    var text = String(value || "").trim();
    var match = text.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2}|\d{4})$/);
    var day;
    var month;
    var year;

    if (match) {
      day = Number(match[1]);
      month = Number(match[2]);
      year = Number(match[3]);
      if (year < 100) {
        year += 2000;
      }
    } else {
      var digits = text.replace(/\D/g, "");
      if (digits.length === 6) {
        day = Number(digits.slice(0, 2));
        month = Number(digits.slice(2, 4));
        year = Number(digits.slice(4, 6)) + 2000;
      } else if (digits.length === 8) {
        day = Number(digits.slice(0, 2));
        month = Number(digits.slice(2, 4));
        year = Number(digits.slice(4, 8));
      } else {
        return "";
      }
    }

    var date = new Date(year, month - 1, day);
    if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
      return "";
    }

    return String(day).padStart(2, "0") + "/" + String(month).padStart(2, "0") + "/" + year;
  }

  function normalizeBrazilianDate(value) {
    var match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (!match) {
      return value || "";
    }
    var date = new Date(Number(match[3]), Number(match[2]) - 1, Number(match[1]));
    if (
      date.getFullYear() !== Number(match[3]) ||
      date.getMonth() !== Number(match[2]) - 1 ||
      date.getDate() !== Number(match[1])
    ) {
      return value;
    }
    return match[1] + "/" + match[2] + "/" + match[3];
  }

  function isoToBrazilianDate(value) {
    var parts = value.split("-");
    if (parts.length !== 3) {
      return "";
    }
    return parts[2] + "/" + parts[1] + "/" + parts[0];
  }

  function formatSignatureDateTime(date) {
    var day = String(date.getDate()).padStart(2, "0");
    var month = String(date.getMonth() + 1).padStart(2, "0");
    var year = date.getFullYear();
    var hour = String(date.getHours()).padStart(2, "0");
    var minute = String(date.getMinutes()).padStart(2, "0");
    return {
      date: day + "/" + month + "/" + year,
      time: hour + ":" + minute
    };
  }

  function syncPickerFromText() {
    var value = els.deferDateText.value;
    var match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (!match) {
      return;
    }
    var iso = match[3] + "-" + match[2] + "-" + match[1];
    var date = new Date(Number(match[3]), Number(match[2]) - 1, Number(match[1]));
    if (!Number.isNaN(date.getTime())) {
      els.deferDatePicker.value = iso;
    }
  }

  function validateFields() {
    clearInvalidStates();

    var errors = [];
    var dateValue = els.deferDateText.value.trim();

    if (!els.participantName.value.trim()) {
      errors.push("Informe o nome do participante.");
      markInvalid(els.participantName, "Informe o nome do participante.");
    }

    if (!els.matriculaPetros.value.trim()) {
      errors.push("Informe a matrícula Petros.");
      markInvalid(els.matriculaPetros, "Informe a matrícula Petros.");
    } else if (els.matriculaPetros.value.replace(/\D/g, "").length > 7) {
      errors.push("A matrícula Petros deve ter no máximo 7 dígitos.");
      markInvalid(els.matriculaPetros, "Use no máximo 7 dígitos.");
    }

    if (!dateValue) {
      errors.push("Informe a data de deferimento.");
      markInvalid(els.deferDateText, "Informe a data de deferimento.");
    } else if (!isValidBrazilianDate(dateValue)) {
      errors.push("Use uma data de deferimento válida no formato dd/mm/aaaa.");
      markInvalid(els.deferDateText, "Use uma data válida no formato dd/mm/aaaa.");
    }

    if (!els.vigenciaMes.value) {
      errors.push("Selecione o mês de vigência.");
      markInvalid(els.vigenciaMes, "Selecione o mês de vigência.");
    }

    if (!els.vigenciaAno.value) {
      errors.push("Selecione o ano de vigência.");
      markInvalid(els.vigenciaAno, "Selecione o ano de vigência.");
    }

    return errors;
  }

  function isValidBrazilianDate(value) {
    var match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (!match) {
      return false;
    }
    var day = Number(match[1]);
    var month = Number(match[2]);
    var year = Number(match[3]);
    var date = new Date(year, month - 1, day);
    return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
  }

  function markInvalid(element, message) {
    element.classList.add("invalid");
    element.setAttribute("aria-invalid", "true");
    var field = element.closest(".field");
    if (field) {
      field.classList.add("invalid");
    }
    var errorNode = document.querySelector('[data-error-for="' + element.id + '"]');
    if (errorNode) {
      errorNode.textContent = message || "";
      errorNode.classList.toggle("show", Boolean(message));
    }
  }

  function clearInvalidStates() {
    Array.prototype.forEach.call(document.querySelectorAll(".invalid"), function (node) {
      node.classList.remove("invalid");
    });
    Array.prototype.forEach.call(document.querySelectorAll("[aria-invalid]"), function (node) {
      node.setAttribute("aria-invalid", "false");
    });
    Array.prototype.forEach.call(document.querySelectorAll("[data-error-for]"), function (node) {
      node.textContent = "";
      node.classList.remove("show");
    });
  }

  function focusFirstInvalidField() {
    var firstInvalid = document.querySelector(".control-panel input.invalid, .control-panel select.invalid");
    if (firstInvalid && typeof firstInvalid.focus === "function") {
      firstInvalid.focus();
    }
  }

  function getValidationMessage(errors) {
    if (errors.length === 1) {
      return errors[0];
    }
    return "Complete os campos obrigatórios destacados para gerar o PDF.";
  }

  function updateDocumentStatus() {
    if (!els.editIndicator || !els.letterPage) {
      return;
    }

    var fits = letterFitsOnePage();
    if (els.pageNumber) {
      els.pageNumber.textContent = fits ? "1" : "1+";
    }

    els.editIndicator.className = "edit-indicator";

    if (!fits) {
      els.editIndicator.textContent = "Ajustar texto";
      els.editIndicator.classList.add("needs-attention");
      updateStepper(1);
      return;
    }

    if (isFormComplete()) {
      els.editIndicator.textContent = "Pronto para exportar";
      els.editIndicator.classList.add("ready");
      updateStepper(1);
      return;
    }

    if (manualDocumentEdited) {
      els.editIndicator.textContent = "Modificado";
      els.editIndicator.classList.add("changed");
      return;
    }

    els.editIndicator.textContent = "Modelo original";
    updateStepper(0);
  }

  function updateStepper(activeIndex) {
    Array.prototype.forEach.call(els.stepItems || [], function (item, index) {
      item.classList.toggle("active", index === activeIndex);
      item.classList.toggle("done", index < activeIndex);
    });
  }

  function isFormComplete() {
    return Boolean(
      els.participantName.value.trim() &&
      els.matriculaPetros.value.trim() &&
      isValidBrazilianDate(els.deferDateText.value.trim()) &&
      els.vigenciaMes.value &&
      els.vigenciaAno.value
    );
  }

  function letterFitsOnePage() {
    var page = els.letterPage;
    var content = page.querySelector(".letter-content");
    return page.scrollHeight <= page.clientHeight + 2 && content.scrollHeight <= content.clientHeight + 2;
  }

  async function generatePdf() {
    updateLetterFromForm();

    var errors = validateFields();
    if (errors.length) {
      showMessage(getValidationMessage(errors), "error");
      focusFirstInvalidField();
      return;
    }

    var element = document.querySelector(".document-page");
    var restoreHeaderImage = function () {};
    setGenerating(true);

    try {
      var headerReady = await ensureHeaderImageReady();
      if (!headerReady) {
        showMessage("Cabeçalho oficial não encontrado. Adicione o arquivo assets/cabecalho-petros.png antes de gerar o PDF.", "error");
        showHeaderAssetWarning(true);
        return;
      }

      await waitForImages(element);

      if (!letterFitsOnePage()) {
        showMessage("A carta ultrapassou uma página A4. Reduza o texto ou ajuste a edição antes de gerar o PDF.", "warning");
        return;
      }

      if (!window.html2pdf) {
        showMessage("Biblioteca local de PDF não encontrada em libs/html2pdf.bundle.min.js.", "error");
        return;
      }

      var filename = buildPdfFilename(els.matriculaPetros.value);
      restoreHeaderImage = await inlineHeaderImageForPdf();
      if (!restoreHeaderImage) {
        showMessage("Cabeçalho oficial não encontrado. Adicione o arquivo assets/cabecalho-petros.png antes de gerar o PDF.", "error");
        showHeaderAssetWarning(true);
        return;
      }

      document.body.classList.add("pdf-exporting");
      await window.html2pdf()
        .set({
        filename: filename,
        margin: 0,
        headerDataUrl: getHeaderBase64DataUrl(),
        signatureSealDataUrl: getSignatureSealBase64DataUrl(),
        signatureDateTime: formatSignatureDateTime(new Date()),
        image: { type: "jpeg", quality: 0.98 },
        html2canvas: {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          backgroundColor: "#ffffff",
          logging: false,
          scrollX: 0,
          scrollY: 0,
          windowWidth: element.scrollWidth,
          windowHeight: element.scrollHeight
        },
        jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
        pagebreak: { mode: ["avoid-all", "css", "legacy"] }
        })
        .from(element)
        .save();
      showMessage("PDF gerado com sucesso: " + filename, "success");
    } catch (error) {
      if (error && /header|cabeçalho/i.test(error.message || "")) {
        showMessage("Cabeçalho oficial não encontrado. Adicione o arquivo assets/cabecalho-petros.png antes de gerar o PDF.", "error");
        showHeaderAssetWarning(true);
      } else {
        showMessage("Não foi possível gerar o PDF. Verifique se o navegador permite downloads locais e tente novamente.", "error");
      }
    } finally {
      restoreHeaderImage();
      setGenerating(false);
      document.body.classList.remove("pdf-exporting");
    }
  }

  async function waitForImages(container) {
    var images = Array.prototype.slice.call(container.querySelectorAll("img"));
    await Promise.all(images.map(function (img) {
      if (img.complete && img.naturalWidth > 0) {
        return Promise.resolve();
      }

      return new Promise(function (resolve) {
        img.onload = resolve;
        img.onerror = function () {
          resolve();
        };
      });
    }));
  }

  function headerImageReady() {
    var image = document.querySelector(".document-header .header-image");
    return Boolean(image && image.complete && image.naturalWidth > 0 && image.naturalHeight > 0);
  }

  async function ensureHeaderImageReady() {
    if (headerImageReady()) {
      showHeaderAssetWarning(false);
      return true;
    }

    var image = document.querySelector(".document-header .header-image");
    var base64DataUrl = getHeaderBase64DataUrl();
    if (!image || !base64DataUrl) {
      return false;
    }

    image.src = base64DataUrl;
    await waitForSingleImage(image);

    showHeaderAssetWarning(false);
    return true;
  }

  function waitForSingleImage(image) {
    if (image.complete && image.naturalWidth > 0) {
      return Promise.resolve();
    }

    return new Promise(function (resolve) {
      image.onload = resolve;
      image.onerror = resolve;
      setTimeout(resolve, 1000);
    });
  }

  async function inlineHeaderImageForPdf() {
    var image = document.querySelector(".document-header .header-image");
    var base64DataUrl = getHeaderBase64DataUrl();

    if (!image) {
      return null;
    }

    var originalSrc = image.getAttribute("src");

    if (!image.complete || image.naturalWidth <= 0 || image.naturalHeight <= 0) {
      if (base64DataUrl) {
        image.src = base64DataUrl;
        await waitForSingleImage(image);
        return function () {
          image.setAttribute("src", originalSrc);
        };
      }

      return null;
    }

    if (/^data:image\//i.test(image.src)) {
      return function () {};
    }

    try {
      var canvas = document.createElement("canvas");
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;

      var context = canvas.getContext("2d");
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0);

      image.src = canvas.toDataURL("image/png");
      await waitForImages(document.querySelector(".document-page"));

      return function () {
        image.setAttribute("src", originalSrc);
      };
    } catch (error) {
      if (base64DataUrl) {
        image.src = base64DataUrl;
        await waitForImages(document.querySelector(".document-page"));
        return function () {
          image.setAttribute("src", originalSrc);
        };
      }

      if (originalSrc) {
        image.setAttribute("src", originalSrc);
      }

      return null;
    }
  }

  function getHeaderBase64DataUrl() {
    var value = window.PETROS_HEADER_DATA_URL || "";
    return /^data:image\/(?:png|jpe?g);base64,/i.test(value) ? value : "";
  }

  function getSignatureSealBase64DataUrl() {
    var value = window.PETROS_SIGNATURE_SEAL_DATA_URL || "";
    return /^data:image\/(?:png|jpe?g);base64,/i.test(value) ? value : "";
  }

  function showHeaderAssetWarning(show) {
    if (els.headerAssetWarning) {
      els.headerAssetWarning.classList.toggle("show", Boolean(show));
    }
  }

  function buildPdfFilename(matricula) {
    var cleanMatricula = sanitizeFilenamePart(matricula.trim());
    return "Carta de Deferimento de Isenção - Matricula Petros " + cleanMatricula + ".pdf";
  }

  function sanitizeFilenamePart(value) {
    return value.replace(/[<>:"/\\|?*\x00-\x1F]/g, "").replace(/\s+/g, " ").trim();
  }

  function clearFields() {
    els.participantName.value = "";
    els.matriculaPetros.value = "";
    els.deferDateText.value = "";
    els.deferDatePicker.value = "";
    els.vigenciaMes.value = "";
    els.vigenciaAno.value = "";
    clearInvalidStates();
    updateLetterFromForm();
    showMessage("Campos limpos. A carta permanece disponível para edição.", "success");
  }

  function restoreModel() {
    var confirmed = window.confirm("Restaurar o modelo oficial? As edições manuais feitas na carta serão apagadas.");
    if (!confirmed) {
      return;
    }

    isUpdatingProgrammatically = true;
    els.letterPage.innerHTML = originalTemplate;
    setTodayOnLetter();
    updateLetterFromForm();
    checkAssets();
    isUpdatingProgrammatically = false;

    manualDocumentEdited = false;
    setEditIndicator(false);
    updateDocumentStatus();
    showMessage("Modelo restaurado. Os dados preenchidos foram reaplicados aos campos variáveis.", "success");
  }

  function setEditIndicator(changed) {
    els.editIndicator.textContent = changed ? "Alterações manuais" : "Modelo original";
    els.editIndicator.classList.toggle("changed", changed);
  }

  function showMessage(text, type) {
    els.messageBox.textContent = text;
    els.messageBox.className = "message-box show " + type;
  }

  function clearMessage() {
    els.messageBox.textContent = "";
    els.messageBox.className = "message-box";
  }

  function setGenerating(isGenerating) {
    els.generatePdf.disabled = Boolean(isGenerating);
    els.generatePdf.textContent = isGenerating ? "Gerando PDF..." : "Gerar PDF";
    els.generatePdf.classList.toggle("is-loading", Boolean(isGenerating));
    updateStepper(isGenerating ? 2 : (isFormComplete() ? 1 : 0));
  }

  function checkAssets() {
    checkHeaderAsset();
    checkImageAsset(".signature-block", ".signature-image", "has-image");
    checkImageAsset(".letter-footer", ".footer-image", "has-image");
  }

  function checkHeaderAsset() {
    var image = els.letterPage.querySelector(".document-header .header-image");
    if (!image) {
      showHeaderAssetWarning(true);
      return;
    }

    var applyState = async function () {
      if (image.complete && image.naturalWidth > 0 && image.naturalHeight > 0) {
        showHeaderAssetWarning(false);
        return;
      }

      var dataUrl = getHeaderBase64DataUrl();
      if (dataUrl) {
        image.src = dataUrl;
        await waitForSingleImage(image);
        showHeaderAssetWarning(!headerImageReady());
        return;
      }

      showHeaderAssetWarning(true);
    };

    image.addEventListener("load", applyState, { once: true });
    image.addEventListener("error", function () {
      applyState();
    }, { once: true });
    applyState();
  }

  function checkImageAsset(containerSelector, imageSelector, className) {
    var container = els.letterPage.querySelector(containerSelector);
    var image = els.letterPage.querySelector(imageSelector);
    if (!container || !image) {
      return;
    }

    var applyState = function () {
      var hasRealImage = image.complete && image.naturalWidth > 1 && image.naturalHeight > 1;
      if (className === "asset-missing") {
        container.classList.toggle(className, !hasRealImage);
      } else {
        container.classList.toggle(className, hasRealImage);
      }
    };

    image.addEventListener("load", applyState, { once: true });
    image.addEventListener("error", function () {
      if (className === "asset-missing") {
        container.classList.add(className);
      } else {
        container.classList.remove(className);
      }
    }, { once: true });
    applyState();
  }
})();
