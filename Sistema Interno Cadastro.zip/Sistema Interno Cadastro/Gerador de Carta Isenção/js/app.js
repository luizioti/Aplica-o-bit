(function () {
  "use strict";

  var months = [
    "JANEIRO",
    "FEVEREIRO",
    "MARÇO",
    "ABRIL",
    "MAIO",
    "JUNHO",
    "JULHO",
    "AGOSTO",
    "SETEMBRO",
    "OUTUBRO",
    "NOVEMBRO",
    "DEZEMBRO"
  ];

  var monthNamesLower = [
    "janeiro",
    "fevereiro",
    "março",
    "abril",
    "maio",
    "junho",
    "julho",
    "agosto",
    "setembro",
    "outubro",
    "novembro",
    "dezembro"
  ];

  var els = {};
  var originalTemplate = "";
  var isUpdatingProgrammatically = false;
  var manualDocumentEdited = false;

  document.addEventListener("DOMContentLoaded", init);

  function init() {
    els.letterPage = document.getElementById("letterPage");
    els.participantName = document.getElementById("participantName");
    els.matriculaPetros = document.getElementById("matriculaPetros");
    els.deferDateText = document.getElementById("deferDateText");
    els.deferDatePicker = document.getElementById("deferDatePicker");
    els.vigenciaMes = document.getElementById("vigenciaMes");
    els.vigenciaAno = document.getElementById("vigenciaAno");
    els.generatePdf = document.getElementById("generatePdf");
    els.generateDocx = document.getElementById("generateDocx");
    els.clearFields = document.getElementById("clearFields");
    els.restoreModel = document.getElementById("restoreModel");
    els.messageBox = document.getElementById("messageBox");
    els.headerAssetWarning = document.getElementById("headerAssetWarning");
    els.editIndicator = document.getElementById("editIndicator");
    els.pageNumber = document.querySelector(".page-number");
    els.stepItems = document.querySelectorAll(".stepper li");

    fillMonthSelect();
    fillYearSelect();
    setTodayOnLetter();
    checkAssets();
    originalTemplate = els.letterPage.innerHTML;
    bindEvents();
    updateLetterFromForm();
    updateDocumentStatus();
  }

  function bindEvents() {
    ["input", "change"].forEach(function (eventName) {
      els.participantName.addEventListener(eventName, handleFormChange);
      els.vigenciaMes.addEventListener(eventName, handleFormChange);
      els.vigenciaAno.addEventListener(eventName, handleFormChange);
    });

    els.matriculaPetros.addEventListener("input", function () {
      els.matriculaPetros.value = limitMatricula(els.matriculaPetros.value);
      handleFormChange();
    });

    els.matriculaPetros.addEventListener("change", function () {
      els.matriculaPetros.value = limitMatricula(els.matriculaPetros.value);
      handleFormChange();
    });

    els.deferDateText.addEventListener("input", function () {
      els.deferDateText.value = formatDateTyping(els.deferDateText.value);
      syncPickerFromText();
      handleFormChange();
    });

    els.deferDateText.addEventListener("keydown", handleDateSeparatorKey);

    els.deferDateText.addEventListener("paste", function (event) {
      var text = getClipboardText(event);
      var date = parseFlexibleBrazilianDate(text);
      if (!date) {
        return;
      }
      event.preventDefault();
      els.deferDateText.value = date;
      syncPickerFromText();
      handleFormChange();
    });

    els.deferDateText.addEventListener("blur", function () {
      var date = parseFlexibleBrazilianDate(els.deferDateText.value);
      if (date) {
        els.deferDateText.value = date;
        syncPickerFromText();
        handleFormChange();
      }
    });

    els.deferDatePicker.addEventListener("change", function () {
      if (els.deferDatePicker.value) {
        els.deferDateText.value = isoToBrazilianDate(els.deferDatePicker.value);
      }
      handleFormChange();
    });

    els.generatePdf.addEventListener("click", generatePdf);
    els.generateDocx.addEventListener("click", generateDocx);
    els.clearFields.addEventListener("click", clearFields);
    els.restoreModel.addEventListener("click", restoreModel);

    els.letterPage.addEventListener("input", function () {
      if (isUpdatingProgrammatically) {
        return;
      }
      manualDocumentEdited = true;
      setEditIndicator(true);
      updateDocumentStatus();
      clearMessage();
    });

    els.letterPage.addEventListener("paste", handleLetterPaste);

    document.addEventListener("keydown", function (event) {
      if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
        event.preventDefault();
        if (!els.generatePdf.disabled) {
          generatePdf();
        }
      }
    });
  }

  function handleFormChange() {
    clearMessage();
    clearInvalidStates();
    updateLetterFromForm();
  }

  function fillMonthSelect() {
    months.forEach(function (month) {
      var option = document.createElement("option");
      option.value = month;
      option.textContent = month;
      els.vigenciaMes.appendChild(option);
    });
  }

  function fillYearSelect() {
    var currentYear = new Date().getFullYear();
    for (var year = currentYear - 3; year <= currentYear + 5; year += 1) {
      var option = document.createElement("option");
      option.value = String(year);
      option.textContent = String(year);
      els.vigenciaAno.appendChild(option);
    }
  }

  function setTodayOnLetter() {
    setField("data-carta", formatLongRioDate(new Date()));
  }

  function formatLongRioDate(date) {
    var day = String(date.getDate()).padStart(2, "0");
    var month = monthNamesLower[date.getMonth()];
    var year = date.getFullYear();
    return "Rio de Janeiro, " + day + " de " + month + " de " + year + ".";
  }

  function updateLetterFromForm() {
    isUpdatingProgrammatically = true;

    var name = els.participantName.value.trim();
    var matricula = els.matriculaPetros.value.trim();
    var deferDate = normalizeBrazilianDate(els.deferDateText.value.trim());
    var vigencia = getVigenciaText();

    setField("nome-participante", name ? name.toUpperCase() : "[NOME DO PARTICIPANTE]");
    setField("matricula-petros", matricula || "[MATRÍCULA PETROS]");
    setField("data-deferimento", deferDate || "[DATA DE DEFERIMENTO]");
    setField("vigencia", vigencia || "[VIGÊNCIA]");
    setTodayOnLetter();
    updateDocumentStatus();

    isUpdatingProgrammatically = false;
  }

  function setField(fieldName, value) {
    var nodes = els.letterPage.querySelectorAll('[data-field="' + fieldName + '"]');
    Array.prototype.forEach.call(nodes, function (node) {
      node.textContent = value;
    });
  }

  function handleLetterPaste(event) {
    event.preventDefault();
    insertPlainText(getClipboardText(event));
    manualDocumentEdited = true;
    setEditIndicator(true);
    updateDocumentStatus();
    clearMessage();
  }

  function getClipboardText(event) {
    var clipboard = event.clipboardData || window.clipboardData;
    return clipboard ? clipboard.getData("text/plain") : "";
  }

  function insertPlainText(text) {
    if (document.queryCommandSupported && document.queryCommandSupported("insertText")) {
      document.execCommand("insertText", false, text);
      return;
    }

    var selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) {
      return;
    }

    var range = selection.getRangeAt(0);
    range.deleteContents();
    range.insertNode(document.createTextNode(text));
    range.collapse(false);
    selection.removeAllRanges();
    selection.addRange(range);
  }

  function getVigenciaText() {
    if (!els.vigenciaMes.value || !els.vigenciaAno.value) {
      return "";
    }
    return els.vigenciaMes.value + "/" + els.vigenciaAno.value;
  }

  function limitMatricula(value) {
    var output = "";
    var digitCount = 0;
    var hasHyphen = false;
    var clean = String(value || "").replace(/[^\d-]/g, "");

    for (var i = 0; i < clean.length; i += 1) {
      var char = clean.charAt(i);
      if (/\d/.test(char)) {
        if (digitCount >= 7) {
          continue;
        }
        digitCount += 1;
        output += char;
      } else if (char === "-" && !hasHyphen && output.length > 0) {
        hasHyphen = true;
        output += char;
      }
    }

    return output;
  }

  function formatDateTyping(value) {
    var digits = value.replace(/\D/g, "").slice(0, 8);
    if (digits.length <= 2) {
      return digits;
    }
    if (digits.length <= 4) {
      return digits.slice(0, 2) + "/" + digits.slice(2);
    }
    return digits.slice(0, 2) + "/" + digits.slice(2, 4) + "/" + digits.slice(4);
  }

  function handleDateSeparatorKey(event) {
    if (!/[\/.-]/.test(event.key)) {
      return;
    }

    var parts = els.deferDateText.value.split("/");
    if (parts.length === 1 && parts[0]) {
      event.preventDefault();
      els.deferDateText.value = parts[0].padStart(2, "0") + "/";
      return;
    }

    if (parts.length === 2 && parts[1]) {
      event.preventDefault();
      els.deferDateText.value = parts[0].padStart(2, "0") + "/" + parts[1].padStart(2, "0") + "/";
    }
  }

  function parseFlexibleBrazilianDate(value) {
    var text = String(value || "").trim();
    var match = text.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2}|\d{4})$/);
    var day;
    var month;
    var year;

    if (match) {
      day = Number(match[1]);
      month = Number(match[2]);
      year = Number(match[3]);
      if (year < 100) {
        year += 2000;
      }
    } else {
      var digits = text.replace(/\D/g, "");
      if (digits.length === 6) {
        day = Number(digits.slice(0, 2));
        month = Number(digits.slice(2, 4));
        year = Number(digits.slice(4, 6)) + 2000;
      } else if (digits.length === 8) {
        day = Number(digits.slice(0, 2));
        month = Number(digits.slice(2, 4));
        year = Number(digits.slice(4, 8));
      } else {
        return "";
      }
    }

    var date = new Date(year, month - 1, day);
    if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
      return "";
    }

    return String(day).padStart(2, "0") + "/" + String(month).padStart(2, "0") + "/" + year;
  }

  function normalizeBrazilianDate(value) {
    var match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (!match) {
      return value || "";
    }
    var date = new Date(Number(match[3]), Number(match[2]) - 1, Number(match[1]));
    if (
      date.getFullYear() !== Number(match[3]) ||
      date.getMonth() !== Number(match[2]) - 1 ||
      date.getDate() !== Number(match[1])
    ) {
      return value;
    }
    return match[1] + "/" + match[2] + "/" + match[3];
  }

  function isoToBrazilianDate(value) {
    var parts = value.split("-");
    if (parts.length !== 3) {
      return "";
    }
    return parts[2] + "/" + parts[1] + "/" + parts[0];
  }

  function formatSignatureDateTime(date) {
    var day = String(date.getDate()).padStart(2, "0");
    var month = String(date.getMonth() + 1).padStart(2, "0");
    var year = date.getFullYear();
    var hour = String(date.getHours()).padStart(2, "0");
    var minute = String(date.getMinutes()).padStart(2, "0");
    return {
      date: day + "/" + month + "/" + year,
      time: hour + ":" + minute
    };
  }

  function syncPickerFromText() {
    var value = els.deferDateText.value;
    var match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (!match) {
      return;
    }
    var iso = match[3] + "-" + match[2] + "-" + match[1];
    var date = new Date(Number(match[3]), Number(match[2]) - 1, Number(match[1]));
    if (!Number.isNaN(date.getTime())) {
      els.deferDatePicker.value = iso;
    }
  }

  function validateFields() {
    clearInvalidStates();

    var errors = [];
    var dateValue = els.deferDateText.value.trim();

    if (!els.participantName.value.trim()) {
      errors.push("Informe o nome do participante.");
      markInvalid(els.participantName, "Informe o nome do participante.");
    }

    if (!els.matriculaPetros.value.trim()) {
      errors.push("Informe a matrícula Petros.");
      markInvalid(els.matriculaPetros, "Informe a matrícula Petros.");
    } else if (els.matriculaPetros.value.replace(/\D/g, "").length > 7) {
      errors.push("A matrícula Petros deve ter no máximo 7 dígitos.");
      markInvalid(els.matriculaPetros, "Use no máximo 7 dígitos.");
    }

    if (!dateValue) {
      errors.push("Informe a data de deferimento.");
      markInvalid(els.deferDateText, "Informe a data de deferimento.");
    } else if (!isValidBrazilianDate(dateValue)) {
      errors.push("Use uma data de deferimento válida no formato dd/mm/aaaa.");
      markInvalid(els.deferDateText, "Use uma data válida no formato dd/mm/aaaa.");
    }

    if (!els.vigenciaMes.value) {
      errors.push("Selecione o mês de vigência.");
      markInvalid(els.vigenciaMes, "Selecione o mês de vigência.");
    }

    if (!els.vigenciaAno.value) {
      errors.push("Selecione o ano de vigência.");
      markInvalid(els.vigenciaAno, "Selecione o ano de vigência.");
    }

    return errors;
  }

  function isValidBrazilianDate(value) {
    var match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (!match) {
      return false;
    }
    var day = Number(match[1]);
    var month = Number(match[2]);
    var year = Number(match[3]);
    var date = new Date(year, month - 1, day);
    return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
  }

  function markInvalid(element, message) {
    element.classList.add("invalid");
    element.setAttribute("aria-invalid", "true");
    var field = element.closest(".field");
    if (field) {
      field.classList.add("invalid");
    }
    var errorNode = document.querySelector('[data-error-for="' + element.id + '"]');
    if (errorNode) {
      errorNode.textContent = message || "";
      errorNode.classList.toggle("show", Boolean(message));
    }
  }

  function clearInvalidStates() {
    Array.prototype.forEach.call(document.querySelectorAll(".invalid"), function (node) {
      node.classList.remove("invalid");
    });
    Array.prototype.forEach.call(document.querySelectorAll("[aria-invalid]"), function (node) {
      node.setAttribute("aria-invalid", "false");
    });
    Array.prototype.forEach.call(document.querySelectorAll("[data-error-for]"), function (node) {
      node.textContent = "";
      node.classList.remove("show");
    });
  }

  function focusFirstInvalidField() {
    var firstInvalid = document.querySelector(".control-panel input.invalid, .control-panel select.invalid");
    if (firstInvalid && typeof firstInvalid.focus === "function") {
      firstInvalid.focus();
    }
  }

  function getValidationMessage(errors) {
    if (errors.length === 1) {
      return errors[0];
    }
    return "Complete os campos obrigatórios destacados para gerar o documento.";
  }

  function updateDocumentStatus() {
    if (!els.editIndicator || !els.letterPage) {
      return;
    }

    var fits = letterFitsOnePage();
    if (els.pageNumber) {
      els.pageNumber.textContent = fits ? "1" : "1+";
    }

    els.editIndicator.className = "edit-indicator";

    if (!fits) {
      els.editIndicator.textContent = "Ajustar texto";
      els.editIndicator.classList.add("needs-attention");
      updateStepper(1);
      return;
    }

    if (isFormComplete()) {
      els.editIndicator.textContent = "Pronto para exportar";
      els.editIndicator.classList.add("ready");
      updateStepper(1);
      return;
    }

    if (manualDocumentEdited) {
      els.editIndicator.textContent = "Modificado";
      els.editIndicator.classList.add("changed");
      return;
    }

    els.editIndicator.textContent = "Modelo original";
    updateStepper(0);
  }

  function updateStepper(activeIndex) {
    Array.prototype.forEach.call(els.stepItems || [], function (item, index) {
      item.classList.toggle("active", index === activeIndex);
      item.classList.toggle("done", index < activeIndex);
    });
  }

  function isFormComplete() {
    return Boolean(
      els.participantName.value.trim() &&
      els.matriculaPetros.value.trim() &&
      isValidBrazilianDate(els.deferDateText.value.trim()) &&
      els.vigenciaMes.value &&
      els.vigenciaAno.value
    );
  }

  function letterFitsOnePage() {
    var page = els.letterPage;
    var content = page.querySelector(".letter-content");
    return page.scrollHeight <= page.clientHeight + 2 && content.scrollHeight <= content.clientHeight + 2;
  }

  async function generatePdf() {
    updateLetterFromForm();

    var errors = validateFields();
    if (errors.length) {
      showMessage(getValidationMessage(errors), "error");
      focusFirstInvalidField();
      return;
    }

    var element = document.querySelector(".document-page");
    var restoreHeaderImage = function () {};
    setGenerating(true);

    try {
      var headerReady = await ensureHeaderImageReady();
      if (!headerReady) {
        showMessage("Cabeçalho oficial não encontrado. Adicione o arquivo assets/cabecalho-petros.png antes de gerar o PDF.", "error");
        showHeaderAssetWarning(true);
        return;
      }

      await waitForImages(element);

      if (!letterFitsOnePage()) {
        showMessage("A carta ultrapassou uma página A4. Reduza o texto ou ajuste a edição antes de gerar o PDF.", "warning");
        return;
      }

      if (!window.html2pdf) {
        showMessage("Biblioteca local de PDF não encontrada em libs/html2pdf.bundle.min.js.", "error");
        return;
      }

      var filename = buildPdfFilename(els.matriculaPetros.value);
      restoreHeaderImage = await inlineHeaderImageForPdf();
      if (!restoreHeaderImage) {
        showMessage("Cabeçalho oficial não encontrado. Adicione o arquivo assets/cabecalho-petros.png antes de gerar o PDF.", "error");
        showHeaderAssetWarning(true);
        return;
      }

      document.body.classList.add("pdf-exporting");
      await window.html2pdf()
        .set({
        filename: filename,
        margin: 0,
        headerDataUrl: getHeaderBase64DataUrl(),
        signatureSealDataUrl: getSignatureSealBase64DataUrl(),
        signatureDateTime: formatSignatureDateTime(new Date()),
        image: { type: "jpeg", quality: 0.98 },
        html2canvas: {
          scale: 2,
          useCORS: true,
          allowTaint: true,
          backgroundColor: "#ffffff",
          logging: false,
          scrollX: 0,
          scrollY: 0,
          windowWidth: element.scrollWidth,
          windowHeight: element.scrollHeight
        },
        jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
        pagebreak: { mode: ["avoid-all", "css", "legacy"] }
        })
        .from(element)
        .save();
      showMessage("PDF gerado com sucesso: " + filename, "success");
    } catch (error) {
      if (error && /header|cabeçalho/i.test(error.message || "")) {
        showMessage("Cabeçalho oficial não encontrado. Adicione o arquivo assets/cabecalho-petros.png antes de gerar o PDF.", "error");
        showHeaderAssetWarning(true);
      } else {
        showMessage("Não foi possível gerar o PDF. Verifique se o navegador permite downloads locais e tente novamente.", "error");
      }
    } finally {
      restoreHeaderImage();
      setGenerating(false);
      document.body.classList.remove("pdf-exporting");
    }
  }

  async function generateDocx() {
    updateLetterFromForm();

    var errors = validateFields();
    if (errors.length) {
      showMessage(getValidationMessage(errors), "error");
      focusFirstInvalidField();
      return;
    }

    setDocxGenerating(true);

    try {
      var headerDataUrl = getHeaderBase64DataUrl();
      if (!headerDataUrl) {
        showMessage("Cabeçalho oficial não encontrado. Adicione o arquivo assets/cabecalho-petros.png antes de salvar o DOCX.", "error");
        showHeaderAssetWarning(true);
        return;
      }

      var docxBytes = buildDocxPackage({
        model: collectDocxModel(),
        headerImage: dataUrlToPackageImage(headerDataUrl, "cabecalho-petros"),
        sealImage: dataUrlToPackageImage(getSignatureSealBase64DataUrl(), "selo-assinatura"),
        signatureDateTime: formatSignatureDateTime(new Date())
      });
      var filename = buildDocxFilename(els.matriculaPetros.value);
      downloadBytes(docxBytes, filename, "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
      showMessage("DOCX gerado com sucesso: " + filename, "success");
    } catch (error) {
      showMessage("Não foi possível salvar o DOCX. Revise os dados e tente novamente.", "error");
    } finally {
      setDocxGenerating(false);
    }
  }

  function collectDocxModel() {
    var page = document.querySelector(".document-page");
    var content = page.querySelector(".letter-content");
    var signature = page.querySelector(".signature-block");
    var paragraphs = [];
    var signatureLines = [];

    Array.prototype.forEach.call(content.querySelectorAll("p"), function (node) {
      if (
        node.classList.contains("letter-date") ||
        node.classList.contains("recipient") ||
        node.classList.contains("subject") ||
        node.classList.contains("closing") ||
        node.closest(".signature-block")
      ) {
        return;
      }

      var text = cleanExportText(node.innerText || node.textContent);
      if (text) {
        paragraphs.push(text);
      }
    });

    Array.prototype.forEach.call(signature.querySelectorAll("p"), function (node) {
      var line = cleanExportText(node.innerText || node.textContent);
      if (line) {
        signatureLines.push({
          text: line,
          color: /Alessandra|Gerente de Cadastro/i.test(line) ? "777777" : "000000"
        });
      }
    });

    return {
      date: cleanExportText(textFrom(content, ".letter-date")),
      recipient: cleanExportText(textFrom(content, ".recipient")),
      subject: cleanExportText(textFrom(content, ".subject")),
      paragraphs: paragraphs,
      closing: cleanExportText(textFrom(content, ".closing")),
      signatureLines: signatureLines
    };
  }

  function buildDocxPackage(config) {
    var headerImage = config.headerImage;
    var sealImage = config.sealImage;
    var documentXml = buildDocumentXml(config.model, Boolean(sealImage), config.signatureDateTime);
    var relsXml = buildDocumentRelationshipsXml(headerImage, sealImage);
    var contentTypesXml = buildContentTypesXml(headerImage, sealImage);
    var files = [
      { name: "[Content_Types].xml", data: utf8Bytes(contentTypesXml) },
      { name: "_rels/.rels", data: utf8Bytes(buildRootRelationshipsXml()) },
      { name: "docProps/core.xml", data: utf8Bytes(buildCoreXml()) },
      { name: "docProps/app.xml", data: utf8Bytes(buildAppXml()) },
      { name: "word/document.xml", data: utf8Bytes(documentXml) },
      { name: "word/_rels/document.xml.rels", data: utf8Bytes(relsXml) },
      { name: "word/media/" + headerImage.name, data: headerImage.bytes }
    ];

    if (sealImage) {
      files.push({ name: "word/media/" + sealImage.name, data: sealImage.bytes });
    }

    return createZip(files);
  }

  function buildDocumentXml(model, hasSealImage, signatureDateTime) {
    var body = [];
    var date = signatureDateTime.date;
    var time = signatureDateTime.time;

    body.push(imageParagraph("rIdHeader", 5486400, 986000, "center", 160));
    body.push(dividerParagraph(220, 300));
    body.push(paragraph(model.date, { after: 560 }));
    body.push(paragraph(model.recipient, { after: 420 }));
    body.push(paragraph(model.subject, { bold: true, after: 320 }));

    model.paragraphs.forEach(function (text) {
      body.push(paragraph(text, { after: 260, justify: true }));
    });

    body.push(paragraph(model.closing, { after: 170 }));

    model.signatureLines.forEach(function (line) {
      body.push(paragraph(line.text, {
        italic: true,
        color: line.color,
        after: 40
      }));
    });

    body.push(pageBreakParagraph());
    body.push(paragraph("Lista de Assinaturas Eletrônicas", { bold: true, center: true, after: 80 }));
    body.push(dividerParagraph(0, 140));
    body.push(signatureListTable(hasSealImage, date, time));

    return [
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
      '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">',
      '<w:body>',
      body.join(""),
      '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="720" w:right="1440" w:bottom="720" w:left="1440" w:header="0" w:footer="0" w:gutter="0"/></w:sectPr>',
      '</w:body>',
      '</w:document>'
    ].join("");
  }

  function paragraph(text, options) {
    options = options || {};
    return paragraphRuns([{ text: text, bold: options.bold, italic: options.italic, color: options.color }], options);
  }

  function paragraphRuns(runs, options) {
    options = options || {};
    var props = ['<w:pPr>'];
    if (options.center) {
      props.push('<w:jc w:val="center"/>');
    } else if (options.justify) {
      props.push('<w:jc w:val="both"/>');
    }
    props.push('<w:spacing w:after="' + String(options.after || 0) + '"/>');
    props.push('</w:pPr>');

    return '<w:p>' + props.join("") + runs.map(function (run) {
      return runXml(run.text, run);
    }).join("") + '</w:p>';
  }

  function dividerParagraph(before, after) {
    return '<w:p><w:pPr><w:spacing w:before="' + String(before || 0) + '" w:after="' + String(after || 0) + '"/><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="222222"/></w:pBdr></w:pPr></w:p>';
  }

  function pageBreakParagraph() {
    return '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
  }

  function signatureListTable(hasSealImage, date, time) {
    var sealCell = hasSealImage ? imageParagraph("rIdSeal", 680000, 680000, "left", 0) : paragraph("", {});
    var textCell = paragraphRuns([
      { text: "Documento assinado eletronicamente por " },
      { text: "ALESSANDRA DE PAULA GOUVEA", bold: true },
      { text: " - SETOR DE CADASTRO em " + date + ", às " + time }
    ], { after: 80 });

    return [
      '<w:tbl><w:tblPr><w:tblW w:w="0" w:type="auto"/><w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/><w:insideH w:val="nil"/><w:insideV w:val="nil"/></w:tblBorders></w:tblPr>',
      '<w:tr>',
      '<w:tc><w:tcPr><w:tcW w:w="1150" w:type="dxa"/></w:tcPr>' + sealCell + '</w:tc>',
      '<w:tc><w:tcPr><w:tcW w:w="7600" w:type="dxa"/></w:tcPr>' + textCell + '</w:tc>',
      '</w:tr></w:tbl>'
    ].join("");
  }

  function imageParagraph(relId, cx, cy, align, after) {
    return [
      '<w:p><w:pPr>',
      align === "center" ? '<w:jc w:val="center"/>' : '',
      '<w:spacing w:after="' + String(after || 0) + '"/>',
      '</w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">',
      '<wp:extent cx="' + cx + '" cy="' + cy + '"/><wp:docPr id="' + (relId === "rIdHeader" ? "1" : "2") + '" name="' + relId + '"/>',
      '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">',
      '<pic:pic><pic:nvPicPr><pic:cNvPr id="0" name="' + relId + '"/><pic:cNvPicPr/></pic:nvPicPr>',
      '<pic:blipFill><a:blip r:embed="' + relId + '"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>',
      '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' + cx + '" cy="' + cy + '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>',
      '</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>'
    ].join("");
  }

  function runXml(text, options) {
    options = options || {};
    var props = [];
    if (options.bold) {
      props.push("<w:b/>");
    }
    if (options.italic) {
      props.push("<w:i/>");
    }
    if (options.color) {
      props.push('<w:color w:val="' + options.color + '"/>');
    }

    return '<w:r>' + (props.length ? '<w:rPr>' + props.join("") + '</w:rPr>' : '') + '<w:t xml:space="preserve">' + escapeXml(text) + '</w:t></w:r>';
  }

  function buildContentTypesXml(headerImage, sealImage) {
    var defaults = [
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
      '<Default Extension="xml" ContentType="application/xml"/>',
      '<Default Extension="' + headerImage.extension + '" ContentType="' + headerImage.contentType + '"/>'
    ];

    if (sealImage && sealImage.extension !== headerImage.extension) {
      defaults.push('<Default Extension="' + sealImage.extension + '" ContentType="' + sealImage.contentType + '"/>');
    }

    return [
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
      defaults.join(""),
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>',
      '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
      '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>',
      '</Types>'
    ].join("");
  }

  function buildRootRelationshipsXml() {
    return [
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">',
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>',
      '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>',
      '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>',
      '</Relationships>'
    ].join("");
  }

  function buildDocumentRelationshipsXml(headerImage, sealImage) {
    var rels = [
      '<Relationship Id="rIdHeader" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/' + headerImage.name + '"/>'
    ];

    if (sealImage) {
      rels.push('<Relationship Id="rIdSeal" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/' + sealImage.name + '"/>');
    }

    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + rels.join("") + '</Relationships>';
  }

  function buildCoreXml() {
    var now = new Date().toISOString();
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>Carta de Deferimento de Isenção</dc:title><dc:creator>Gerador de Documentos</dc:creator><cp:lastModifiedBy>Gerador de Documentos</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">' + now + '</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">' + now + '</dcterms:modified></cp:coreProperties>';
  }

  function buildAppXml() {
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Gerador de Documentos</Application></Properties>';
  }

  function createZip(files) {
    var chunks = [];
    var centralDirectory = [];
    var offset = 0;

    files.forEach(function (file) {
      var nameBytes = utf8Bytes(file.name);
      var crc = crc32(file.data);
      var localHeader = concatByteArrays([
        uint32(0x04034b50),
        uint16(20),
        uint16(0x0800),
        uint16(0),
        uint16(0),
        uint16(0),
        uint32(crc),
        uint32(file.data.length),
        uint32(file.data.length),
        uint16(nameBytes.length),
        uint16(0),
        nameBytes
      ]);
      chunks.push(localHeader, file.data);

      centralDirectory.push(concatByteArrays([
        uint32(0x02014b50),
        uint16(20),
        uint16(20),
        uint16(0x0800),
        uint16(0),
        uint16(0),
        uint16(0),
        uint32(crc),
        uint32(file.data.length),
        uint32(file.data.length),
        uint16(nameBytes.length),
        uint16(0),
        uint16(0),
        uint16(0),
        uint16(0),
        uint32(0),
        uint32(offset),
        nameBytes
      ]));

      offset += localHeader.length + file.data.length;
    });

    var centralOffset = offset;
    centralDirectory.forEach(function (entry) {
      chunks.push(entry);
      offset += entry.length;
    });

    chunks.push(concatByteArrays([
      uint32(0x06054b50),
      uint16(0),
      uint16(0),
      uint16(files.length),
      uint16(files.length),
      uint32(offset - centralOffset),
      uint32(centralOffset),
      uint16(0)
    ]));

    return concatByteArrays(chunks);
  }

  function dataUrlToPackageImage(dataUrl, baseName) {
    var match = String(dataUrl || "").match(/^data:image\/(png|jpe?g);base64,(.+)$/i);
    if (!match) {
      return null;
    }

    var type = match[1].toLowerCase();
    var extension = type === "png" ? "png" : "jpg";
    return {
      name: baseName + "." + extension,
      extension: extension,
      contentType: extension === "png" ? "image/png" : "image/jpeg",
      bytes: base64ToBytes(match[2])
    };
  }

  function crc32(bytes) {
    var table = crc32.table || (crc32.table = makeCrcTable());
    var crc = -1;
    for (var i = 0; i < bytes.length; i += 1) {
      crc = (crc >>> 8) ^ table[(crc ^ bytes[i]) & 0xff];
    }
    return (crc ^ -1) >>> 0;
  }

  function makeCrcTable() {
    var table = [];
    for (var i = 0; i < 256; i += 1) {
      var c = i;
      for (var k = 0; k < 8; k += 1) {
        c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      }
      table[i] = c >>> 0;
    }
    return table;
  }

  function utf8Bytes(value) {
    return new TextEncoder().encode(String(value));
  }

  function base64ToBytes(base64) {
    var binary = atob(base64);
    var bytes = new Uint8Array(binary.length);
    for (var i = 0; i < binary.length; i += 1) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }

  function uint16(value) {
    var bytes = new Uint8Array(2);
    bytes[0] = value & 255;
    bytes[1] = (value >>> 8) & 255;
    return bytes;
  }

  function uint32(value) {
    var bytes = new Uint8Array(4);
    bytes[0] = value & 255;
    bytes[1] = (value >>> 8) & 255;
    bytes[2] = (value >>> 16) & 255;
    bytes[3] = (value >>> 24) & 255;
    return bytes;
  }

  function concatByteArrays(arrays) {
    var length = arrays.reduce(function (sum, item) {
      return sum + item.length;
    }, 0);
    var output = new Uint8Array(length);
    var offset = 0;
    arrays.forEach(function (item) {
      output.set(item, offset);
      offset += item.length;
    });
    return output;
  }

  function downloadBytes(bytes, filename, mimeType) {
    var blob = new Blob([bytes], { type: mimeType });
    var url = URL.createObjectURL(blob);
    var link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(function () {
      URL.revokeObjectURL(url);
    }, 1000);
  }

  function buildDocxFilename(matricula) {
    return buildPdfFilename(matricula).replace(/\.pdf$/i, ".docx");
  }

  function textFrom(root, selector) {
    var node = root ? root.querySelector(selector) : null;
    return node ? node.innerText || node.textContent || "" : "";
  }

  function cleanExportText(value) {
    return String(value || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
  }

  function escapeXml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  async function waitForImages(container) {
    var images = Array.prototype.slice.call(container.querySelectorAll("img"));
    await Promise.all(images.map(function (img) {
      if (img.complete && img.naturalWidth > 0) {
        return Promise.resolve();
      }

      return new Promise(function (resolve) {
        img.onload = resolve;
        img.onerror = function () {
          resolve();
        };
      });
    }));
  }

  function headerImageReady() {
    var image = document.querySelector(".document-header .header-image");
    return Boolean(image && image.complete && image.naturalWidth > 0 && image.naturalHeight > 0);
  }

  async function ensureHeaderImageReady() {
    if (headerImageReady()) {
      showHeaderAssetWarning(false);
      return true;
    }

    var image = document.querySelector(".document-header .header-image");
    var base64DataUrl = getHeaderBase64DataUrl();
    if (!image || !base64DataUrl) {
      return false;
    }

    image.src = base64DataUrl;
    await waitForSingleImage(image);

    showHeaderAssetWarning(false);
    return true;
  }

  function waitForSingleImage(image) {
    if (image.complete && image.naturalWidth > 0) {
      return Promise.resolve();
    }

    return new Promise(function (resolve) {
      image.onload = resolve;
      image.onerror = resolve;
      setTimeout(resolve, 1000);
    });
  }

  async function inlineHeaderImageForPdf() {
    var image = document.querySelector(".document-header .header-image");
    var base64DataUrl = getHeaderBase64DataUrl();

    if (!image) {
      return null;
    }

    var originalSrc = image.getAttribute("src");

    if (!image.complete || image.naturalWidth <= 0 || image.naturalHeight <= 0) {
      if (base64DataUrl) {
        image.src = base64DataUrl;
        await waitForSingleImage(image);
        return function () {
          image.setAttribute("src", originalSrc);
        };
      }

      return null;
    }

    if (/^data:image\//i.test(image.src)) {
      return function () {};
    }

    try {
      var canvas = document.createElement("canvas");
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;

      var context = canvas.getContext("2d");
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0);

      image.src = canvas.toDataURL("image/png");
      await waitForImages(document.querySelector(".document-page"));

      return function () {
        image.setAttribute("src", originalSrc);
      };
    } catch (error) {
      if (base64DataUrl) {
        image.src = base64DataUrl;
        await waitForImages(document.querySelector(".document-page"));
        return function () {
          image.setAttribute("src", originalSrc);
        };
      }

      if (originalSrc) {
        image.setAttribute("src", originalSrc);
      }

      return null;
    }
  }

  function getHeaderBase64DataUrl() {
    var value = window.PETROS_HEADER_DATA_URL || "";
    return /^data:image\/(?:png|jpe?g);base64,/i.test(value) ? value : "";
  }

  function getSignatureSealBase64DataUrl() {
    var value = window.PETROS_SIGNATURE_SEAL_DATA_URL || "";
    return /^data:image\/(?:png|jpe?g);base64,/i.test(value) ? value : "";
  }

  function showHeaderAssetWarning(show) {
    if (els.headerAssetWarning) {
      els.headerAssetWarning.classList.toggle("show", Boolean(show));
    }
  }

  function buildPdfFilename(matricula) {
    var cleanMatricula = sanitizeFilenamePart(matricula.trim());
    return "Carta de Deferimento de Isenção - Matricula Petros " + cleanMatricula + ".pdf";
  }

  function sanitizeFilenamePart(value) {
    return value.replace(/[<>:"/\\|?*\x00-\x1F]/g, "").replace(/\s+/g, " ").trim();
  }

  function clearFields() {
    els.participantName.value = "";
    els.matriculaPetros.value = "";
    els.deferDateText.value = "";
    els.deferDatePicker.value = "";
    els.vigenciaMes.value = "";
    els.vigenciaAno.value = "";
    clearInvalidStates();
    updateLetterFromForm();
    showMessage("Campos limpos. A carta permanece disponível para edição.", "success");
  }

  function restoreModel() {
    var confirmed = window.confirm("Restaurar o modelo oficial? As edições manuais feitas na carta serão apagadas.");
    if (!confirmed) {
      return;
    }

    isUpdatingProgrammatically = true;
    els.letterPage.innerHTML = originalTemplate;
    setTodayOnLetter();
    updateLetterFromForm();
    checkAssets();
    isUpdatingProgrammatically = false;

    manualDocumentEdited = false;
    setEditIndicator(false);
    updateDocumentStatus();
    showMessage("Modelo restaurado. Os dados preenchidos foram reaplicados aos campos variáveis.", "success");
  }

  function setEditIndicator(changed) {
    els.editIndicator.textContent = changed ? "Alterações manuais" : "Modelo original";
    els.editIndicator.classList.toggle("changed", changed);
  }

  function showMessage(text, type) {
    els.messageBox.textContent = text;
    els.messageBox.className = "message-box show " + type;
  }

  function clearMessage() {
    els.messageBox.textContent = "";
    els.messageBox.className = "message-box";
  }

  function setGenerating(isGenerating) {
    els.generatePdf.disabled = Boolean(isGenerating);
    els.generatePdf.textContent = isGenerating ? "Gerando PDF..." : "Gerar PDF";
    els.generatePdf.classList.toggle("is-loading", Boolean(isGenerating));
    updateStepper(isGenerating ? 2 : (isFormComplete() ? 1 : 0));
  }

  function setDocxGenerating(isGenerating) {
    els.generateDocx.disabled = Boolean(isGenerating);
    els.generateDocx.textContent = isGenerating ? "Salvando DOCX..." : "Salvar DOCX";
    els.generateDocx.classList.toggle("is-loading", Boolean(isGenerating));
    updateStepper(isGenerating ? 2 : (isFormComplete() ? 1 : 0));
  }

  function checkAssets() {
    checkHeaderAsset();
    checkImageAsset(".signature-block", ".signature-image", "has-image");
    checkImageAsset(".letter-footer", ".footer-image", "has-image");
  }

  function checkHeaderAsset() {
    var image = els.letterPage.querySelector(".document-header .header-image");
    if (!image) {
      showHeaderAssetWarning(true);
      return;
    }

    var applyState = async function () {
      if (image.complete && image.naturalWidth > 0 && image.naturalHeight > 0) {
        showHeaderAssetWarning(false);
        return;
      }

      var dataUrl = getHeaderBase64DataUrl();
      if (dataUrl) {
        image.src = dataUrl;
        await waitForSingleImage(image);
        showHeaderAssetWarning(!headerImageReady());
        return;
      }

      showHeaderAssetWarning(true);
    };

    image.addEventListener("load", applyState, { once: true });
    image.addEventListener("error", function () {
      applyState();
    }, { once: true });
    applyState();
  }

  function checkImageAsset(containerSelector, imageSelector, className) {
    var container = els.letterPage.querySelector(containerSelector);
    var image = els.letterPage.querySelector(imageSelector);
    if (!container || !image) {
      return;
    }

    var applyState = function () {
      var hasRealImage = image.complete && image.naturalWidth > 1 && image.naturalHeight > 1;
      if (className === "asset-missing") {
        container.classList.toggle(className, !hasRealImage);
      } else {
        container.classList.toggle(className, hasRealImage);
      }
    };

    image.addEventListener("load", applyState, { once: true });
    image.addEventListener("error", function () {
      if (className === "asset-missing") {
        container.classList.add(className);
      } else {
        container.classList.remove(className);
      }
    }, { once: true });
    applyState();
  }
})();
