﻿hubAppMetadata({
  versao: '1.0.0',
  ultimaAtualizacao: '12/05/2025',
  ambiente: 'Produção',
  seguranca: 'Conforme'
});

