# Agenda de Atendimentos Petros

Mantenha estes três arquivos sempre juntos na mesma pasta compartilhada:

- `calendario_atendimentos_moderno-4.html` — aplicação (a cópia `index.html` facilita a publicação no GitHub Pages);
- `atendimentos-data.js` — fonte carregada automaticamente por todos;
- `ATENDIMENTOS.JSON` — backup estruturado da mesma publicação.

## Para consultar

Abra `calendario_atendimentos_moderno-4.html` (ou `index.html`). A agenda é carregada automaticamente, inclusive no primeiro acesso. Não é necessário selecionar o JSON.

## Para editar e publicar

Clique em **Habilitar edição** ou **Novo atendimento** e selecione a pasta acima. Essa autorização é solicitada somente de quem publica e fica memorizada pelo Edge/Chrome enquanto a permissão permanecer válida.

Cada publicação atualiza `atendimentos-data.js` e `ATENDIMENTOS.JSON`. Não renomeie nenhum dos três arquivos. Em uma pasta sincronizada pelo OneDrive, aguarde o indicador de sincronização concluir antes de desligar o computador.

## Observação para GitHub Pages

A leitura funciona normalmente quando os três arquivos são publicados no repositório. A edição local não altera o repositório remoto; para publicar no site, envie os dois arquivos de dados atualizados ao GitHub.
