window.RECADASTRAMENTO_CONFIG = {
  "version": 1,
  "updatedAt": "2026-09-24T13:02:01.739Z",
  "applications": [
    {
      "id": "formulario-recadastramento",
      "name": "Dash de Acompanhamento",
      "description": "Acesse ao Painel de acompanhamento das campanhas através do PowerBI",
      "category": "Dados",
      "path": "https://app.powerbi.com/groups/me/reports/6a509a55-8881-461c-a7d1-8dd7c63d9f1b/c6baabb60c71e9a1cb6e?ctid=84c09349-8a90-4f46-b88a-2a034acb8b25&experience=power-bi",
      "icon": "chart",
      "accent": "#087e82",
      "target": "_blank",
      "status": "Disponível"
    },
    {
      "id": "consulta-pendencias",
      "name": "Consulta ao CRM",
      "description": "Acompanhe todos os atendimentos registrados pelo CRM relacionados ao assunto Recadastramento - Campanha a partir de 10/08/2026",
      "category": "Análise",
      "path": "https://app.powerbi.com/groups/me/reports/02860578-1df8-4302-bc6a-a6ea858c2da7/54552eadb91270e2b6ae?ctid=84c09349-8a90-4f46-b88a-2a034acb8b25&experience=power-bi",
      "icon": "check",
      "accent": "#2c758c",
      "target": "_blank",
      "status": "Disponível"
    },
    {
      "id": "validacao-documental",
      "name": "Calendário de Atendimentos",
      "description": "Acompanhe os próximos atendimentos que realizaremos para o público do Recadastramento na Petros, Sindicatos ou Associações.",
      "category": "Gestão",
      "path": "F:\\DADOS\\CADASTRO\\NÚCLEO ANALYTICS\\Sistema Interno Cadastro\\HUB Recad\\Atendimento - Recadastramento\\calendario_atendimentos_moderno-4.html",
      "icon": "folder",
      "accent": "#9b7042",
      "target": "_blank",
      "status": "Disponível"
    },
    {
      "id": "nova-aplicacao-1787072821689",
      "name": "Admin do Recad",
      "description": "Acesse ao Admin do Recadastramento para acompanhar os tratamentos",
      "category": "Aplicação",
      "path": "https://files.petros.com.br/RecadAdm/dashboard/tratamento/4/460887",
      "icon": "link",
      "accent": "#087e82",
      "target": "_blank",
      "status": "Disponível"
    },
    {
      "id": "nova-aplicacao-1787073586663",
      "name": "Registro de Atividades Recadastramento - TI",
      "description": "Formulário para inclusão de bugs e/ou melhorias do Recadastramento",
      "category": "Forms",
      "path": "https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=SZPAhJCKRk-4iioDSsuLJVhc0fsc3aFOiVHmJ-vYdGtUQ1RRV0tQQkJQS0daS1A2UzUzMUhIVzBDSCQlQCN0PWcu",
      "icon": "form",
      "accent": "#087e82",
      "target": "_blank",
      "status": "Disponível"
    },
    {
      "id": "nova-aplicacao-1789068660312",
      "name": "CSP's - Manutenções e correções",
      "description": "CSP's - Manutenções e correções",
      "category": "Aplicação",
      "path": "file:///F:/DADOS/CADASTRO/N%C3%9ACLEO%20ANALYTICS/Sistema%20Interno%20Cadastro/HUB%20Recad/CSP%20-%20Recad/index.html",
      "icon": "link",
      "accent": "#087e82",
      "target": "_blank",
      "status": "Disponível"
    }
  ]
};
