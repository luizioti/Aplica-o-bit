# Gestão de Projetos Internos — versão 3.1-local

## 1. Arquivos da entrega

- `index.html`: aplicação completa e autônoma.
- `Base_Gestao_Projetos.xlsx`: base no esquema 3.0, com os dados existentes preservados.
- `RELATORIO_ALTERACOES.md`: descrição funcional e técnica da evolução.
- `test_results_v3_0.json`: regressão funcional consolidada da versão-base 3.0.
- `test_results_v3_1.json`: consolidação das validações de sintaxe, modo offline, interface e regras de acesso da versão 3.1.
- `auth_test_results.json`: testes detalhados do login, visualização de senha, autocadastro e alteração de senha da versão 3.1.
- `performance_results.json`: teste de desempenho com massa ampliada.
- imagens `login_test.png`, `register_test.png`, `password_change_test.png`, `mywork_test.png` e `portfolio_test_v31.png`: evidências visuais da homologação técnica.
- pasta `backup`: cópia dos três arquivos originais recebidos.

## 2. Como iniciar

1. Mantenha o `index.html` e o arquivo Excel em uma pasta de trabalho com permissão de leitura e gravação.
2. Abra o `index.html` diretamente em um navegador Chromium moderno, preferencialmente Microsoft Edge ou Google Chrome.
3. Clique em **Selecionar base existente**.
4. Escolha `Base_Gestao_Projetos.xlsx`.
5. Entre com um usuário já existente na base.

Na base original de testes, o primeiro acesso indicado era:

- usuário: `luiz.ioti@petros.com.br`
- senha inicial: `123456`

A aplicação preserva a regra de troca obrigatória de senha configurada na base.

## 3. Uso de uma base antiga

A versão 3.1 continua aceitando a base anterior e mantém o esquema Excel 3.0.

Ao abrir uma base no esquema 2.0, a aplicação:

1. identifica a versão anterior;
2. adiciona as novas colunas e estruturas em memória;
3. preserva os projetos, atividades, usuários, comentários, histórico e demais dados existentes;
4. registra a migração;
5. marca a base como alterada;
6. solicita que o usuário salve para persistir o esquema 3.0.

Antes de migrar uma base operacional, mantenha uma cópia do Excel original.

## 4. Experiência por perfil

### Analista

A página inicial padrão é **Meu trabalho**. O usuário visualiza as atividades atribuídas, prioridades, prazos, bloqueios e projetos relacionados.

### Gestor

A página inicial padrão é **Portfólio**. O usuário visualiza a carteira, indicadores, gráficos, entregas, concentração de atividades e projetos que exigem atenção. O gestor também acessa **Meu trabalho** quando possui atividades ou projetos atribuídos.

### Administrador

A página inicial padrão é **Governança**. O usuário visualiza integridade da base, acessos, parâmetros e inconsistências. O administrador também acessa **Meu trabalho** e **Portfólio**, inclusive quando participa operacionalmente de projetos.

### Consulta

O perfil permanece somente leitura. A interface oculta ações de alteração e a lógica valida novamente a permissão antes de qualquer gravação.

Cada usuário pode escolher uma página inicial preferida dentro das opções permitidas pelo seu perfil.

## 5. Principais recursos da versão 3.1

- interface clean e responsiva;
- menu lateral agrupado e recolhível;
- páginas iniciais diferentes por perfil;
- tela universal **Meu trabalho**;
- Portfólio executivo com filtros, indicadores, gráficos e narrativa automática;
- Governança com validações de integridade;
- atividades hierárquicas em EAP/WBS, com até quatro níveis;
- atividades do tipo Resumo, Atividade e Marco;
- cálculo ponderado de progresso;
- progresso manual e progresso externo;
- riscos, problemas e decisões por projeto;
- lista, quadro, calendário e cronograma de atividades;
- formulários de projeto e atividade em painel lateral;
- atualização rápida de status, percentual e prazo;
- relatórios e modo reunião;
- migração automática do esquema;
- validação central antes de salvar ou exportar;
- paginação das listas extensas;
- operação totalmente offline.

### Correções e autoatendimento da versão 3.1

- alinhamento dos filtros do Portfólio, sem sobreposição entre campos;
- estado selecionado visível nas opções Lista, Quadro, Calendário e nos filtros de Governança;
- ícone da marca lateral corrigido;
- botão de recolher o menu convertido em controle compacto com ícone próprio;
- ícone de olho em todos os campos de senha relevantes;
- opção **Alterar senha** na tela de login, exigindo a senha atual;
- opção **Cadastre-se** após a base ser selecionada;
- todo autocadastro é criado obrigatoriamente com perfil **Analista**, ativo e com página inicial **Meu trabalho**;
- o autocadastro não apresenta seletor de perfil e não pode conceder acesso de Gestor ou Administrador;
- alteração posterior de perfil permanece restrita ao administrador.

### Como usar o autocadastro

1. Selecione a base Excel.
2. Na tela de login, clique em **Cadastre-se**.
3. Informe nome, e-mail, setor e senha.
4. Conclua o cadastro.
5. O acesso será gravado na base como **Analista**.

Quando o navegador não permite sobrescrever diretamente o Excel, a aplicação baixa uma cópia atualizada. Essa nova cópia deverá ser adotada como base oficial para que o usuário recém-cadastrado consiga entrar.

### Como alterar a senha antes do login

1. Na tela de login, clique em **Alterar senha**.
2. Informe e-mail, senha atual, nova senha e confirmação.
3. Salve a alteração.
4. A senha será novamente armazenada por hash PBKDF2; o texto da senha não é gravado no Excel.

## 6. Hierarquia de atividades

Na tela de atividades ou dentro do projeto, utilize as ações disponíveis para:

- adicionar uma atividade filha;
- aumentar ou reduzir nível;
- mover para cima ou para baixo;
- transformar em Resumo, Atividade ou Marco;
- expandir e recolher a estrutura.

A aplicação impede:

- uma atividade ser pai de si mesma;
- mover uma atividade para dentro de uma descendente;
- ciclos hierárquicos;
- ciclos de dependência;
- mais de quatro níveis;
- vincular uma atividade-pai pertencente a outro projeto.

Atividades-resumo consolidam automaticamente datas, progresso, situação e alertas das filhas.

## 7. Salvamento

O botão **Salvar** permanece disponível no cabeçalho.

Atalhos:

- `Ctrl + S`: salvar;
- `Esc`: fechar modal ou painel lateral;
- setas esquerda e direita: navegação no modo reunião, quando aplicável.

O mesmo processo de validação é usado para:

- salvar;
- salvar como;
- baixar uma cópia;
- exportar a base.

A aplicação não interrompe a navegação interna apenas porque existem alterações pendentes. O aviso é apresentado quando há risco real de perda, como trocar de base, sair ou recarregar a página.

## 8. Testes executados nesta entrega

### Regressão automatizada no navegador

Foram executados 32 cenários com a base antiga e 32 cenários com a base nova:

- **64 de 64 cenários aprovados**;
- migração da base 2.0 para 3.0;
- abertura direta da base 3.0;
- rotas e páginas principais;
- regras dos perfis;
- telas Meu trabalho, Portfólio e Governança;
- detalhe do projeto e suas 12 seções;
- painéis de edição;
- EAP, cálculo ponderado e consolidação de datas;
- detecção de ciclos;
- validação da base;
- exportação XLSX;
- filtros do Portfólio;
- renderização móvel;
- ausência de exceções de execução no navegador.

### Correções visuais e acesso — versão 3.1

Foram validados em navegador Chromium: 

- ausência de sobreposição entre os sete campos de seleção do Portfólio;
- cor branca para texto e ícone da opção ativa sobre fundo verde;
- estado ativo nas visualizações de Meu trabalho e nos filtros de Governança;
- presença e renderização do ícone lateral;
- presença do ícone de menu no botão de recolhimento;
- alternância de senha entre `password` e `text`, com retorno ao estado protegido;
- autocadastro sem campo de perfil;
- criação obrigatória com `Perfil = Analista`, `Ativo = Sim` e `PaginaInicialPreferida = mywork`;
- alteração de senha com atualização do hash, salt e data da última troca;
- retorno à tela de login após as operações;
- ausência de erros JavaScript durante os cenários.

O resultado estruturado está em `auth_test_results.json`.

### Ciclo completo do Excel

O Excel foi:

1. aberto pela aplicação;
2. exportado novamente pelo próprio HTML;
3. validado como arquivo XLSX íntegro;
4. importado novamente para inspeção.

Resultado:

- esquema preservado: `3.0`;
- quatro projetos preservados;
- dez atividades preservadas;
- tipo MIME correto;
- pacote XLSX sem erros de compactação.

### Desempenho

Massa sintética testada:

- 100 projetos;
- 2.000 atividades.

Resultados no ambiente de teste:

- cálculo dos projetos: aproximadamente 124 ms;
- renderização do Portfólio: aproximadamente 531 ms;
- lista de atividades paginada: aproximadamente 471 ms;
- Meu trabalho paginado: aproximadamente 336 ms;
- aproximadamente 3.613 elementos no DOM após a renderização testada.

Os tempos variam conforme computador, navegador e volume real da base.

## 9. Roteiro mínimo de homologação operacional

Antes de colocar a versão em uso com a equipe:

1. abra uma cópia da base real;
2. confirme a migração e salve uma cópia;
3. valide login com Administrador, Gestor, Analista e Consulta;
4. crie e edite um projeto;
5. crie uma atividade-pai e duas filhas;
6. confirme o progresso consolidado;
7. teste uma dependência válida e uma circular;
8. teste riscos, problemas e decisões;
9. aplique filtros no Portfólio e confira indicadores e gráficos;
10. atualize uma atividade em Meu trabalho;
11. salve, feche, reabra e confirme os dados;
12. gere uma cópia e abra o Excel resultante;
13. teste impressão ou salvamento em PDF pelo navegador.

Os testes automatizados reduzem o risco técnico, mas não substituem a homologação do processo real pela equipe usuária.

## 10. Limitações técnicas conhecidas

A solução foi mantida deliberadamente como HTML local com Excel. Portanto:

- não existe autenticação corporativa por Entra ID;
- o arquivo Excel pode ser alterado diretamente por alguém com acesso à pasta;
- perfis locais reduzem erros operacionais, mas não substituem autorização de servidor;
- não existe bloqueio físico permanente para múltiplos usuários simultâneos;
- o controle de concorrência depende da possibilidade de reler o arquivo original;
- o navegador pode solicitar novamente permissão para abrir ou salvar o arquivo;
- sem File System Access API, a aplicação baixa uma nova cópia em vez de sobrescrever o original;
- recursos avançados inseridos manualmente no Excel fora do esquema da aplicação podem não ser preservados após uma nova gravação;
- o cronograma é prioritariamente visual e não implementa caminho crítico completo;
- movimentação hierárquica usa botões, e não arrastar e soltar, para reduzir alterações acidentais;
- edição das barras do Gantt por arraste não foi habilitada;
- o quadro visual limita a renderização simultânea a 500 atividades; todas continuam disponíveis na lista paginada;
- a carga de trabalho representa quantidade de atividades abertas, não horas ou esforço estimado;
- a aplicação não deve ser utilizada simultaneamente por várias pessoas sobre a mesma cópia física sem coordenação operacional.

## 11. Recomendação de operação

Para uso interno controlado:

- mantenha a base em uma pasta corporativa com controle de acesso;
- defina uma pessoa ou rotina responsável por backups;
- evite edição manual das abas estruturais do Excel;
- use uma única cópia oficial por vez;
- salve antes de trocar de base ou encerrar;
- gere cópias de segurança periodicamente;
- não compartilhe senhas iniciais após a homologação.
