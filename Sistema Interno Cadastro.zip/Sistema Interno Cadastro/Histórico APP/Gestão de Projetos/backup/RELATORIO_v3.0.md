# Relatório de alterações — Gestão de Projetos Internos 3.0-local

## 1. Objetivo da evolução

A versão 3.0 transforma o controle anterior em uma aplicação de gestão de projetos corporativos com três experiências principais:

- **Meu trabalho**, orientado à execução individual;
- **Portfólio**, orientado ao acompanhamento gerencial;
- **Governança**, orientado à administração e à integridade da base.

A arquitetura original foi preservada: um único HTML autônomo, sem servidor, sem backend, sem CDN, sem chamadas de rede e com persistência em Excel.

## 2. Arquivos preservados

Foi criada uma pasta `backup` com cópias dos arquivos originais recebidos:

- HTML original;
- Excel original;
- instruções originais.

Os dados existentes foram mantidos na nova base.

## 3. Interface e experiência

### Novo layout

- identidade visual mais limpa e corporativa;
- menu lateral agrupado em Área de trabalho e Administração;
- menu recolhível no desktop e drawer em telas menores;
- cabeçalho compacto com usuário, perfil, página inicial e estado de salvamento;
- hierarquia tipográfica e espaçamentos revisados;
- cores reservadas principalmente a status, saúde, alertas e ações;
- formulários extensos transferidos para painéis laterais;
- responsividade aprimorada para desktop, notebook, tablet e celular;
- navegação por teclado e foco visível preservados.

### Navegação

Novas rotas:

- Meu trabalho;
- Portfólio;
- Governança;
- Relatórios e reunião;
- Detalhe do projeto como rota oficial.

O detalhe do projeto preserva o projeto e a seção selecionada durante as renderizações.

## 4. Perfis e permissões

Foi separada a noção de perfil da aplicação da noção de papel no projeto.

### Administrador

- página inicial padrão: Governança;
- acesso a todas as áreas;
- também visualiza suas próprias atividades e projetos.

### Gestor

- página inicial padrão: Portfólio;
- acesso à visão gerencial e ao modo reunião;
- também visualiza suas próprias atividades e projetos.

### Analista

- página inicial padrão: Meu trabalho;
- edição limitada aos projetos relacionados, conforme as regras de permissão;
- sem acesso aos módulos administrativos.

### Consulta

- permanece em modo somente leitura;
- ações de alteração são bloqueadas tanto na interface quanto na lógica.

Foi acrescentada preferência individual de página inicial.

## 5. Meu trabalho

Nova tela disponível a todos os usuários autenticados.

Inclui:

- indicadores pessoais;
- prioridades ordenadas por atraso, bloqueio e prazo;
- atividades atribuídas;
- visualizações em lista, quadro e calendário;
- projetos liderados ou com participação;
- atualização rápida de status, percentual e prazo;
- inclusão rápida de comentário;
- paginação para volumes maiores.

Atividades-resumo são omitidas da execução pessoal por padrão, salvo quando há atribuição explícita pertinente.

## 6. Portfólio executivo

A visão executiva foi redesenhada para apoiar decisões.

### Filtros

- pesquisa;
- status;
- saúde;
- prioridade;
- fase;
- tipo;
- responsabilidade;
- líder;
- somente meus projetos;
- inclusão de encerrados.

Os filtros afetam os indicadores, gráficos, narrativa, listas e tabela.

### Indicadores

- projetos ativos;
- atrasados;
- com bloqueios;
- entregas em até 15 dias;
- sem atualização;
- avanço médio;
- situação crítica.

### Visualizações

- distribuição por situação;
- saúde do portfólio;
- progresso por projeto;
- carga de trabalho por pessoa;
- linha do tempo das próximas entregas;
- projetos que exigem atenção;
- carteira detalhada.

Os gráficos são produzidos com recursos nativos embutidos no HTML.

## 7. Governança

Nova tela administrativa com:

- usuários ativos e distribuição por perfil;
- versão da aplicação e do esquema;
- informações do último salvamento;
- situação da base;
- validações de integridade;
- acesso direto aos registros inconsistentes;
- resumo das responsabilidades pessoais do administrador.

As validações abrangem, entre outros:

- projeto sem líder;
- atividade sem responsável;
- datas incoerentes;
- atividade órfã;
- referência inexistente;
- hierarquia inválida;
- dependência circular;
- usuário inativo responsável por atividade aberta;
- projeto concluído com atividades abertas;
- divergências de percentual e status.

## 8. EAP/WBS e atividades hierárquicas

Foram adicionados aos registros de atividade:

- `AtividadePaiID`;
- `Nivel`;
- `CodigoEAP`;
- `TipoAtividade`;
- `Prioridade`.

Tipos disponíveis:

- Resumo;
- Atividade;
- Marco.

Recursos:

- até quatro níveis;
- código EAP automático;
- árvore expansível;
- adicionar filha;
- aumentar e reduzir nível;
- mover entre irmãos;
- transformar tipo;
- excluir estrutura ou promover filhas;
- validação antes da alteração definitiva.

Atividades-resumo consolidam automaticamente:

- menor início;
- maior término;
- percentual ponderado;
- status;
- bloqueios;
- atrasos.

## 9. Cálculo de progresso

O cálculo anterior, baseado apenas na proporção de atividades concluídas, foi substituído.

### Atividades

- atividades comuns usam percentual de 0 a 100;
- atividades-resumo usam média ponderada das filhas;
- atividades canceladas não entram no cálculo;
- pesos iguais são usados quando não há peso válido.

### Projetos internos

O progresso é calculado a partir da estrutura de nível superior, evitando dupla contagem entre atividades-resumo e descendentes.

### Projetos externos

O percentual global externo pode ser usado com data e fonte da informação.

### Percentual manual

Quando ativado:

- substitui a exibição principal;
- exige justificativa;
- mantém o percentual calculado disponível;
- registra usuário e data.

## 10. Novos campos de projeto

Foram adicionados:

- prioridade;
- fase;
- saúde;
- objetivo;
- benefício esperado;
- critério de sucesso;
- líder;
- patrocinador;
- próxima ação;
- próxima decisão;
- data-base do cronograma;
- data da última atualização executiva;
- tags;
- metadados de percentual externo e manual.

As fases são parametrizáveis pelo administrador.

## 11. Riscos, problemas e decisões

Foram criadas novas estruturas relacionais no Excel e novas seções no detalhe do projeto.

### Riscos

Incluem probabilidade, impacto, criticidade, resposta, responsável, prazo e status.

### Problemas

Incluem impacto, responsável, plano de ação, prazo e status.

### Decisões

Incluem decisão necessária, responsável, data limite, decisão tomada e situação.

Esses registros alimentam a visão do projeto, Portfólio, Governança e relatórios.

## 12. Visualizações das atividades

A mesma base de atividades pode ser consultada em:

- lista hierárquica;
- quadro por status;
- calendário;
- cronograma.

A lista passou a usar paginação para volumes maiores. O quadro possui limite de renderização simultânea de 500 cartões para preservar a responsividade.

## 13. Detalhe do projeto

O detalhe foi reorganizado em seções:

1. Resumo;
2. Atividades;
3. Cronograma;
4. Riscos;
5. Problemas;
6. Decisões;
7. Marcos;
8. Pessoas;
9. Comentários;
10. Narrativa;
11. Links;
12. Histórico.

O resumo reúne saúde, progresso, objetivo, benefícios, próximos marcos, riscos, decisões e equipe.

## 14. Correções funcionais

### Dependência circular

A aplicação agora testa a alteração em uma cópia temporária do grafo e só modifica os dados oficiais quando a validação é aprovada.

### Hierarquia circular

Foi aplicado o mesmo princípio às relações pai-filho.

### Salvamento

Salvar, Salvar como, Baixar cópia e exportações utilizam uma validação central comum.

### Navegação com alterações pendentes

A navegação interna deixou de exibir confirmações desnecessárias. O alerta é reservado a ações com risco real de perda.

### Rota de projeto

O detalhe do projeto passou a integrar oficialmente o mapa de rotas.

### XLSX

- correção do tipo MIME;
- leitura de XML com namespaces compatível com a base gerada;
- abertura da base antiga e da base 3.0;
- exportação e reabertura validadas.

## 15. Mudanças no esquema Excel

### Colunas adicionadas

- `Usuarios`: `PaginaInicialPreferida`.
- `Projetos`: 17 campos de gestão, liderança, progresso e atualização executiva.
- `Atividades`: cinco campos de EAP e prioridade.

### Abas adicionadas

- `FasesProjeto`;
- `Riscos`;
- `Problemas`;
- `Decisoes`.

### Versões

- aplicação: `3.0-local`;
- esquema: `3.0`.

## 16. Migração

A migração:

- detecta bases anteriores;
- acrescenta somente o que estiver ausente;
- preserva os registros existentes;
- não duplica estruturas;
- registra a atualização;
- é idempotente;
- marca a base como alterada para que o usuário possa persistir o novo esquema.

## 17. Testes executados

### Base antiga

- 32 cenários executados;
- 32 aprovados.

### Base nova

- 32 cenários executados;
- 32 aprovados.

### Total

- 64 cenários;
- 64 aprovados;
- nenhuma exceção de execução detectada;
- nenhum erro relevante de navegador detectado.

### Exportação e reimportação

O XLSX gerado pelo HTML foi validado e reimportado com:

- esquema 3.0;
- quatro projetos;
- dez atividades;
- pacote compactado íntegro;
- tipo MIME correto.

### Teste de desempenho

Com 100 projetos e 2.000 atividades:

- cálculo: 124 ms;
- Portfólio: 531 ms;
- lista de atividades: 471 ms;
- Meu trabalho: 336 ms;
- DOM: aproximadamente 3.613 elementos.

Os resultados estão disponíveis em `test_results.json` e `performance_results.json`.

## 18. Limitações e decisões técnicas

Foram priorizadas previsibilidade e segurança operacional.

Não foram implementados nesta versão:

- drag and drop da EAP;
- edição das barras do Gantt por arraste;
- caminho crítico completo;
- estimativa de capacidade em horas;
- autenticação corporativa;
- bloqueio multiusuário de servidor;
- seleção arbitrária de colunas em todas as tabelas;
- visualizações nomeadas e compartilhadas.

A movimentação de hierarquia utiliza botões para reduzir alterações acidentais.

O sistema continua sujeito às limitações inerentes ao uso de um Excel local como fonte oficial. Essas limitações estão detalhadas no arquivo de instruções.

## 19. Pontos recomendados para homologação

- nomenclatura dos campos e fases;
- regras finais de saúde do projeto;
- critérios de prioridade;
- nível de acesso do gestor aos projetos;
- pertinência de cada indicador do Portfólio;
- formulário de riscos, problemas e decisões;
- rotina de backup e definição da cópia oficial;
- uso simultâneo por mais de uma pessoa;
- impressão dos relatórios no padrão corporativo desejado.
