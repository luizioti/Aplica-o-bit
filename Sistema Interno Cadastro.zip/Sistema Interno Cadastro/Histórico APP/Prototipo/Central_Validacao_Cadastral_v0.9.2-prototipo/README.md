# Central de Consistência Cadastral Petros

Protótipo local e offline para validar arquivos cadastrais com base no **Catálogo de Campos Cadastrais v1.1**. A aplicação cobre os 17 campos oficiais do catálogo e acrescenta a **Matrícula Petros** como chave mestre de rastreabilidade.

## Como abrir

1. Abra `index.html` diretamente no Microsoft Edge ou Google Chrome.
2. Se quiser conhecer o fluxo antes de usar uma base real, clique em **Experimentar com 5 registros de demonstração**.
3. Para uma validação real, selecione um arquivo `.xlsx`, `.csv` ou `.txt` delimitado.

A aplicação foi desenhada para funcionar por `file://`, sem servidor, instalação ou conexão com a internet.

## Fluxo de trabalho

1. **Arquivo:** importe a base, escolha a aba e confirme a linha de cabeçalho.
2. **Mapeamento:** associe a Matrícula Petros e os demais campos às colunas do arquivo. Os aliases do catálogo alimentam a sugestão automática.
3. **Regras:** selecione testes impeditivos e alertas de revisão. Cada campo possui comandos próprios para marcar ou desmarcar todas as suas regras; regras condicionais exibem suas dependências.
4. **Resultados:** acompanhe consistência por registro, campo e regra, com filtros, detalhamento rastreável e paginação de 20 ou 100 registros — ou exibição integral quando necessário.
5. **Relatório e Excel:** salve o relatório A4 em PDF e gere arquivos para saneamento em lote.

## Regras disponíveis

O protótipo oferece 59 regras locais, incluindo:

- completude e unicidade da Matrícula Petros;
- CPF com 11 dígitos, sequência repetida, módulo 11 e duplicidade;
- caracteres, comprimento, espaços e títulos no nome;
- data de nascimento válida e padronizada em DD/MM/AAAA, futuro, idade plausível e consistência entre datas;
- domínios M/F, S/N, estado civil e UF;
- formato ISO alpha-3 de nacionalidade;
- código IBGE de 7 dígitos e coerência com a UF;
- formato e preservação do NIF;
- condições entre invalidez e data da invalidez;
- coerência entre aposentadoria e espécie do benefício;
- TVP inteiro, não negativo e limite operacional.

Os controles que dependem de RFB, IBGE, INSS, tabela CID, documento, protocolo, base legal, vigência ou outra fonte externa aparecem no dicionário e na interface como limites explícitos. Eles não são simulados como aprovados.

## Excel de tratamento

O arquivo completo contém cinco abas:

- **Tratamento:** todas as linhas originais sem deslocamentos; após cada campo testado são inseridas colunas coloridas de validação, achados e sugestão específicas daquele campo, além do resultado geral e das colunas de acompanhamento;
- **Inconsistências:** uma linha por achado, preservando regra, severidade, valor original e sugestão;
- **Resumo:** indicadores e metadados do processamento;
- **Configuração:** coluna, campo, regra, severidade, peso e dependências aplicadas;
- **Dicionário:** metadados do catálogo e controles que exigem fonte externa.

Também é possível exportar somente os registros com achados ou baixar um modelo de próxima carga.

## Relatório PDF

O relatório possui capa executiva, visão consolidada e amostra dos achados prioritários. O botão **Salvar relatório em PDF** abre a impressão do navegador já formatada em A4, com cores preservadas e sem controles da interface. Selecione **Salvar como PDF** e orientação retrato; as margens são controladas pelo próprio relatório.

## Privacidade e segurança

- Nenhum dado é enviado para a internet.
- Não há `fetch`, API, CDN, telemetria ou integração remota.
- Somente a seleção de regras pode ser lembrada no `localStorage`; bases e resultados não são persistidos.
- Os arquivos exportados são gerados no próprio navegador.
- Os dados são de uso interno e devem permanecer nos diretórios autorizados.

## Limitações conhecidas do protótipo

- Arquivos `.xls` legados devem ser salvos como `.xlsx` ou `.csv`.
- Identificadores numéricos podem perder zeros à esquerda antes da leitura se a célula tiver sido gravada como número no Excel; use formato Texto.
- Fórmulas são lidas pelo valor armazenado no arquivo. Recalcule e salve a planilha antes da importação.
- A capacidade máxima depende da memória disponível no navegador. O núcleo foi testado com 100 mil registros.
- A tabela na tela usa paginação; as exportações sempre consultam o universo completo.
- A geração do PDF utiliza o mecanismo de impressão do navegador para preservar o layout visual sem dependências externas.

## Estrutura para evolução

- `src/catalog.js`: campos, metadados e regras configuráveis;
- `src/rules.js`: executores reutilizáveis de validação;
- `src/engine.js`: processamento, estatísticas e rastreabilidade;
- `src/io.js` e `src/xlsx.js`: entrada CSV/XLSX e escrita de Excel;
- `src/reports.js` e `src/exports.js`: saídas gerenciais e operacionais;
- `src/app.js`: estado e interação da interface;
- `styles/app.css`: identidade visual, responsividade e impressão.

Para adicionar um campo, cadastre seus metadados e regras em `src/catalog.js`. Se a regra usar um tipo novo, implemente o executor correspondente em `src/rules.js` e acrescente testes.

## Testes

Execute a partir desta pasta:

```text
node tests/run-tests.cjs
node tests/xlsx-roundtrip.cjs
node tests/static-checks.cjs
node tests/large-volume.cjs
```

A suíte cobre regras unitárias, cruzamentos, integração do processamento, CSV com campos complexos, escrita/releitura XLSX, estrutura offline e 100 mil registros. A versão também foi revisada visualmente no navegador em desktop e viewport móvel.

## Versão

`0.9.2-prototipo`
