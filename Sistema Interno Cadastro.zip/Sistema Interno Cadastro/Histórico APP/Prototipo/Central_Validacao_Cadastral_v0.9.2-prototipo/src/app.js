(function () {
  "use strict";

  const U = window.CVCUtils;
  const Config = window.CVCConfig;
  const Catalog = window.CVCCatalog;
  const Engine = window.CVCEngine;
  const IO = window.CVCIO;
  const Charts = window.CVCCharts;
  const Exports = window.CVCExports;
  const Reports = window.CVCReports;
  if (!U || !Config || !Catalog || !Engine || !IO || !Charts || !Exports || !Reports) {
    document.body.innerHTML = '<div class="noscript">Não foi possível carregar os componentes locais da aplicação.</div>';
    return;
  }

  const $ = (selector, scope) => (scope || document).querySelector(selector);
  const $$ = (selector, scope) => [...(scope || document).querySelectorAll(selector)];
  const titleByView = { upload: "Preparar validação", mapping: "Mapear campos", rules: "Configurar regras", results: "Analisar resultados", exports: "Relatório e tratamento" };
  const state = {
    file: null, fileType: "", sheets: {}, sheetName: "", sheetRows: [], headerRow: 0, headers: [],
    mapping: {}, selection: loadSelection(), result: null, currentView: "upload", page: 1, pageSize: Config.TABLE_PAGE_SIZE
  };

  function loadSelection() {
    try {
      const saved = JSON.parse(localStorage.getItem("cvc_rule_selection_v1") || "null");
      if (saved && typeof saved === "object") return Object.assign(Catalog.defaultRuleSelection(), saved);
    } catch (_) { /* armazenamento opcional */ }
    return Catalog.defaultRuleSelection();
  }
  function saveSelection() {
    try { localStorage.setItem("cvc_rule_selection_v1", JSON.stringify(state.selection)); }
    catch (_) { /* armazenamento opcional */ }
  }

  function toast(message, tone) {
    const element = $("#toast");
    element.textContent = message;
    element.className = `toast show ${tone || ""}`;
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { element.className = "toast"; }, 3400);
  }
  function setBusy(show, progress) {
    const overlay = $("#busyOverlay");
    overlay.hidden = !show;
    if (!show) return;
    const item = progress || {};
    const percent = Math.max(0, Math.min(100, Number(item.percent) || 0));
    $("#busyPhase").textContent = item.phase || "Preparando processamento";
    $("#busyDetail").textContent = item.detail || "Os dados permanecem neste computador";
    $("#busyProgress").style.width = `${percent}%`;
    $("#busyPercent").textContent = `${Math.round(percent)}%`;
    $("#busyCount").textContent = item.current != null ? `${U.formatNumber(item.current)} / ${U.formatNumber(item.total)}` : "";
  }
  function updateBusy(progress) { setBusy(true, progress); }

  function updateNavigation() {
    const hasFile = Boolean(state.file && state.sheetRows.length);
    const hasMaster = state.mapping[Config.MASTER_FIELD] != null;
    const hasResult = Boolean(state.result);
    const enabled = { upload: true, mapping: hasFile, rules: hasFile && hasMaster, results: hasResult, exports: hasResult };
    $$(".nav-button").forEach((button) => { button.disabled = !enabled[button.dataset.view]; });
    $("#sessionStatus").textContent = hasResult ? `${U.formatNumber(state.result.summary.total)} registros processados` : hasFile ? state.file.name : "Aguardando arquivo";
  }
  function navigate(view) {
    const button = $(`.nav-button[data-view="${view}"]`);
    if (button?.disabled) return;
    state.currentView = view;
    $$(".nav-button").forEach((item) => item.classList.toggle("active", item.dataset.view === view));
    $$(".app-view").forEach((panel) => panel.classList.toggle("active", panel.dataset.viewPanel === view));
    $("#pageTitle").textContent = titleByView[view] || Config.SHORT_NAME;
    $(".sidebar").classList.remove("open");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function fileSize(bytes) {
    if (bytes < 1024) return `${bytes} bytes`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  }
  function countDataRows() {
    return state.sheetRows.slice(state.headerRow + 1).filter((row) => row.some((value) => !U.isBlank(value))).length;
  }
  function guessHeaderRow(rows) {
    let best = { index: 0, score: -1 };
    rows.slice(0, 20).forEach((row, index) => {
      const headers = U.uniqueHeaders(row || []);
      const mapping = Engine.autoMap(headers);
      const mapped = Object.keys(mapping).length;
      const score = mapped * 10 + (mapping[Config.MASTER_FIELD] != null ? 30 : 0) + headers.filter((header) => !/^Coluna /.test(header)).length * .05;
      if (score > best.score) best = { index, score };
    });
    return best.index;
  }
  function populateSheetControls() {
    const names = Object.keys(state.sheets);
    $("#sheetSelect").innerHTML = names.map((name) => `<option${name === state.sheetName ? " selected" : ""}>${U.escapeHtml(name)}</option>`).join("");
    const max = Math.min(20, state.sheetRows.length || 1);
    $("#headerRowSelect").innerHTML = Array.from({ length: max }, (_, index) => `<option value="${index}"${index === state.headerRow ? " selected" : ""}>Linha ${index + 1}</option>`).join("");
  }
  function activateSheet(name, forcedHeader) {
    state.sheetName = name;
    state.sheetRows = state.sheets[name] || [];
    state.headerRow = forcedHeader == null ? guessHeaderRow(state.sheetRows) : Math.max(0, Math.min(Number(forcedHeader), state.sheetRows.length - 1));
    populateSheetControls();
    updateStructure(true);
  }
  function updateStructure(automatic) {
    const header = state.sheetRows[state.headerRow] || [];
    state.headers = U.uniqueHeaders(header);
    if (automatic) state.mapping = Engine.autoMap(state.headers);
    state.result = null;
    state.page = 1;
    $("#dataRowCount").textContent = U.formatNumber(countDataRows());
    $("#previewCaption").textContent = `${state.headers.length} colunas · mostrando até ${Config.MAX_PREVIEW_ROWS} linhas`;
    renderPreview();
    renderMapping();
    renderRules();
    updateNavigation();
  }
  function renderPreview() {
    const table = $("#previewTable");
    const rows = state.sheetRows.slice(state.headerRow + 1).filter((row) => row.some((value) => !U.isBlank(value))).slice(0, Config.MAX_PREVIEW_ROWS);
    table.innerHTML = `<thead><tr>${state.headers.map((header, index) => `<th>${U.escapeHtml(header)}<small>${U.columnName(index)}</small></th>`).join("")}</tr></thead><tbody>${rows.map((row) => `<tr>${state.headers.map((_, column) => `<td title="${U.escapeHtml(row[column] ?? "")}">${U.escapeHtml(row[column] ?? "") || "—"}</td>`).join("")}</tr>`).join("")}</tbody>`;
  }
  function renderFileSummary() {
    const element = $("#fileSummary");
    element.hidden = false;
    $("#dropZone").hidden = true;
    $("#demoButton").hidden = true;
    const sheetCount = Object.keys(state.sheets).length;
    element.innerHTML = `<span class="file-kind">${state.fileType.toUpperCase()}</span><div><strong>${U.escapeHtml(state.file.name)}</strong><small>${fileSize(state.file.size)} · ${sheetCount} aba(s) encontrada(s)</small></div><button type="button" id="replaceFile">Trocar arquivo</button>`;
    $("#replaceFile").addEventListener("click", () => $("#fileInput").click());
    $("#sheetSetup").hidden = false;
  }

  async function loadFile(file) {
    if (!file) return;
    setBusy(true, { phase: "Preparando leitura", detail: file.name, percent: 0 });
    try {
      const read = await IO.read(file, updateBusy);
      const names = Object.keys(read.sheets || {});
      if (!names.length) throw new Error("O arquivo não contém nenhuma aba legível.");
      state.file = file;
      state.fileType = read.type;
      state.sheets = read.sheets;
      state.result = null;
      state.sheetName = names[0];
      activateSheet(names[0]);
      renderFileSummary();
      setBusy(false);
      updateNavigation();
      toast("Arquivo lido com sucesso. Confirme a estrutura da planilha.", "success");
    } catch (error) {
      setBusy(false);
      console.error(error);
      toast(error.message || "Não foi possível ler o arquivo.", "error");
    }
  }

  function loadDemo() {
    const rows = [
      ["Matrícula Petros", "CPF", "Nome", "Data de Nascimento", "Sexo", "Nacionalidade", "Naturalidade UF", "Naturalidade Município", "Invalidez", "Data da Invalidez", "Aposentado INSS", "Tipo de Benefício INSS", "TVP"],
      ["000001", "52998224725", "Ana Maria de Souza", "20/05/1980", "F", "BRA — Brasil", "SP", "3550308 — São Paulo", "N", "", "N", "", "146"],
      ["000002", "11144477735", "Dr Bruno Almeida", "03/11/1972", "M", "BRA — Brasil", "RJ", "3304557 — Rio de Janeiro", "N", "", "N", "", "310"],
      ["000003", "11111111111", "Carlos 9 Silva", "30/02/2099", "Masculino", "Brasil", "XX", "3550308", "S", "", "S", "21 — Pensão por morte", "-3"],
      ["000004", "12345678909", "Mariana Costa", "29/02/1964", "F", "BRA — Brasil", "MG", "3106200 — Belo Horizonte", "S", "2018-06-10", "S", "32 — Aposentadoria por invalidez", "522"],
      ["000005", "", "João Pedro Santos", "14/08/1991", "M", "BRA — Brasil", "BA", "2927408 — Salvador", "N", "", "N", "", "84"]
    ];
    const csv = rows.map((row) => row.map((value) => `"${String(value).replace(/"/g, '""')}"`).join(";")).join("\r\n");
    loadFile(new File([csv], "Base_Demonstracao_Consistencia.csv", { type: "text/csv" }));
  }

  function mappedFieldCount() { return Catalog.fields.filter((field) => state.mapping[field.id] != null).length; }
  function selectedActiveRules() {
    return Catalog.fields.filter((field) => state.mapping[field.id] != null).reduce((sum, field) => sum + (state.selection[field.id] || []).length, 0);
  }
  function duplicateMappedColumns() {
    const counts = {};
    Object.values(state.mapping).forEach((column) => { if (column != null) counts[column] = (counts[column] || 0) + 1; });
    return Object.entries(counts).filter(([, count]) => count > 1).map(([column]) => Number(column));
  }
  function mappingOptions(fieldId) {
    return `<option value="">Não validar este campo</option>${state.headers.map((header, index) => `<option value="${index}"${Number(state.mapping[fieldId]) === index ? " selected" : ""}>${U.columnName(index)} · ${U.escapeHtml(header)}</option>`).join("")}`;
  }
  function fieldInitial(field) {
    return field.label.split(/\s+/).map((part) => U.normalizeText(part).replace(/[^A-Z0-9]/g, "")).filter(Boolean).slice(0, 2).map((part) => part[0]).join("");
  }
  function renderMapping() {
    if (!state.headers.length) return;
    const mapped = mappedFieldCount();
    const duplicates = duplicateMappedColumns();
    $("#mappingStats").innerHTML = `<article><span>Colunas encontradas</span><strong>${state.headers.length}</strong></article><article><span>Campos mapeados</span><strong>${mapped}</strong></article><article><span>Campos do catálogo</span><strong>${Catalog.fields.length}</strong></article><article><span>Colunas reutilizadas</span><strong>${duplicates.length}</strong></article>`;
    $("#mappingRows").innerHTML = Catalog.fields.map((field) => {
      const selected = state.mapping[field.id] != null;
      const ruleCount = (state.selection[field.id] || []).length;
      const master = field.id === Config.MASTER_FIELD;
      return `<div class="mapping-row" data-field-id="${field.id}"><div class="mapping-field"><span class="field-icon">${fieldInitial(field)}</span><div><strong>${U.escapeHtml(field.label)}${master ? " · chave mestre" : ""}</strong><span>${U.escapeHtml(field.group)} · criticidade ${field.criticality}</span><small>${U.escapeHtml(field.expectedFormat)}</small></div></div><select class="mapping-select" data-map-field="${field.id}" aria-label="Coluna para ${U.escapeHtml(field.label)}">${mappingOptions(field.id)}</select><span class="rule-count"><strong>${ruleCount}</strong> regra(s) configurada(s)</span><span class="map-state ${selected ? (master ? "master" : "ready") : "empty"}">${selected ? (master ? "Chave associada" : "Mapeado") : "Ignorado"}</span></div>`;
    }).join("");
    const hasMaster = state.mapping[Config.MASTER_FIELD] != null;
    const readiness = $("#mappingReadiness");
    readiness.innerHTML = hasMaster
      ? `<strong>${mapped} campo(s) pronto(s) para configurar</strong><span>${duplicates.length ? "Atenção: uma coluna está associada a mais de um campo." : "Chave mestre associada. Revise os campos opcionais."}</span>`
      : "<strong>Mapeie a Matrícula Petros</strong><span>A chave mestre é necessária para rastrear os resultados.</span>";
    $("#continueRules").disabled = !hasMaster;
    renderRules();
    updateNavigation();
  }

  function ruleDependencyText(rule) {
    const missing = (rule.requires || []).filter((id) => state.mapping[id] == null);
    if (!missing.length) return "";
    return `Dependência não mapeada: ${missing.map((id) => Catalog.getField(id)?.label || id).join(", ")}. A regra será registrada como não avaliada.`;
  }
  function renderRules() {
    const container = $("#ruleCards");
    if (!container || !state.headers.length) return;
    const fields = Catalog.fields.filter((field) => state.mapping[field.id] != null);
    container.innerHTML = fields.map((field) => {
      const selected = new Set(state.selection[field.id] || []);
      return `<article class="rule-card"><header><span class="field-icon">${fieldInitial(field)}</span><div><h3>${U.escapeHtml(field.label)}</h3><p>${U.escapeHtml(field.description)}</p></div><div class="rule-card-meta"><span class="criticality">Criticidade ${field.criticality}</span><div class="rule-card-actions"><button type="button" data-rule-group-action="select" data-rule-group-field="${field.id}" aria-label="Marcar todas as regras de ${U.escapeHtml(field.label)}">Marcar todas</button><button type="button" data-rule-group-action="clear" data-rule-group-field="${field.id}" aria-label="Desmarcar todas as regras de ${U.escapeHtml(field.label)}">Desmarcar</button></div></div></header><div class="rule-list">${field.rules.map((rule) => { const dependency = ruleDependencyText(rule); return `<label class="rule-option"><input type="checkbox" data-rule-field="${field.id}" value="${rule.id}"${selected.has(rule.id) ? " checked" : ""}><span><strong>${U.escapeHtml(rule.label)}</strong><small>${U.escapeHtml(rule.description)}</small></span><b class="severity ${rule.severity}">${rule.severity === "error" ? "Erro" : "Alerta"}</b>${dependency ? `<small class="dependency-note">${U.escapeHtml(dependency)}</small>` : ""}</label>`; }).join("")}</div><details class="catalog-details"><summary>Ver metadados e limites do catálogo</summary><div><section><h4>Controles de qualidade catalogados</h4><ul>${field.catalogRules.map((item) => `<li>${U.escapeHtml(item)}</li>`).join("")}</ul></section><section><h4>Exigem fonte externa ou evidência</h4>${field.externalRules.length ? `<ul>${field.externalRules.map((item) => `<li>${U.escapeHtml(item)}</li>`).join("")}</ul>` : "<p>Nenhum controle externo registrado para este campo.</p>"}</section></div></details></article>`;
    }).join("");
    updateRulesSummary();
  }
  function updateRulesSummary() {
    const fields = Catalog.fields.filter((field) => state.mapping[field.id] != null);
    let errors = 0, warnings = 0;
    fields.forEach((field) => {
      const selected = new Set(state.selection[field.id] || []);
      field.rules.filter((rule) => selected.has(rule.id)).forEach((rule) => { if (rule.severity === "error") errors += 1; else warnings += 1; });
    });
    $("#rulesFieldCount").textContent = fields.length;
    $("#rulesSelectedCount").textContent = errors + warnings;
    $("#rulesErrorCount").textContent = errors;
    $("#rulesWarningCount").textContent = warnings;
    $("#processButton").disabled = state.mapping[Config.MASTER_FIELD] == null || errors + warnings === 0;
    $("#ruleReadiness").innerHTML = errors + warnings
      ? `<strong>${errors + warnings} regra(s) em ${fields.length} campo(s)</strong><span>${errors} impeditiva(s), ${warnings} alerta(s) e processamento integral da base.</span>`
      : "<strong>Nenhuma regra selecionada</strong><span>Selecione pelo menos um teste para processar.</span>";
  }
  function setRuleMode(mode) {
    if (mode === "recommended") state.selection = Catalog.defaultRuleSelection();
    else if (mode === "all") state.selection = Catalog.allRuleSelection();
    else state.selection = Object.fromEntries(Catalog.fields.map((field) => [field.id, []]));
    saveSelection();
    renderRules();
  }

  async function processData() {
    if (state.mapping[Config.MASTER_FIELD] == null) return toast("Mapeie a Matrícula Petros antes de processar.", "error");
    if (!selectedActiveRules()) return toast("Selecione ao menos uma regra de validação.", "error");
    setBusy(true, { phase: "Preparando motor de regras", detail: `${countDataRows()} linhas disponíveis`, percent: 1 });
    try {
      const activeSelection = Object.fromEntries(Catalog.fields.filter((field) => state.mapping[field.id] != null).map((field) => [field.id, state.selection[field.id] || []]));
      state.result = await Engine.process({
        rows: state.sheetRows.slice(state.headerRow + 1), mapping: state.mapping, selection: activeSelection,
        firstDataRow: state.headerRow + 2,
        onProgress: (item) => updateBusy({ percent: item.percent, phase: item.phase, detail: `${U.formatNumber(item.current)} de ${U.formatNumber(item.total)} registros`, current: item.current, total: item.total })
      });
      setBusy(false);
      renderResults();
      updateNavigation();
      navigate("results");
      toast("Processamento concluído e consolidado.", "success");
    } catch (error) {
      setBusy(false);
      console.error(error);
      toast(error.message || "Falha ao processar a consistência.", "error");
    }
  }

  function renderKpis(summary) {
    $("#resultKpis").innerHTML = `<article class="metric blue"><span>Registros processados</span><strong>${U.formatNumber(summary.total)}</strong><small>${summary.mappedFields} campos avaliados</small></article><article class="metric accent"><span>Consistentes</span><strong>${U.formatNumber(summary.consistent)}</strong><small>sem erros ou alertas</small></article><article class="metric warning"><span>Com ressalvas</span><strong>${U.formatNumber(summary.withWarnings)}</strong><small>alertas, sem erro impeditivo</small></article><article class="metric danger"><span>Inconsistentes</span><strong>${U.formatNumber(summary.invalid)}</strong><small>exigem tratamento</small></article><article class="metric accent"><span>Taxa sem erros</span><strong>${U.formatPercent(summary.passRate, 1)}</strong><small>${U.formatNumber(summary.approved)} aprovados</small></article><article class="metric"><span>Total de achados</span><strong>${U.formatNumber(summary.issueCount)}</strong><small>${summary.errorCount} erros · ${summary.warningCount} alertas</small></article>`;
  }
  function populateFieldFilter() {
    $("#fieldFilter").innerHTML = '<option value="">Todos os campos</option>' + state.result.fieldStats.map((item) => `<option value="${item.fieldId}">${U.escapeHtml(item.label)}</option>`).join("");
  }
  function renderResults() {
    if (!state.result) return;
    const summary = state.result.summary;
    $("#resultsSubtitle").textContent = `${state.file.name} · ${state.sheetName} · ${U.formatNumber(summary.selectedRules)} regras em ${summary.mappedFields} campos · ${(summary.durationMs / 1000).toFixed(2)} s`;
    renderKpis(summary);
    $("#qualityDonut").innerHTML = Charts.qualityDonut(summary);
    $("#fieldQualityChart").innerHTML = Charts.fieldBars(state.result.fieldStats, 9);
    $("#ruleIssueChart").innerHTML = Charts.issueBars(state.result.ruleStats, 9);
    populateFieldFilter();
    state.page = 1;
    renderResultTable();
    $("#reportRoot").innerHTML = Reports.render(state);
  }
  function filteredRecords() {
    const query = U.normalizeText($("#resultSearch").value);
    const status = $("#statusFilter").value;
    const field = $("#fieldFilter").value;
    return state.result.records.filter((record) => {
      if (status && record.status !== status) return false;
      if (field && !record.issues.some((item) => item.fieldId === field)) return false;
      if (!query) return true;
      const haystack = U.normalizeText([record.matricula, record.status, ...Object.values(record.values), ...record.issues.flatMap((item) => [item.field, item.rule, item.message])].join(" "));
      return haystack.includes(query);
    });
  }
  function statusClass(status) {
    return status === Config.STATUS.PASS ? "pass" : status === Config.STATUS.WARNING ? "warning" : "fail";
  }
  function renderResultTable() {
    if (!state.result) return;
    const records = filteredRecords();
    const pagination = U.paginationModel(records.length, state.page, state.pageSize, Config.TABLE_PAGE_SIZE);
    const { showAll, pageSize, pageCount, start } = pagination;
    state.page = pagination.page;
    const visible = showAll ? records : records.slice(start, start + pageSize);
    $("#resultTableBody").innerHTML = visible.length ? visible.map((record) => {
      const fields = [...new Set(record.issues.map((item) => item.field))];
      return `<tr><td>${record.rowNumber}</td><td><strong>${U.escapeHtml(record.matricula) || "—"}</strong></td><td><span class="status-badge ${statusClass(record.status)}">${U.escapeHtml(record.status)}</span></td><td>${record.errors || "—"}</td><td>${record.warnings || "—"}</td><td><div class="field-pills">${fields.length ? fields.slice(0, 4).map((item) => `<span class="field-pill">${U.escapeHtml(item)}</span>`).join("") + (fields.length > 4 ? `<span class="field-pill">+${fields.length - 4}</span>` : "") : '<span class="field-pill">Nenhum</span>'}</div></td><td><button class="detail-button" type="button" data-record-index="${record.index}">Ver detalhe</button></td></tr>`;
    }).join("") : '<tr><td colspan="7"><div class="empty-mini">Nenhum registro corresponde aos filtros.</div></td></tr>';
    $("#tableCaption").textContent = showAll
      ? `${U.formatNumber(records.length)} registro(s) · exibindo todos`
      : `${U.formatNumber(records.length)} registro(s) · exibindo ${visible.length ? start + 1 : 0}–${Math.min(start + visible.length, records.length)}`;
    $("#pageSizeSelect").value = String(state.pageSize);
    $("#pageButtons").innerHTML = U.pageTokens(state.page, pageCount).map((token) => token === "…"
      ? '<span class="page-ellipsis" aria-hidden="true">…</span>'
      : `<button type="button" class="pagination-button page-number${token === state.page ? " active" : ""}" data-page="${token}"${token === state.page ? ' aria-current="page"' : ""}>${token}</button>`).join("");
    $("#firstPage").disabled = showAll || state.page <= 1;
    $("#prevPage").disabled = state.page <= 1;
    $("#nextPage").disabled = state.page >= pageCount;
    $("#lastPage").disabled = showAll || state.page >= pageCount;
  }
  function showRecord(index) {
    const record = state.result.records.find((item) => item.index === Number(index));
    if (!record) return;
    const content = $("#dialogContent");
    const issuesHtml = record.issues.length ? record.issues.map((item) => `<article class="dialog-issue ${item.severity}"><header><h3>${U.escapeHtml(item.field)} · ${U.escapeHtml(item.rule)}</h3><span class="severity ${item.severity}">${item.severity === "error" ? "Erro" : "Alerta"}</span></header><p>${U.escapeHtml(item.message)}</p><div class="value-comparison"><div><span>Valor original</span><code>${U.escapeHtml(item.value) || "(vazio)"}</code></div><div><span>${item.suggestion ? "Sugestão" : "Valor normalizado"}</span><code>${U.escapeHtml(item.suggestion || item.normalized) || "—"}</code></div></div></article>`).join("") : '<div class="report-success-box">Este registro passou em todas as regras selecionadas e aplicáveis.</div>';
    content.innerHTML = `<div class="dialog-hero"><div><span>Linha ${record.rowNumber}</span><h2 id="dialogTitle">Matrícula ${U.escapeHtml(record.matricula) || "não informada"}</h2><small>Detalhamento rastreável por campo e regra.</small></div><span class="status-badge ${statusClass(record.status)}">${U.escapeHtml(record.status)}</span></div><div class="dialog-summary"><div><span>Erros</span><strong>${record.errors}</strong></div><div><span>Alertas</span><strong>${record.warnings}</strong></div><div><span>Campos mapeados</span><strong>${Object.keys(record.values).length}</strong></div></div><div class="dialog-issues">${issuesHtml}</div>`;
    $("#recordDialog").showModal();
  }

  async function runExport(mode) {
    if (!state.result) return;
    setBusy(true, { phase: "Montando Excel de tratamento", detail: "Preparando abas e metadados", percent: 25 });
    try {
      await Exports.downloadWorkbook(state, mode);
      setBusy(false);
      toast("Excel gerado com sucesso.", "success");
    } catch (error) {
      setBusy(false);
      console.error(error);
      toast(error.message || "Não foi possível gerar o Excel.", "error");
    }
  }
  async function runTemplate(configured) {
    setBusy(true, { phase: "Gerando modelo Excel", detail: "Incluindo dicionário de campos", percent: 45 });
    try {
      const ids = configured ? Catalog.fields.filter((field) => state.mapping[field.id] != null).map((field) => field.id) : null;
      await Exports.downloadTemplate(ids);
      setBusy(false);
      toast("Modelo Excel gerado.", "success");
    } catch (error) {
      setBusy(false);
      console.error(error);
      toast(error.message || "Não foi possível gerar o modelo.", "error");
    }
  }
  function printReport() {
    if (!state.result) return;
    Reports.print();
    setTimeout(() => toast("Na janela de impressão, escolha “Salvar como PDF”.", "success"), 250);
  }

  function bindEvents() {
    $$(".nav-button").forEach((button) => button.addEventListener("click", () => navigate(button.dataset.view)));
    $$('[data-view-jump]').forEach((button) => button.addEventListener("click", () => navigate(button.dataset.viewJump)));
    $("#mobileMenu").addEventListener("click", () => $(".sidebar").classList.toggle("open"));
    $("#fileInput").addEventListener("change", (event) => loadFile(event.target.files?.[0]));
    $("#demoButton").addEventListener("click", loadDemo);
    const dropZone = $("#dropZone");
    ["dragenter", "dragover"].forEach((eventName) => dropZone.addEventListener(eventName, (event) => { event.preventDefault(); dropZone.classList.add("dragging"); }));
    ["dragleave", "drop"].forEach((eventName) => dropZone.addEventListener(eventName, (event) => { event.preventDefault(); dropZone.classList.remove("dragging"); }));
    dropZone.addEventListener("drop", (event) => loadFile(event.dataTransfer?.files?.[0]));
    $("#sheetSelect").addEventListener("change", (event) => activateSheet(event.target.value));
    $("#headerRowSelect").addEventListener("change", (event) => { state.headerRow = Number(event.target.value); updateStructure(true); });
    $("#continueMapping").addEventListener("click", () => navigate("mapping"));
    $("#autoMapButton").addEventListener("click", () => { state.mapping = Engine.autoMap(state.headers); renderMapping(); toast("Mapeamento automático refeito.", "success"); });
    $("#clearMappingButton").addEventListener("click", () => { const master = state.mapping[Config.MASTER_FIELD]; state.mapping = master == null ? {} : { [Config.MASTER_FIELD]: master }; renderMapping(); });
    $("#mappingRows").addEventListener("change", (event) => {
      const fieldId = event.target.dataset.mapField;
      if (!fieldId) return;
      if (event.target.value === "") delete state.mapping[fieldId];
      else state.mapping[fieldId] = Number(event.target.value);
      renderMapping();
    });
    $("#continueRules").addEventListener("click", () => { if (state.mapping[Config.MASTER_FIELD] != null) navigate("rules"); });
    $("#ruleCards").addEventListener("change", (event) => {
      const fieldId = event.target.dataset.ruleField;
      if (!fieldId) return;
      const selected = new Set(state.selection[fieldId] || []);
      if (event.target.checked) selected.add(event.target.value); else selected.delete(event.target.value);
      state.selection[fieldId] = [...selected];
      saveSelection();
      updateRulesSummary();
    });
    $("#ruleCards").addEventListener("click", (event) => {
      const button = event.target.closest("[data-rule-group-action]");
      if (!button) return;
      const fieldId = button.dataset.ruleGroupField;
      const field = Catalog.getField(fieldId);
      if (!field) return;
      state.selection[fieldId] = button.dataset.ruleGroupAction === "select" ? field.rules.map((rule) => rule.id) : [];
      $$(`[data-rule-field="${fieldId}"]`, $("#ruleCards")).forEach((input) => { input.checked = button.dataset.ruleGroupAction === "select"; });
      saveSelection();
      updateRulesSummary();
    });
    $("#recommendedRules").addEventListener("click", () => setRuleMode("recommended"));
    $("#allRules").addEventListener("click", () => setRuleMode("all"));
    $("#clearRules").addEventListener("click", () => setRuleMode("clear"));
    $("#processButton").addEventListener("click", processData);
    $("#reprocessButton").addEventListener("click", () => navigate("rules"));
    $("#resultSearch").addEventListener("input", U.debounce(() => { state.page = 1; renderResultTable(); }, 160));
    $("#statusFilter").addEventListener("change", () => { state.page = 1; renderResultTable(); });
    $("#fieldFilter").addEventListener("change", () => { state.page = 1; renderResultTable(); });
    $("#pageSizeSelect").addEventListener("change", (event) => { state.pageSize = event.target.value === "all" ? "all" : Number(event.target.value); state.page = 1; renderResultTable(); });
    $("#firstPage").addEventListener("click", () => { state.page = 1; renderResultTable(); });
    $("#prevPage").addEventListener("click", () => { state.page -= 1; renderResultTable(); });
    $("#pageButtons").addEventListener("click", (event) => { const button = event.target.closest("[data-page]"); if (button) { state.page = Number(button.dataset.page); renderResultTable(); } });
    $("#nextPage").addEventListener("click", () => { state.page += 1; renderResultTable(); });
    $("#lastPage").addEventListener("click", () => { state.page = U.paginationModel(filteredRecords().length, 1, state.pageSize, Config.TABLE_PAGE_SIZE).pageCount; renderResultTable(); });
    $("#resultTableBody").addEventListener("click", (event) => { const button = event.target.closest("[data-record-index]"); if (button) showRecord(button.dataset.recordIndex); });
    $("#closeDialog").addEventListener("click", () => $("#recordDialog").close());
    $("#recordDialog").addEventListener("click", (event) => { if (event.target === $("#recordDialog")) $("#recordDialog").close(); });
    $("#quickExcelButton").addEventListener("click", () => runExport("full"));
    $("#quickPdfButton").addEventListener("click", printReport);
    $("#exportFullButton").addEventListener("click", () => runExport("full"));
    $("#exportIssuesButton").addEventListener("click", () => runExport("issues"));
    $("#exportTemplateButton").addEventListener("click", () => runTemplate(true));
    $("#downloadTemplateTop").addEventListener("click", () => runTemplate(false));
    $("#printReportButton").addEventListener("click", printReport);
  }

  function init() {
    $("#sidebarVersion").textContent = `${Config.APP_NAME} · ${Config.VERSION}`;
    bindEvents();
    updateNavigation();
    updateRulesSummary();
  }

  init();
})();
