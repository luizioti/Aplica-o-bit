(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVCCatalog = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  function rule(id, label, description, type, options) {
    return Object.assign({ id, label, description, type, severity: "error", weight: 5, default: true, requires: [] }, options || {});
  }

  const fields = [
    {
      id: "matricula_petros", label: "Matrícula Petros", group: "Chave mestre", catalog: false,
      aliases: ["Matrícula Petros", "Matricula Petros", "Matrícula", "Matricula", "MATR_PARTICIPANTE", "CD_MATRICULA"],
      description: "Chave mestre usada para identificar e rastrear cada participante durante a validação.",
      type: "Texto identificador", expectedFormat: "Identificador não vazio, preservado como texto e sem espaços.",
      required: "Obrigatório em todos os processamentos", nullable: "Não", criticality: 5, sensitivity: "Dado pessoal",
      catalogRules: ["Completude da chave", "Formato utilizável", "Unicidade no arquivo", "Preservação de zeros à esquerda"],
      externalRules: [],
      rules: [
        rule("required", "Matrícula preenchida", "A chave mestre não pode ser nula ou vazia.", "required"),
        rule("format", "Formato utilizável", "Até 40 caracteres e sem caracteres de controle.", "matriculaFormat", { weight: 4 }),
        rule("spaces", "Sem espaços", "Remove espaços internos e externos que podem impedir cruzamentos.", "noWhitespace", { severity: "warning", weight: 3 }),
        rule("unique", "Matrícula única", "A mesma matrícula não deve aparecer mais de uma vez no arquivo.", "unique", { weight: 5 })
      ]
    },
    {
      id: "cpf", label: "CPF", group: "Identificação", catalog: true,
      aliases: ["CPF", "CPF Participante", "NR_CPF", "Número CPF", "Numero CPF"],
      description: "Identificador fiscal da pessoa física perante a Receita Federal.",
      type: "String numérica (texto)", expectedFormat: "11 dígitos numéricos sem máscara; exibição ###.###.###-##.",
      required: "Obrigatório", nullable: "Não", criticality: 5, sensitivity: "Dado pessoal identificável",
      catalogRules: ["Completude", "Formato com 11 dígitos", "Dígitos verificadores módulo 11", "Unicidade", "Rejeição de sequência repetida", "Situação cadastral RFB"],
      externalRules: ["Situação cadastral na Receita Federal"],
      rules: [
        rule("required", "CPF preenchido", "CPF não pode ser nulo ou vazio.", "required"),
        rule("format", "Exatamente 11 dígitos", "O valor mestre deve conter somente 11 dígitos, sem máscara.", "cpfFormat", { weight: 4 }),
        rule("repeated", "Sem sequência repetida", "Rejeita CPFs formados por um único dígito repetido.", "cpfRepeated", { weight: 4 }),
        rule("check_digits", "Dígitos verificadores válidos", "Valida D10 e D11 pelo algoritmo módulo 11 da RFB.", "cpfCheckDigits"),
        rule("unique", "CPF único", "O CPF não deve estar duplicado no arquivo processado.", "unique")
      ]
    },
    {
      id: "nome", label: "Nome", group: "Identificação", catalog: true,
      aliases: ["Nome", "Nome Participante", "Nome do Participante", "Participante", "NM_PESSOA"],
      description: "Nome civil completo do participante, preservando a grafia original.",
      type: "String textual", expectedFormat: "Até 150 caracteres; letras, espaços, hífen e apóstrofo.",
      required: "Obrigatório", nullable: "Não", criticality: 5, sensitivity: "Dado pessoal identificável",
      catalogRules: ["Completude", "Caracteres compatíveis com nome civil", "Consistência documental", "Sem títulos ou espaços duplicados", "Rastreabilidade"],
      externalRules: ["Compatibilidade com CPF/documento", "Protocolo da alteração"],
      rules: [
        rule("required", "Nome preenchido", "O nome não pode ser nulo ou vazio.", "required"),
        rule("length", "Comprimento adequado", "O nome deve ter entre 2 e 150 caracteres.", "lengthBetween", { params: { min: 2, max: 150 }, weight: 4 }),
        rule("characters", "Caracteres de nome civil", "Aceita letras Unicode, espaços, hífens e apóstrofos.", "nameCharacters", { weight: 4 }),
        rule("controls", "Sem caracteres de controle", "Impede quebras e caracteres invisíveis indevidos.", "noControl", { weight: 4 }),
        rule("double_spaces", "Sem espaços duplicados", "Sinaliza espaços consecutivos para padronização.", "noDoubleSpaces", { severity: "warning", weight: 3 }),
        rule("titles", "Sem títulos indevidos", "Sinaliza prefixos como Sr., Dr. ou Prof. no valor mestre.", "noTitles", { severity: "warning", weight: 3 })
      ]
    },
    {
      id: "data_nascimento", label: "Data de Nascimento", group: "Dados Demográficos", catalog: true,
      aliases: ["Data de Nascimento", "Data Nascimento", "Nascimento", "DT_NASCIMENTO", "DT_NASC"],
      description: "Data de nascimento usada em identificação, elegibilidade e cálculos.",
      type: "Data", expectedFormat: "DD/MM/AAAA; células de data nativas do Excel também são reconhecidas.",
      required: "Obrigatório", nullable: "Não", criticality: 5, sensitivity: "Dado pessoal",
      catalogRules: ["Completude", "Data real e não futura", "Idade plausível", "Consistência temporal", "Consistência documental"],
      externalRules: ["Compatibilidade com CPF/documento", "Consistência com admissão, inscrição e benefício"],
      rules: [
        rule("required", "Data preenchida", "A data de nascimento não pode ser nula.", "required"),
        rule("valid", "Data válida em DD/MM/AAAA", "Exige uma data real no padrão brasileiro; células de data nativas do Excel são reconhecidas.", "brazilianDate"),
        rule("future", "Data não futura", "A data não pode ser posterior à data do processamento.", "notFuture"),
        rule("age", "Idade plausível", "Sinaliza idade fora do intervalo de 0 a 120 anos.", "ageRange", { severity: "warning", weight: 4, params: { min: 0, max: 120 } }),
        rule("before_death", "Anterior ao óbito", "Quando a data de óbito estiver mapeada, o nascimento deve ser anterior.", "dateBeforeField", { requires: ["data_obito"], params: { field: "data_obito" } })
      ]
    },
    {
      id: "sexo", label: "Sexo", group: "Dados Demográficos", catalog: true,
      aliases: ["Sexo", "Sexo Cadastral", "CD_SEXO", "TP_SEXO"],
      description: "Sexo cadastral informado pela fonte competente, sem inferência de identidade de gênero.",
      type: "Enumeração", expectedFormat: "M = Masculino; F = Feminino.",
      required: "Obrigatório", nullable: "Não", criticality: 5, sensitivity: "Dado pessoal",
      catalogRules: ["Completude", "Domínio M/F", "Consistência com fonte", "Rastreabilidade", "Uso adequado"],
      externalRules: ["Compatibilidade com documento", "Protocolo de alteração"],
      rules: [
        rule("required", "Sexo preenchido", "O valor não pode ser nulo.", "required"),
        rule("domain", "Domínio M/F", "Aceita estritamente os códigos M ou F.", "enum", { params: { values: ["M", "F"], aliases: { MASCULINO: "M", HOMEM: "M", FEMININO: "F", MULHER: "F" } } })
      ]
    },
    {
      id: "estado_civil", label: "Estado Civil", group: "Dados Demográficos e Familiares", catalog: true,
      aliases: ["Estado Civil", "ESTADO_CIVIL", "CD_ESTADO_CIVIL", "Situacao Civil", "Situação Civil"],
      description: "Situação civil vigente, mantida em domínio controlado.",
      type: "Enumeração", expectedFormat: "SOLTEIRO, CASADO, UNIÃO ESTÁVEL, SEPARADO, DIVORCIADO ou VIÚVO.",
      required: "Obrigatório para titular; condicional para demais perfis", nullable: "Quando não aplicável", criticality: 4, sensitivity: "Dado pessoal",
      catalogRules: ["Domínio controlado", "Atualidade", "Consistência com dependências", "Rastreabilidade", "Completude para titulares"],
      externalRules: ["Atualidade na data de referência", "Vínculos de cônjuge", "Protocolo da mudança"],
      rules: [
        rule("required", "Preenchimento obrigatório", "Use quando a base processada contiver somente titulares.", "required", { default: false, severity: "warning", weight: 4 }),
        rule("domain", "Domínio de estado civil", "Valida o valor contra a lista controlada do catálogo.", "enum", { weight: 4, params: { values: ["SOLTEIRO", "CASADO", "UNIAO ESTAVEL", "SEPARADO", "DIVORCIADO", "VIUVO"], aliases: { SOLTEIRA: "SOLTEIRO", CASADA: "CASADO", "UNIÃO ESTÁVEL": "UNIAO ESTAVEL", SEPARADA: "SEPARADO", DIVORCIADA: "DIVORCIADO", "VIÚVO": "VIUVO", "VIÚVA": "VIUVO", VIUVA: "VIUVO" } } })
      ]
    },
    {
      id: "nacionalidade", label: "Nacionalidade", group: "Dados Demográficos", catalog: true,
      aliases: ["Nacionalidade", "País de Nascimento", "Pais de Nascimento", "CD_PAIS_NASCIMENTO", "PAIS_NASC"],
      description: "País de nacionalidade ou nascimento representado por código padronizado.",
      type: "Código + descrição", expectedFormat: "Código ISO 3166-1 alpha-3; ex.: BRA — Brasil.",
      required: "Obrigatório", nullable: "Não", criticality: 4, sensitivity: "Dado pessoal",
      catalogRules: ["Completude", "Código de país oficial", "Consistência com documento e NIF", "Código único", "Rastreabilidade"],
      externalRules: ["Existência em tabela oficial versionada", "Compatibilidade com documento/NIF"],
      rules: [
        rule("required", "Nacionalidade preenchida", "O país deve ser informado.", "required", { weight: 4 }),
        rule("iso3", "Formato ISO alpha-3", "Aceita código de três letras, isolado ou acompanhado da descrição.", "iso3", { weight: 4 })
      ]
    },
    {
      id: "naturalidade_uf", label: "Naturalidade (UF)", group: "Dados Demográficos", catalog: true,
      aliases: ["Naturalidade UF", "Naturalidade (UF)", "UF Naturalidade", "UF Nascimento", "SG_UF_NASC"],
      description: "Unidade da Federação de nascimento para pessoas nascidas no Brasil.",
      type: "Enumeração / código", expectedFormat: "Sigla oficial da UF com 2 caracteres.",
      required: "Condicional — nascidos no Brasil", nullable: "Para nascimento no exterior", criticality: 4, sensitivity: "Dado pessoal",
      catalogRules: ["Preenchido para nascimento no Brasil", "Sigla válida", "Município pertence à UF", "Dois caracteres", "Nulidade permitida"],
      externalRules: ["Tratamento histórico de UFs"],
      rules: [
        rule("required_brazil", "Obrigatória para Brasil", "Exige UF quando a nacionalidade começar por BRA.", "conditionalRequired", { weight: 4, requires: ["nacionalidade"], params: { field: "nacionalidade", matches: ["BRA"] } }),
        rule("length", "Exatamente 2 caracteres", "A sigla deve ter dois caracteres sem descrição adicional.", "exactLength", { severity: "warning", weight: 3, params: { length: 2 } }),
        rule("domain", "UF oficial", "Valida contra as 27 siglas oficiais.", "uf", { weight: 4 })
      ]
    },
    {
      id: "naturalidade_municipio", label: "Naturalidade (Município)", group: "Dados Demográficos", catalog: true,
      aliases: ["Naturalidade Município", "Naturalidade Municipio", "Naturalidade (Município)", "Municipio Nascimento", "Município Nascimento", "CD_MUNICIPIO_NASC"],
      description: "Código IBGE e nome oficial do município de nascimento.",
      type: "Código + descrição", expectedFormat: "Código IBGE com 7 dígitos, opcionalmente acompanhado do nome.",
      required: "Condicional — nascidos no Brasil", nullable: "Exterior ou desconhecido documentalmente", criticality: 4, sensitivity: "Dado pessoal",
      catalogRules: ["Preenchido para nascimento no Brasil", "Código existente/histórico", "Município pertence à UF", "Código de 7 dígitos", "Sem ambiguidade"],
      externalRules: ["Existência e vigência em tabela IBGE", "Equivalência de municípios históricos"],
      rules: [
        rule("required_brazil", "Obrigatório para Brasil", "Exige município quando a nacionalidade começar por BRA.", "conditionalRequired", { weight: 4, requires: ["nacionalidade"], params: { field: "nacionalidade", matches: ["BRA"] } }),
        rule("format", "Código IBGE de 7 dígitos", "Aceita o código isolado ou seguido de separador e nome.", "ibgeFormat", { weight: 4 }),
        rule("with_name", "Código acompanhado do nome", "Sinaliza código sem descrição para facilitar o tratamento humano.", "ibgeWithName", { default: false, severity: "warning", weight: 3 }),
        rule("uf_consistency", "Código coerente com a UF", "Compara os dois primeiros dígitos do código IBGE com a UF mapeada.", "municipioUf", { requires: ["naturalidade_uf"], params: { field: "naturalidade_uf" } })
      ]
    },
    {
      id: "nif", label: "NIF", group: "Identificação Fiscal", catalog: true,
      aliases: ["NIF", "Número de Identificação Fiscal", "Numero de Identificacao Fiscal", "NR_NIF", "TAX ID"],
      description: "Identificador fiscal estrangeiro, preservando zeros e caracteres significativos.",
      type: "String alfanumérica", expectedFormat: "Até 40 caracteres, sem espaços externos.",
      required: "Quando houver obrigação fiscal estrangeira", nullable: "Sem obrigação fiscal estrangeira", criticality: 5, sensitivity: "Dado pessoal identificável",
      catalogRules: ["Condicionalidade", "Padrão por país", "País emissor compatível", "Unicidade contextual", "Preservação de caracteres"],
      externalRules: ["Padrão parametrizado por país", "País emissor", "Unicidade por país"],
      rules: [
        rule("format", "Formato preservado", "Até 40 caracteres alfanuméricos e os separadores . / _ -.", "nifFormat", { weight: 4 }),
        rule("trim", "Sem espaços externos", "Sinaliza espaços antes ou depois do identificador.", "noOuterSpaces", { severity: "warning", weight: 3 }),
        rule("unique", "NIF único no arquivo", "Sinaliza repetição no arquivo; confirme o país emissor antes de tratar.", "unique", { default: false, severity: "warning", weight: 4 }),
        rule("not_cpf", "Não reutilizar o CPF", "Sinaliza NIF igual ao CPF quando não há regra explícita.", "differentFromField", { severity: "warning", weight: 4, requires: ["cpf"], params: { field: "cpf", compare: "digits" } })
      ]
    },
    {
      id: "isencao_ir", label: "Isenção de Imposto de Renda", group: "Tributário e Benefícios", catalog: true,
      aliases: ["Isenção de Imposto de Renda", "Isencao de Imposto de Renda", "Isenção IR", "Isencao IR", "FL_ISENTO_IR"],
      description: "Indicador de isenção aplicável ao rendimento, sem exposição do motivo clínico.",
      type: "Booleano / enumeração", expectedFormat: "S = isento; N = não isento.",
      required: "Para pessoas em folha de benefícios/pagamentos", nullable: "Públicos fora do escopo", criticality: 5, sensitivity: "Dado pessoal sensível por inferência",
      catalogRules: ["Domínio S/N", "Evidência e aprovação", "Escopo legal", "Temporalidade", "Segregação do motivo"],
      externalRules: ["Documentação e aprovação", "Escopo do rendimento", "Data de início", "Segregação de acesso"],
      rules: [rule("domain", "Domínio S/N", "Aceita estritamente os códigos S ou N.", "enum", { params: { values: ["S", "N"], aliases: { SIM: "S", NAO: "N", "NÃO": "N", TRUE: "S", FALSE: "N", "1": "S", "0": "N" } } })]
    },
    {
      id: "data_obito", label: "Data de Óbito", group: "Eventos Vitais", catalog: true,
      aliases: ["Data de Óbito", "Data de Obito", "Data Óbito", "Data Obito", "DT_OBITO"],
      description: "Data do falecimento confirmada por fonte autorizada.",
      type: "Data", expectedFormat: "AAAA-MM-DD no banco ou DD/MM/AAAA na entrada.",
      required: "Quando o óbito estiver confirmado", nullable: "Enquanto não houver confirmação", criticality: 5, sensitivity: "Dado pessoal",
      catalogRules: ["Evidência autorizada", "Data real e não futura", "Posterior ao nascimento", "Bloqueio de movimentos incompatíveis", "Rastreabilidade"],
      externalRules: ["Confirmação em fonte autorizada", "Cessação e movimentos posteriores", "Protocolo da fonte"],
      rules: [
        rule("valid", "Data existente", "Valida datas preenchidas nos formatos aceitos.", "validDate"),
        rule("future", "Data não futura", "A data de óbito não pode estar no futuro.", "notFuture"),
        rule("after_birth", "Posterior ao nascimento", "Compara com a data de nascimento quando mapeada.", "dateAfterField", { requires: ["data_nascimento"], params: { field: "data_nascimento" } })
      ]
    },
    {
      id: "motivo_obito", label: "Motivo de Óbito", group: "Saúde e Eventos Vitais", catalog: true,
      aliases: ["Motivo de Óbito", "Motivo de Obito", "Causa Óbito", "Causa Obito", "CID Óbito", "CID Obito"],
      description: "Código controlado da causa quando sua coleta for necessária e autorizada.",
      type: "Código + descrição", expectedFormat: "Preferencialmente código CID + descrição controlada.",
      required: "Somente para finalidade definida", nullable: "Sim", criticality: 5, sensitivity: "Dado pessoal sensível — saúde",
      catalogRules: ["Finalidade definida", "Evidência", "CID e descrição padronizados", "Vinculado a óbito", "Acesso restrito"],
      externalRules: ["Finalidade/base legal", "Validade em tabela CID", "Fonte documental", "Controle de acesso"],
      rules: [
        rule("when_death", "Preenchido quando há óbito", "Regra opcional para processos que exigem a causa em todo óbito confirmado.", "conditionalRequired", { default: false, severity: "warning", requires: ["data_obito"], params: { field: "data_obito", nonBlank: true } }),
        rule("cid", "Formato compatível com CID", "Aceita código CID ou 'não informado'; não confirma a existência na tabela oficial.", "cidFormat", { severity: "warning", weight: 4 }),
        rule("length", "Sem detalhe excessivo", "Sinaliza descrição com mais de 160 caracteres.", "maxLength", { severity: "warning", params: { max: 160 } })
      ]
    },
    {
      id: "invalidez", label: "Invalidez", group: "Saúde e Benefícios", catalog: true,
      aliases: ["Invalidez", "Indicador Invalidez", "FL_INVALIDEZ", "INVALIDEZ_S_N"],
      description: "Indicador de invalidez formalmente reconhecida, sem inferência por diagnóstico.",
      type: "Booleano / enumeração", expectedFormat: "S = reconhecida; N = não reconhecida.",
      required: "Quando relevante ao processo", nullable: "Fora do escopo", criticality: 5, sensitivity: "Dado pessoal sensível — saúde",
      catalogRules: ["Domínio S/N", "Decisão formal", "Consistência com data e benefício", "Não inferência", "Rastreabilidade"],
      externalRules: ["Decisão/laudo", "Origem e protocolo", "Reavaliação competente"],
      rules: [rule("domain", "Domínio S/N", "Aceita estritamente os códigos S ou N.", "enum", { params: { values: ["S", "N"], aliases: { SIM: "S", NAO: "N", "NÃO": "N", TRUE: "S", FALSE: "N", "1": "S", "0": "N" } } })]
    },
    {
      id: "data_invalidez", label: "Data da Invalidez", group: "Saúde e Benefícios", catalog: true,
      aliases: ["Data da Invalidez", "Data Invalidez", "DT_INVALIDEZ", "Início Invalidez", "Inicio Invalidez"],
      description: "Marco temporal de início da invalidez conforme definição operacional.",
      type: "Data", expectedFormat: "AAAA-MM-DD no banco ou DD/MM/AAAA na entrada.",
      required: "Quando Invalidez = S", nullable: "Quando Invalidez = N ou não aplicável", criticality: 5, sensitivity: "Dado pessoal sensível — saúde",
      catalogRules: ["Preenchida quando Invalidez = S", "Data real e não futura", "Posterior ao nascimento", "Marco semântico correto", "Evidência"],
      externalRules: ["Coerência com requerimento/concessão", "Marco e documento vinculante"],
      rules: [
        rule("required_if_invalid", "Obrigatória quando Invalidez = S", "Exige data quando o indicador de invalidez estiver marcado como S.", "conditionalRequired", { requires: ["invalidez"], params: { field: "invalidez", matches: ["S"] } }),
        rule("blank_if_not_invalid", "Nula quando Invalidez = N", "Sinaliza data preenchida para indicador N.", "conditionalBlank", { severity: "warning", requires: ["invalidez"], params: { field: "invalidez", matches: ["N"] } }),
        rule("valid", "Data existente", "Valida datas preenchidas nos formatos aceitos.", "validDate"),
        rule("future", "Data não futura", "A data não pode estar no futuro.", "notFuture"),
        rule("after_birth", "Posterior ao nascimento", "Compara com a data de nascimento quando mapeada.", "dateAfterField", { requires: ["data_nascimento"], params: { field: "data_nascimento" } })
      ]
    },
    {
      id: "aposentado_inss", label: "Aposentado pelo INSS", group: "Previdenciário Externo", catalog: true,
      aliases: ["Aposentado pelo INSS", "Aposentado INSS", "FL_APOSENTADO_INSS", "APOSENTADO_S_N"],
      description: "Indicador de aposentadoria concedida pelo INSS, sem inferência por idade.",
      type: "Booleano / enumeração", expectedFormat: "S = aposentadoria concedida; N = não aposentado.",
      required: "Quando utilizado em elegibilidade ou cálculo", nullable: "Fora do escopo", criticality: 5, sensitivity: "Dado pessoal previdenciário",
      catalogRules: ["Domínio S/N", "Evidência oficial", "Consistência com benefício", "Atualidade", "Não inferência"],
      externalRules: ["Documento/fonte oficial", "Vigência e revisão"],
      rules: [rule("domain", "Domínio S/N", "Aceita estritamente os códigos S ou N.", "enum", { params: { values: ["S", "N"], aliases: { SIM: "S", NAO: "N", "NÃO": "N", TRUE: "S", FALSE: "N", "1": "S", "0": "N" } } })]
    },
    {
      id: "tipo_beneficio_inss", label: "Tipo de Benefício INSS", group: "Previdenciário Externo", catalog: true,
      aliases: ["Tipo de Benefício INSS", "Tipo de Beneficio INSS", "Benefício INSS", "Beneficio INSS", "Especie INSS", "Espécie INSS"],
      description: "Espécie oficial do benefício e descrição controlada.",
      type: "Código + descrição", expectedFormat: "Código/espécie oficial + descrição controlada.",
      required: "Quando houver benefício INSS", nullable: "Quando não houver benefício", criticality: 5, sensitivity: "Dado pessoal previdenciário",
      catalogRules: ["Preenchido quando há benefício", "Código existente", "Compatível com aposentadoria/invalidez", "Código vigente", "Rastreabilidade"],
      externalRules: ["Existência e vigência na tabela de espécies", "Fonte e data"],
      rules: [
        rule("required_if_retired", "Preenchido para aposentado", "Exige o tipo quando Aposentado pelo INSS = S.", "conditionalRequired", { requires: ["aposentado_inss"], params: { field: "aposentado_inss", matches: ["S"] } }),
        rule("format", "Código + descrição", "Valida código de 2 ou 3 dígitos acompanhado da descrição, ou descrição controlada reconhecível.", "benefitFormat", { severity: "warning", weight: 4 }),
        rule("retirement_consistency", "Compatível com aposentadoria", "Para indicador S, a descrição deve representar aposentadoria.", "containsWhen", { severity: "warning", requires: ["aposentado_inss"], params: { field: "aposentado_inss", matches: ["S"], contains: "APOSENTADORIA" } }),
        rule("invalidity_consistency", "Compatível com invalidez", "Quando Invalidez = S, sinaliza benefício sem referência a incapacidade/invalidez.", "containsWhen", { default: false, severity: "warning", requires: ["invalidez"], params: { field: "invalidez", matches: ["S"], contains: "INCAPACIDADE|INVALIDEZ" } })
      ]
    },
    {
      id: "tvp", label: "TVP — Tempo de Vínculo Previdenciário", group: "Vínculo e Elegibilidade", catalog: true,
      aliases: ["TVP", "Tempo de Vínculo Previdenciário", "Tempo de Vinculo Previdenciario", "TVP Meses", "QTD_MESES_TVP"],
      description: "Tempo de vínculo previdenciário mantido em meses inteiros na data de referência.",
      type: "Inteiro derivado", expectedFormat: "Quantidade de meses inteiros maior ou igual a zero.",
      required: "Quando aplicável ao vínculo", nullable: "Somente para perfis sem vínculo", criticality: 5, sensitivity: "Dado pessoal previdenciário",
      catalogRules: ["Reprodutibilidade", "Não negatividade", "Consistência temporal", "Regulamento vigente", "Sem edição manual", "Atualização após evento"],
      externalRules: ["Recomputação pelas datas-fonte", "Regulamento e data de referência", "Bloqueio de edição", "Atualidade após eventos"],
      rules: [
        rule("required", "Preenchimento obrigatório", "Use quando todos os registros processados possuírem vínculo válido.", "required", { default: false }),
        rule("integer", "Meses inteiros", "O TVP deve ser um número inteiro.", "integer"),
        rule("non_negative", "Valor não negativo", "O TVP deve ser maior ou igual a zero.", "minNumber", { params: { min: 0 } }),
        rule("outlier", "Limite operacional", "Sinaliza valores acima de 1.200 meses para revisão, sem reprovar automaticamente.", "maxNumber", { severity: "warning", weight: 3, params: { max: 1200 } })
      ]
    }
  ];

  const byId = Object.fromEntries(fields.map((field) => [field.id, field]));
  function getField(id) { return byId[id] || null; }
  function defaultRuleSelection() {
    return Object.fromEntries(fields.map((field) => [field.id, field.rules.filter((item) => item.default).map((item) => item.id)]));
  }
  function allRuleSelection() {
    return Object.fromEntries(fields.map((field) => [field.id, field.rules.map((item) => item.id)]));
  }
  function selectedRuleCount(selection) {
    return Object.values(selection || {}).reduce((sum, ids) => sum + (ids || []).length, 0);
  }

  return { fields, byId, getField, defaultRuleSelection, allRuleSelection, selectedRuleCount };
});
