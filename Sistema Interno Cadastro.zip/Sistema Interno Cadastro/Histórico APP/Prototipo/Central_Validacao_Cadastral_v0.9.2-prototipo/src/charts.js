(function (root, factory) {
  const U = typeof module === "object" && module.exports ? require("./utils.js") : root.CVCUtils;
  const api = factory(U);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVCCharts = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (U) {
  "use strict";

  function qualityDonut(summary) {
    const total = Math.max(summary.total, 1);
    const pass = 100 * summary.consistent / total;
    const warning = 100 * summary.withWarnings / total;
    const failStart = pass + warning;
    return `<div class="donut-layout"><div class="donut" style="--pass:${pass};--warning:${failStart}"><div><strong>${U.formatPercent(summary.passRate, 1)}</strong><span>sem erros</span></div></div><ul class="chart-legend"><li><i class="legend-pass"></i><span>Consistentes</span><strong>${U.formatNumber(summary.consistent)}</strong></li><li><i class="legend-warning"></i><span>Com ressalvas</span><strong>${U.formatNumber(summary.withWarnings)}</strong></li><li><i class="legend-fail"></i><span>Inconsistentes</span><strong>${U.formatNumber(summary.invalid)}</strong></li></ul></div>`;
  }

  function fieldBars(fieldStats, limit) {
    const rows = (fieldStats || []).slice(0, limit || 8);
    if (!rows.length) return '<div class="empty-mini">Nenhum campo calculado.</div>';
    return `<div class="quality-bars">${rows.map((item) => `<div class="quality-row"><div><span>${U.escapeHtml(item.label)}</span><small>${U.formatNumber(item.affectedRecords)} registro(s) afetado(s)</small></div><div class="quality-track"><i style="width:${Math.max(2, item.recordConformity * 100)}%"></i></div><strong>${U.formatPercent(item.recordConformity, 1)}</strong></div>`).join("")}</div>`;
  }

  function issueBars(items, limit) {
    const rows = (items || []).filter((item) => item.failures).slice(0, limit || 8);
    const max = Math.max(1, ...rows.map((item) => item.failures));
    if (!rows.length) return '<div class="empty-mini">Nenhuma quebra de regra encontrada.</div>';
    return `<div class="issue-bars">${rows.map((item) => `<div class="issue-bar"><span title="${U.escapeHtml(item.rule)}">${U.escapeHtml(item.rule)}</span><div><i style="width:${100 * item.failures / max}%"></i></div><strong>${U.formatNumber(item.failures)}</strong></div>`).join("")}</div>`;
  }

  return { qualityDonut, fieldBars, issueBars };
});

