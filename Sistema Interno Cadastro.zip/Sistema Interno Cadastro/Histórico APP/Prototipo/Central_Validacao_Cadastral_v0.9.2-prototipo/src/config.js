(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVCConfig = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  return {
    APP_NAME: "Central de Consistência Cadastral",
    SHORT_NAME: "Consistência Cadastral",
    VERSION: "0.9.2-prototipo",
    RULES_VERSION: "1.0.0",
    CATALOG_VERSION: "1.1",
    CATALOG_DATE: "27/06/2026",
    INTERNAL_NOTICE: "USO INTERNO — Dados pessoais sob gestão do Cadastro — Núcleo Analytics.",
    TABLE_PAGE_SIZE: 20,
    PROCESS_CHUNK: 750,
    MAX_PREVIEW_ROWS: 6,
    MASTER_FIELD: "matricula_petros",
    STATUS: {
      PASS: "Consistente",
      WARNING: "Aprovado com ressalvas",
      FAIL: "Inconsistente"
    },
    COLORS: {
      navy: "#021832",
      ink: "#071f25",
      green: "#173f3a",
      teal: "#17847b",
      blue: "#2a6ba7",
      sage: "#6fa399",
      orange: "#de8e28",
      gold: "#e2c26f",
      danger: "#a83a2e"
    }
  };
});
