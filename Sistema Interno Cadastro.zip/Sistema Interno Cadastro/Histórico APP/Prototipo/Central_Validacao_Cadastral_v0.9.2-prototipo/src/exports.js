(function (root, factory) {
  const U = typeof module === "object" && module.exports ? require("./utils.js") : root.CVCUtils;
  const Catalog = typeof module === "object" && module.exports ? require("./catalog.js") : root.CVCCatalog;
  const Config = typeof module === "object" && module.exports ? require("./config.js") : root.CVCConfig;
  const api = factory(root, U, Catalog, Config);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVCExports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (root, U, Catalog, Config) {
  "use strict";

  function summaryRows(state) {
    const summary = state.result.summary;
    return [
      { Indicador: "Aplicação", Valor: Config.APP_NAME },
      { Indicador: "Versão", Valor: Config.VERSION },
      { Indicador: "Arquivo de origem", Valor: state.file?.name || "" },
      { Indicador: "Aba processada", Valor: state.sheetName || "" },
      { Indicador: "Linha de cabeçalho", Valor: Number(state.headerRow) + 1 },
      { Indicador: "Gerado em", Valor: U.nowLabel() },
      { Indicador: "Registros processados", Valor: summary.total },
      { Indicador: "Registros consistentes", Valor: summary.consistent },
      { Indicador: "Aprovados com ressalvas", Valor: summary.withWarnings },
      { Indicador: "Registros inconsistentes", Valor: summary.invalid },
      { Indicador: "Taxa sem erros", Valor: U.formatPercent(summary.passRate, 1) },
      { Indicador: "Erros", Valor: summary.errorCount },
      { Indicador: "Alertas", Valor: summary.warningCount },
      { Indicador: "Campos mapeados", Valor: summary.mappedFields },
      { Indicador: "Regras selecionadas", Valor: summary.selectedRules },
      { Indicador: "Avaliações não aplicáveis", Valor: summary.skippedCount }
    ];
  }

  function treatmentRows(state, records) {
    const headers = U.uniqueHeaders(state.headers || []);
    const testedFields = Catalog.fields.filter((field) => state.mapping[field.id] != null && (state.selection[field.id] || []).length);
    const fieldsByColumn = new Map();
    testedFields.forEach((field) => {
      const column = Number(state.mapping[field.id]);
      if (!fieldsByColumn.has(column)) fieldsByColumn.set(column, []);
      fieldsByColumn.get(column).push(field);
    });
    const controlHeaders = ["RESULTADO GERAL", "TOTAL DE ERROS", "TOTAL DE ALERTAS", "CAMPOS COM ACHADOS", "AÇÃO DE TRATAMENTO", "RESPONSÁVEL PELO TRATAMENTO", "DATA DO TRATAMENTO", "OBSERVAÇÃO DO TRATAMENTO"];
    const outputHeaders = [];
    headers.forEach((header, column) => {
      outputHeaders.push(header);
      (fieldsByColumn.get(column) || []).forEach((field) => outputHeaders.push(`VALIDAÇÃO · ${field.label}`, `ACHADOS · ${field.label}`, `SUGESTÃO · ${field.label}`));
    });
    outputHeaders.push(...controlHeaders);
    return [outputHeaders, ...(records || state.result.records).map((record) => {
      const row = [];
      headers.forEach((_, column) => {
        row.push(record.source[column] ?? "");
        (fieldsByColumn.get(column) || []).forEach((field) => {
          const issues = record.issues.filter((item) => item.fieldId === field.id);
          const errors = issues.filter((item) => item.severity === "error").length;
          const warnings = issues.length - errors;
          const storedStatus = record.fieldResults?.[field.id];
          const status = typeof storedStatus === "string" ? storedStatus : storedStatus?.status || (errors ? Config.STATUS.FAIL : warnings ? Config.STATUS.WARNING : Config.STATUS.PASS);
          const details = issues.map((item) => `[${item.severity === "error" ? "ERRO" : "ALERTA"}] ${item.rule}: ${item.message}`).join(" | ");
          const suggestions = [...new Set(issues.filter((item) => item.suggestion).map((item) => item.suggestion))].join(" | ");
          row.push(status, details, suggestions);
        });
      });
      const fields = [...new Set(record.issues.map((item) => item.field))].join("; ");
      row.push(record.status, record.errors, record.warnings, fields, "", "", "", "");
      return row;
    })];
  }

  function issueRows(state, issues) {
    const matriculaByRow = new Map(state.result.records.map((record) => [record.rowNumber, record.matricula]));
    return (issues || state.result.issues).map((item) => ({
      "Matrícula Petros": matriculaByRow.get(item.rowNumber) || "",
      "Linha de Origem": item.rowNumber,
      Severidade: item.severity === "error" ? "Erro" : "Alerta",
      Grupo: item.group,
      Campo: item.field,
      Regra: item.rule,
      "Valor Original": item.value,
      "Valor Normalizado": item.normalized,
      Mensagem: item.message,
      "Sugestão de Tratamento": item.suggestion,
      "Status do Tratamento": "",
      Responsável: "",
      Observação: ""
    }));
  }

  function configRows(state) {
    const rows = [];
    Catalog.fields.forEach((field) => {
      if (state.mapping[field.id] == null) return;
      const column = Number(state.mapping[field.id]);
      const selected = new Set(state.selection[field.id] || []);
      field.rules.filter((rule) => selected.has(rule.id)).forEach((rule) => rows.push({
        Campo: field.label,
        "Coluna de Origem": state.headers[column] || U.columnName(column),
        "Número da Coluna": column + 1,
        Regra: rule.label,
        Severidade: rule.severity === "error" ? "Erro" : "Alerta",
        Peso: rule.weight,
        Dependências: (rule.requires || []).map((id) => Catalog.getField(id)?.label || id).join("; ") || "Nenhuma"
      }));
    });
    return rows;
  }

  function dictionaryRows(state) {
    return Catalog.fields.filter((field) => state.mapping[field.id] != null).map((field) => ({
      Campo: field.label,
      Grupo: field.group,
      Descrição: field.description,
      "Tipo de Dado": field.type,
      "Formato Esperado": field.expectedFormat,
      Obrigatoriedade: field.required,
      "Nulidade Permitida": field.nullable,
      Criticidade: field.criticality,
      "Sensibilidade LGPD": field.sensitivity,
      "Controles que Exigem Fonte Externa": field.externalRules.join("; ") || "Nenhum"
    }));
  }

  async function workbookBlob(state, records, issues) {
    if (!root.CVXlsx) throw new Error("Gerador local de Excel não foi carregado.");
    return root.CVXlsx.write({
      Tratamento: treatmentRows(state, records),
      Inconsistências: issueRows(state, issues),
      Resumo: summaryRows(state),
      Configuração: configRows(state),
      Dicionário: dictionaryRows(state)
    });
  }

  async function downloadWorkbook(state, mode) {
    const onlyIssues = mode === "issues";
    const records = onlyIssues ? state.result.records.filter((record) => record.issues.length) : state.result.records;
    const issues = onlyIssues ? records.flatMap((record) => record.issues) : state.result.issues;
    const blob = await workbookBlob(state, records, issues);
    const type = onlyIssues ? "INCONSISTENCIAS" : "TRATAMENTO_LOTE";
    U.downloadBlob(blob, `CVCAD_PETROS_${type}_${U.fileDateTime()}.xlsx`);
  }

  async function downloadTemplate(fieldIds) {
    if (!root.CVXlsx) throw new Error("Gerador local de Excel não foi carregado.");
    const requested = new Set(fieldIds?.length ? fieldIds : Catalog.fields.map((field) => field.id));
    requested.add(Config.MASTER_FIELD);
    const selectedFields = Catalog.fields.filter((field) => requested.has(field.id));
    const template = [selectedFields.map((field) => field.label), selectedFields.map((field) => {
      if (field.id === Config.MASTER_FIELD) return "000001";
      if (field.id === "cpf") return "52998224725";
      if (field.id === "data_nascimento") return "20/05/1980";
      if (field.id === "sexo") return "F";
      return "";
    })];
    const dictionary = selectedFields.map((field) => ({ Campo: field.label, Grupo: field.group, Descrição: field.description, "Formato Esperado": field.expectedFormat, Obrigatoriedade: field.required }));
    const blob = await root.CVXlsx.write({ Modelo: template, Dicionário: dictionary });
    U.downloadBlob(blob, `CVCAD_PETROS_MODELO_ENTRADA_${U.todayISO()}.xlsx`);
  }

  return { summaryRows, treatmentRows, issueRows, configRows, dictionaryRows, workbookBlob, downloadWorkbook, downloadTemplate };
});
