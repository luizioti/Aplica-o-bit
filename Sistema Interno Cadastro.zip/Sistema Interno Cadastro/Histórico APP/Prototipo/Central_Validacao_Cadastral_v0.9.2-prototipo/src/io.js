(function (root, factory) {
  const U = typeof module === "object" && module.exports ? require("./utils.js") : root.CVCUtils;
  const api = factory(root, U);
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVCIO = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (root, U) {
  "use strict";

  function detectDelimiter(content) {
    const sample = content.split(/\r?\n/).slice(0, 8).join("\n");
    const candidates = [";", "\t", ","];
    const counts = candidates.map((delimiter) => {
      let count = 0, quoted = false;
      for (let index = 0; index < sample.length; index += 1) {
        const char = sample[index];
        if (char === '"') quoted = !quoted;
        else if (!quoted && char === delimiter) count += 1;
      }
      return { delimiter, count };
    }).sort((a, b) => b.count - a.count);
    return counts[0].count ? counts[0].delimiter : ";";
  }

  function parseDelimited(content, delimiter) {
    const rows = [];
    let row = [], cell = "", quoted = false;
    const source = String(content || "").replace(/^\uFEFF/, "");
    for (let index = 0; index < source.length; index += 1) {
      const char = source[index];
      if (quoted) {
        if (char === '"' && source[index + 1] === '"') { cell += '"'; index += 1; }
        else if (char === '"') quoted = false;
        else cell += char;
      } else if (char === '"') quoted = true;
      else if (char === delimiter) { row.push(cell); cell = ""; }
      else if (char === "\n") { row.push(cell.replace(/\r$/, "")); rows.push(row); row = []; cell = ""; }
      else cell += char;
    }
    if (cell || row.length) { row.push(cell.replace(/\r$/, "")); rows.push(row); }
    while (rows.length && rows.at(-1).every(U.isBlank)) rows.pop();
    return rows;
  }

  async function read(file, onProgress) {
    const name = file?.name || "arquivo";
    if (/\.xlsx$/i.test(name)) {
      if (!root.CVXlsx) throw new Error("Leitor local de Excel não foi carregado.");
      const sheets = await root.CVXlsx.read(file, onProgress);
      return { type: "xlsx", sheets };
    }
    if (/\.(csv|txt)$/i.test(name)) {
      onProgress?.({ percent: 8, phase: "Lendo arquivo de texto", detail: name });
      const content = await U.readTextFile(file);
      const delimiter = detectDelimiter(content);
      onProgress?.({ percent: 55, phase: "Interpretando colunas", detail: delimiter === "\t" ? "Separador: tabulação" : `Separador: ${delimiter}` });
      const rows = parseDelimited(content, delimiter);
      onProgress?.({ percent: 100, phase: "Leitura concluída", detail: `${rows.length} linhas` });
      return { type: "csv", delimiter, sheets: { Dados: rows } };
    }
    throw new Error("Formato não suportado. Use um arquivo .xlsx, .csv ou .txt delimitado.");
  }

  return { detectDelimiter, parseDelimited, read };
});

