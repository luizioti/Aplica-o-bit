(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.CVCUtils = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  function text(value) { return value == null ? "" : String(value); }
  function isBlank(value) { return text(value).trim() === ""; }
  function normalizeText(value) {
    return text(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toUpperCase();
  }
  function normalizeHeader(value) {
    return normalizeText(value).replace(/[^A-Z0-9]+/g, " ").replace(/\s+/g, " ").trim();
  }
  function normalizeSpaces(value) { return text(value).trim().replace(/\s+/g, " "); }
  function normalizeMatricula(value) { return text(value).trim().replace(/\s+/g, ""); }
  function digits(value) { return text(value).replace(/\D/g, ""); }
  function escapeHtml(value) {
    return text(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }
  function slug(value) {
    return normalizeText(value).replace(/[^A-Z0-9]+/g, "_").replace(/^_|_$/g, "").toLowerCase();
  }
  function excelSerialToDate(serial) {
    const value = Number(text(serial).replace(",", "."));
    if (!Number.isFinite(value) || value < 1 || value > 100000) return null;
    const date = new Date(Math.round((value - 25569) * 86400 * 1000));
    return Number.isNaN(date.getTime()) ? null : date;
  }
  function parseDate(value) {
    if (value instanceof Date && !Number.isNaN(value.getTime())) return new Date(value.getTime());
    const raw = text(value).trim();
    if (!raw) return null;
    if (/^\d+(?:[.,]\d+)?$/.test(raw)) {
      if (/^\d{4}$/.test(raw)) return null;
      const serial = Number(raw.replace(",", "."));
      if (serial > 20000) return excelSerialToDate(serial);
    }
    let match = raw.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})$/);
    if (match) {
      const date = new Date(Date.UTC(Number(match[3]), Number(match[2]) - 1, Number(match[1])));
      if (date.getUTCDate() === Number(match[1]) && date.getUTCMonth() === Number(match[2]) - 1 && date.getUTCFullYear() === Number(match[3])) return date;
      return null;
    }
    match = raw.match(/^(\d{4})[\/.\-](\d{1,2})[\/.\-](\d{1,2})(?:[T\s].*)?$/);
    if (match) {
      const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
      if (date.getUTCDate() === Number(match[3]) && date.getUTCMonth() === Number(match[2]) - 1 && date.getUTCFullYear() === Number(match[1])) return date;
    }
    return null;
  }
  function dateToISO(value) {
    const date = value instanceof Date ? value : parseDate(value);
    return date && !Number.isNaN(date.getTime()) ? date.toISOString().slice(0, 10) : "";
  }
  function dateToBR(value) {
    const date = value instanceof Date ? value : parseDate(value);
    if (!date || Number.isNaN(date.getTime())) return "";
    const day = String(date.getUTCDate()).padStart(2, "0");
    const month = String(date.getUTCMonth() + 1).padStart(2, "0");
    return `${day}/${month}/${date.getUTCFullYear()}`;
  }
  function formatDate(value) {
    return dateToBR(value) || "—";
  }
  function ageAt(birth, reference) {
    const start = parseDate(birth), end = reference ? parseDate(reference) : new Date();
    if (!start || !end || end < start) return null;
    let age = end.getUTCFullYear() - start.getUTCFullYear();
    if (end.getUTCMonth() < start.getUTCMonth() || (end.getUTCMonth() === start.getUTCMonth() && end.getUTCDate() < start.getUTCDate())) age -= 1;
    return age;
  }
  function formatNumber(value, digitsCount) {
    return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: digitsCount == null ? 0 : digitsCount }).format(Number(value) || 0);
  }
  function formatPercent(value, digitsCount) {
    return `${formatNumber((Number(value) || 0) * 100, digitsCount == null ? 1 : digitsCount)}%`;
  }
  function todayISO() { return new Date().toISOString().slice(0, 10); }
  function nowLabel() { return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" }).format(new Date()); }
  function fileDateTime() { return new Date().toISOString().replace(/[:T]/g, "-").slice(0, 16); }
  function safeFilename(value) { return text(value).replace(/[\\/:*?"<>|]+/g, "-").replace(/\s+/g, "_"); }
  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
  function yieldToMain() { return new Promise((resolve) => setTimeout(resolve, 0)); }
  function debounce(fn, delay) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay || 180);
    };
  }
  function columnName(index) {
    let value = Number(index), output = "";
    while (value >= 0) { output = String.fromCharCode((value % 26) + 65) + output; value = Math.floor(value / 26) - 1; }
    return output;
  }
  function uniqueHeaders(headers) {
    const used = {};
    return headers.map((header, index) => {
      const base = normalizeSpaces(header) || `Coluna ${columnName(index)}`;
      used[base] = (used[base] || 0) + 1;
      return used[base] === 1 ? base : `${base} (${used[base]})`;
    });
  }
  function readTextFile(file) {
    return file.arrayBuffer().then((buffer) => {
      let decoded = new TextDecoder("utf-8").decode(buffer).replace(/^\uFEFF/, "");
      if (decoded.includes("�")) decoded = new TextDecoder("windows-1252").decode(buffer).replace(/^\uFEFF/, "");
      return decoded;
    });
  }
  function maskCpf(value) {
    const raw = digits(value);
    return raw.length === 11 ? `${raw.slice(0, 3)}.${raw.slice(3, 6)}.${raw.slice(6, 9)}-${raw.slice(9)}` : text(value);
  }
  function paginationModel(totalItems, requestedPage, requestedPageSize, fallbackSize) {
    const total = Math.max(0, Number(totalItems) || 0);
    const showAll = requestedPageSize === "all";
    const pageSize = showAll ? Math.max(total, 1) : Math.max(1, Number(requestedPageSize) || Number(fallbackSize) || 20);
    const pageCount = showAll ? 1 : Math.max(1, Math.ceil(total / pageSize));
    const page = Math.max(1, Math.min(Number(requestedPage) || 1, pageCount));
    const start = showAll ? 0 : (page - 1) * pageSize;
    return { total, showAll, pageSize, pageCount, page, start, end: Math.min(start + pageSize, total) };
  }
  function pageTokens(current, total) {
    const pageCount = Math.max(1, Number(total) || 1);
    const active = Math.max(1, Math.min(Number(current) || 1, pageCount));
    if (pageCount <= 7) return Array.from({ length: pageCount }, (_, index) => index + 1);
    const pages = new Set([1, pageCount]);
    for (let page = active - 2; page <= active + 2; page += 1) if (page > 1 && page < pageCount) pages.add(page);
    const ordered = [...pages].sort((a, b) => a - b);
    const tokens = [];
    ordered.forEach((page, index) => {
      if (index && page - ordered[index - 1] > 1) tokens.push("…");
      tokens.push(page);
    });
    return tokens;
  }

  return {
    text, isBlank, normalizeText, normalizeHeader, normalizeSpaces, normalizeMatricula, digits,
    escapeHtml, slug, excelSerialToDate, parseDate, dateToISO, dateToBR, formatDate, ageAt, formatNumber,
    formatPercent, todayISO, nowLabel, fileDateTime, safeFilename, downloadBlob, yieldToMain,
    debounce, columnName, uniqueHeaders, readTextFile, maskCpf, paginationModel, pageTokens
  };
});
