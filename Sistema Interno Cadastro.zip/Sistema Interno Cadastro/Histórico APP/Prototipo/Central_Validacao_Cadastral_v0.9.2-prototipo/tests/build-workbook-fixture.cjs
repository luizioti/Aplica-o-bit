const { mkdirSync, writeFileSync } = require("node:fs");
const { dirname, resolve } = require("node:path");

global.JSZip = require("../vendor/jszip.min.js");
global.CVXlsx = require("../src/xlsx.js");

const Catalog = require("../src/catalog.js");
const Engine = require("../src/engine.js");
const Exports = require("../src/exports.js");

(async () => {
  const headers = ["Matrícula Petros", "CPF", "Nome"];
  const rows = [
    ["000001", "52998224725", "Ana Maria"],
    ["000002", "11111111111"],
    ["000003", "52998224724", "Carlos 9 Silva"]
  ];
  const mapping = Engine.autoMap(headers);
  const all = Catalog.allRuleSelection();
  const selection = Object.fromEntries(Catalog.fields.filter((field) => mapping[field.id] != null).map((field) => [field.id, all[field.id]]));
  const result = await Engine.process({ rows, mapping, selection, firstDataRow: 2 });
  const state = { file: { name: "Base_QA.xlsx" }, sheetName: "Dados", headerRow: 0, headers, mapping, selection, result };
  const blob = await Exports.workbookBlob(state);
  const output = resolve(process.argv[2] || "tmp/spreadsheets/Tratamento_QA_v0.9.2.xlsx");
  mkdirSync(dirname(output), { recursive: true });
  writeFileSync(output, Buffer.from(await blob.arrayBuffer()));
  console.log(output);
})().catch((error) => { console.error(error); process.exit(1); });
