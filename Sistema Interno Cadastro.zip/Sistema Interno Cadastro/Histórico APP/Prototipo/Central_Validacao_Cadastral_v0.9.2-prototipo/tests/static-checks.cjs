const { readFileSync, readdirSync, statSync, existsSync } = require("node:fs");
const { join, resolve, relative } = require("node:path");
const assert = require("node:assert/strict");

const root = resolve(__dirname, "..");
const failures = [];
const forbidden = [/\bfetch\s*\(/, /XMLHttpRequest/, /new\s+WebSocket/, /EventSource\s*\(/, /sendBeacon\s*\(/, /<script[^>]+src=["'](?:https?:)?\/\//i, /<link[^>]+href=["'](?:https?:)?\/\//i, /\bcdn\./i];
function walk(dir) {
  for (const name of readdirSync(dir)) {
    const file = join(dir, name);
    const stat = statSync(file);
    if (stat.isDirectory()) { if (name !== "vendor") walk(file); continue; }
    if (!/\.(?:html|js|css|json|md)$/i.test(name)) continue;
    const content = readFileSync(file, "utf8").replace(/http:\/\/schemas\.(?:openxmlformats|microsoft)\.org\/[A-Za-z0-9_./-]+/g, "OOXML_NAMESPACE");
    forbidden.forEach((pattern) => { if (pattern.test(content)) failures.push(`${relative(root, file)}: ${pattern}`); });
  }
}
walk(root);
if (failures.length) throw new Error("Dependência ou chamada externa encontrada:\n" + failures.join("\n"));

const indexPath = join(root, "index.html");
const html = readFileSync(indexPath, "utf8");
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map((match) => match[1]);
const duplicates = ids.filter((id, index) => ids.indexOf(id) !== index);
assert.deepEqual(duplicates, [], "IDs HTML devem ser únicos");
["fileInput", "mappingRows", "ruleCards", "processButton", "resultTableBody", "pageSizeSelect", "pageButtons", "reportRoot", "busyOverlay"].forEach((id) => assert.ok(ids.includes(id), `ID obrigatório ausente: ${id}`));

const localRefs = [...html.matchAll(/(?:src|href)="([^"]+)"/g)].map((match) => match[1]).filter((item) => !item.startsWith("#"));
localRefs.forEach((reference) => assert.ok(existsSync(join(root, reference)), `Referência local ausente: ${reference}`));

const version = readFileSync(join(root, "versao.txt"), "utf8").trim();
assert.ok(readFileSync(join(root, "src", "config.js"), "utf8").includes(`VERSION: "${version}"`), "versao.txt e config.js devem coincidir");
console.log(`✓ Estrutura estática aprovada: ${ids.length} IDs únicos, ${localRefs.length} referências locais e nenhuma chamada externa.`);
