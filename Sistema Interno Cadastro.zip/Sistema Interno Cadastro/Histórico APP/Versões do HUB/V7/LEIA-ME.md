# HUB Cadastro v9

Portal local do Setor de Cadastro. Não usa servidor: o HTML, a configuração e a Base de Apoio funcionam juntos na mesma pasta.

Na Central de Aplicações, **Abrir** inicia a ferramenta diretamente em uma nova aba. **Detalhes** abre a ficha completa com documentação, ambiente, versão, segurança e histórico.

## Arquivos essenciais

- **HUB Cadastro v9.html** — aplicação principal;
- **hub-cadastro-config.js** — fonte compartilhada carregada automaticamente pelo HUB;
- **hub-cadastro-config.json** — espelho legível, backup e arquivo de importação;
- **Base de Apoio** — PDFs, Word, Excel, manuais e outros conteúdos exibidos na Central de Apoio.

Mantenha o nome **hub-cadastro-config.js**. É esse arquivo que permite que cada pessoa abra o HUB e receba a configuração publicada sem selecionar nada.

## Publicar alterações

1. Abra o HTML e entre no **Admin**.
2. Edite Aplicações ou a Central de Apoio.
3. Clique em **Publicar para todos**.
4. No primeiro uso administrativo, selecione esta pasta — a mesma que contém o HTML.

O HUB grava e confere **hub-cadastro-config.json** e **hub-cadastro-config.js** em conjunto. Nos próximos usos, o navegador tenta reutilizar a autorização.

## Atualizar a Base de Apoio

1. Copie os arquivos para as subpastas de **Base de Apoio**.
2. No Admin, abra **Central de Apoio** e clique em **Indexar pasta de apoio**.
3. Revise o catálogo e clique em **Publicar para todos**.

Somente o administrador autoriza a pasta. Quem consulta o HUB recebe o índice pelo arquivo JS e não precisa selecionar documentos ou diretórios.
