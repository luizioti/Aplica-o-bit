window.HUB_CADASTRO_CONFIG = {
  "schemaVersion": 2,
  "revision": 3,
  "updatedAt": "2026-09-02T15:26:02.724Z",
  "updatedBy": "luiz",
  "publicationId": "321e1031-34d0-48cf-9c0d-02f787dfa8a4",
  "apps": [
    {
      "status": "available",
      "accent": "#00806f",
      "accentSoft": "#e6f6f3",
      "icon": "document",
      "heroImage": "",
      "version": "1.0.0",
      "environment": "Produção",
      "lastUpdate": "12/05/2025",
      "security": "Conforme",
      "owner": "",
      "docs": [
        {
          "title": "Manual do Usuário",
          "subtitle": "Guia completo de utilização do sistema",
          "file": "Manual do Usuário.docx"
        },
        {
          "title": "Política de Acesso",
          "subtitle": "Regras e permissões de acesso",
          "file": "Política de Acesso.docx"
        },
        {
          "title": "FAQ",
          "subtitle": "Perguntas frequentes",
          "file": "FAQ.docx"
        },
        {
          "title": "Template Padrão",
          "subtitle": "Modelo oficial de carta de isenção",
          "file": "Template Padrão.docx"
        }
      ],
      "updates": [
        {
          "date": "12/05/2025",
          "type": "good",
          "label": "Melhoria",
          "text": "Ajustes na geração de PDF e desempenho"
        },
        {
          "date": "28/04/2025",
          "type": "fix",
          "label": "Correção",
          "text": "Correção de validações no template padrão"
        },
        {
          "date": "10/04/2025",
          "type": "info",
          "label": "Atualização",
          "text": "Nova versão do template de carta"
        }
      ],
      "blurName": false,
      "id": "gerador-carta-isencao",
      "name": "Gerador de Carta de Isenção",
      "description": "Geração padronizada de cartas de isenção em PDF, com templates validados e controle de versões.",
      "path": "F:\\DADOS\\CADASTRO\\NÚCLEO ANALYTICS\\Sistema Interno Cadastro\\Gerador de Carta Isenção\\index.html",
      "metaFile": "./Gerador de Carta Isenção/versao.txt",
      "docsBase": "./Gerador de Carta Isenção/Documentos/"
    },
    {
      "status": "available",
      "accent": "#0891b2",
      "accentSoft": "#e6f7fb",
      "icon": "calendar",
      "heroImage": "",
      "version": "1.1.0",
      "environment": "Produção",
      "lastUpdate": "14/07/2026",
      "security": "Produção",
      "owner": "",
      "docs": [],
      "updates": [
        {
          "date": "17/06/2026",
          "type": "good",
          "label": "Melhoria",
          "text": "Ajustes de visualização do calendário"
        },
        {
          "date": "13/06/2026",
          "type": "info",
          "label": "Atualização",
          "text": "Inclusão de filtros por equipe"
        }
      ],
      "blurName": false,
      "id": "planejamento-ferias",
      "name": "Planejamento de Férias",
      "description": "Organização e acompanhamento do planejamento de férias da equipe.",
      "path": "F:\\DADOS\\CADASTRO\\NÚCLEO ANALYTICS\\Sistema Interno Cadastro\\calendario-ferias\\Férias.html",
      "metaFile": "./calendario-ferias/versao.txt",
      "docsBase": "./calendario-ferias/Documentos/"
    },
    {
      "status": "available",
      "accent": "#b45309",
      "accentSoft": "#fff4e6",
      "icon": "phone",
      "heroImage": "",
      "version": "Produção",
      "environment": "Produção",
      "lastUpdate": "25/06/2026",
      "security": "Pendente",
      "owner": "",
      "docs": [
        {
          "title": "Roteiro de Atendimento",
          "subtitle": "Script previsto para contatos",
          "file": "Roteiro de Atendimento.docx"
        },
        {
          "title": "Critérios de Elegibilidade",
          "subtitle": "Público e priorização das ações",
          "file": "Critérios de Elegibilidade.docx"
        }
      ],
      "updates": [
        {
          "date": "Planejado",
          "type": "info",
          "label": "Backlog",
          "text": "Módulo aguardando definição de fluxo"
        }
      ],
      "blurName": false,
      "id": "contato-ativo",
      "name": "Contato Ativo",
      "description": "Gestão e acompanhamento das ações de contato ativo com participantes.",
      "path": "https://fundacaopetros.sharepoint.com/:l:/s/CadastroAnalytics/JACerq9hYMgpTJd24-mzygjCAQNdMWCm8jQs5UhU1hwqIyk?nav=OWEwODVlMTMtMDc3NC00NzMwLTk4YTctZDYwYTQ3NDE4YTk4",
      "metaFile": "./Contato Ativo/versao.txt",
      "docsBase": "./Contato Ativo/Documentos/"
    },
    {
      "status": "available",
      "accent": "#00806f",
      "accentSoft": "#e6f6f3",
      "icon": "idcard",
      "heroImage": "",
      "version": "1.0.0",
      "environment": "Produção",
      "lastUpdate": "25/06/2026",
      "security": "",
      "owner": "",
      "docs": [],
      "updates": [
        {
          "date": "Atual",
          "type": "info",
          "label": "Novo",
          "text": "Aplicação cadastrada pelo Admin do Hub"
        }
      ],
      "blurName": false,
      "id": "app-1782395822619",
      "name": "Forms Priorização CSP",
      "description": "Formulário utilizado para realizar a priorização de CSP's da Squad Cadastro e Atendimento",
      "path": "https://forms.cloud.microsoft/r/1UTheDcTwD",
      "docsBase": ""
    },
    {
      "status": "available",
      "accent": "#00806f",
      "accentSoft": "#e6f6f3",
      "icon": "checklist",
      "heroImage": "",
      "version": "1.0.0",
      "environment": "Produção",
      "lastUpdate": "30/06/2026",
      "security": "",
      "owner": "",
      "docs": [],
      "updates": [
        {
          "date": "Atual",
          "type": "info",
          "label": "Novo",
          "text": "Aplicação cadastrada pelo Admin do Hub"
        }
      ],
      "blurName": false,
      "id": "app-1782846045966",
      "name": "DE e DSI",
      "description": "Descreva a finalidade da aplicação.",
      "path": "./DEDSI/index.html",
      "docsBase": ""
    },
    {
      "status": "available",
      "accent": "#ffffff",
      "accentSoft": "#e6f4f1",
      "icon": "scale",
      "heroImage": "",
      "version": "1.0.1",
      "environment": "Produção",
      "lastUpdate": "17/08/2026",
      "security": "",
      "owner": "",
      "docs": [],
      "updates": [
        {
          "date": "Atual",
          "type": "info",
          "label": "Novo",
          "text": "Aplicação cadastrada pelo Admin do Hub"
        }
      ],
      "blurName": false,
      "id": "app-1786969958552",
      "name": "Recadastramento 2026",
      "description": "Clique e acesse ao Hub com as aplicações do Recadastramento de 2026",
      "path": "file:///F:/DADOS/CADASTRO/N%C3%9ACLEO%20ANALYTICS/Sistema%20Interno%20Cadastro/HUB%20Recad/index.html",
      "docsBase": ""
    },
    {
      "status": "available",
      "accent": "#17847b",
      "accentSoft": "#e6f4f1",
      "icon": "archive",
      "heroImage": "",
      "version": "1.0.0",
      "environment": "Desenvolvimento",
      "lastUpdate": "",
      "security": "",
      "owner": "",
      "docs": [],
      "updates": [
        {
          "date": "Atual",
          "type": "info",
          "label": "Novo",
          "text": "Aplicação cadastrada pelo Admin do Hub"
        }
      ],
      "blurName": false,
      "id": "app-1786987223884",
      "name": "Registro Fisico",
      "description": "Aplicação para controlar os registros fisicos",
      "path": "F:\\DADOS\\CADASTRO\\NÚCLEO ANALYTICS\\Sistema Interno Cadastro\\Histórico APP\\Gestão de Documentos Físicos\\index.html",
      "docsBase": ""
    }
  ],
  "agents": [
    {
      "id": "agente-planos",
      "name": "Agente de Planos",
      "subtitle": "Assistente previdenciário",
      "url": "https://teams.microsoft.com/l/app/f6405520-7907-4464-8f6e-9889e2fb7d8f?source=app-profile-card&templateInstanceId=7566dbf1-c20b-4fed-89be-a43f335d68fe&environment=Default-84c09349-8a90-4f46-b88a-2a034acb8b25&threadId=19%3A9b3eec44-42a0-4616-9a72-c7c77f8eda63_ec568c3f-ae35-4fb9-9cca-f0599babdd97%40unq.gbl.spaces",
      "icon": "bot",
      "variant": "dark"
    },
    {
      "id": "calculadora-tvp",
      "name": "Calculadora de TVP",
      "subtitle": "Envie o documento e calcule",
      "url": "https://teams.microsoft.com/l/app/?titleId=T_ef70940d-8cad-49db-42f3-20784b3ff43c",
      "icon": "calculator",
      "variant": "light"
    },
    {
      "id": "agente-1782935924441",
      "name": "Protocolo",
      "subtitle": "Localize a documentação enviada",
      "url": "https://teams.microsoft.com/l/app/?titleId=T_05677336-d4bf-838b-a474-0ec6d9177108",
      "icon": "archive",
      "variant": "dark"
    }
  ],
  "support": {
    "title": "Central de Apoio",
    "folderBase": "./Base de Apoio/",
    "updatedAt": "2026-09-02T15:26:02.724Z",
    "resources": [
      {
        "id": "arquivo-tabelas-cnpbs-xlsx",
        "title": "CNPBs",
        "description": "Arquivo disponível na Base de Apoio do Cadastro.",
        "type": "document",
        "category": "Tabelas",
        "tags": [
          "XLSX",
          "Tabelas"
        ],
        "path": "./Base de Apoio/Tabelas/CNPBs.xlsx",
        "owner": "",
        "relatedAppId": "",
        "featured": false,
        "accent": "#17847b",
        "updatedAt": "2026-08-21T17:41:32.486Z",
        "source": "folder",
        "columns": [],
        "rows": []
      }
    ]
  }
};
