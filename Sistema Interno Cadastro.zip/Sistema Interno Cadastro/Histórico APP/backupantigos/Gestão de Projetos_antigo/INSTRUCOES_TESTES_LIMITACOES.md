# Gestão de Projetos Internos

## Como usar
1. Abra `index.html` em um navegador Chromium moderno.
2. Clique em "Criar nova base" ou "Selecionar outra base".
3. Primeiro login: `luiz.ioti@petros.com.br` / `123456`.
4. Troque a senha quando solicitado e salve a base.

## Testes executados automaticamente neste build
- Geração do `index.html` sem referencias a CDN.
- Geração do `Base_Gestao_Projetos.xlsx` com abas obrigatórias.
- Validação de que o HTML contem rotinas de PBKDF2, File System Access API, IndexedDB, salvamento XLSX e ausência de fetch/XMLHttpRequest/WebSocket/EventSource/sendBeacon.

## Limitações técnicas
- A File System Access API depende da permissão do navegador; quando indisponivel, o app exporta uma cópia atualizada.
- O bloqueio de concorrência e por comparacao de versão antes de salvar quando o arquivo original pode ser relido.
- O leitor/gravador XLSX embutido preserva as abas e colunas do esquema da aplicação, mas não preserva recursos avançados adicionados manualmente no Excel fora desse modelo.
