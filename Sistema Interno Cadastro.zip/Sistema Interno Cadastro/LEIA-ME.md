# HUB Cadastro v14

## Como abrir e levar para o trabalho

Abra **HUB Cadastro v14.html**. Os estilos e scripts de interface já estão dentro do HTML: não é necessário transportar os antigos arquivos `hub-v13-*.css` ou `hub-v13-*.js`.

Mantenha junto do HTML:

- `assets` — imagens locais do cabeçalho e logos;
- `hub-cadastro-config.json` e `hub-cadastro-config.js` — sua configuração compartilhada;
- `Base de Apoio` — seus documentos, se os caminhos configurados apontarem para essa pasta.

**IMPORTANTE: no trabalho, preserve o JSON/JS já configurado e os documentos existentes.** A configuração deste pacote é uma cópia sem alterações da usada localmente para validação. Não é obrigatório usar essa cópia nem substituir a sua. Não foram criados campos obrigatórios novos. Não substitua os arquivos de configuração por versões de exemplo ao atualizar o HTML.

Se os apontamentos usam caminhos relativos, mantenha a mesma posição da pasta do HUB em relação aos arquivos. Prefira colocar o novo HTML na pasta atual do HUB junto de `assets`, sem mover seu JSON/JS ou documentos. O fluxo de publicação offline e a senha do Admin são os mesmos. Não há servidor, GIF, vídeo nem bibliotecas novas.

## O que mudou

### Atalhos na barra superior

- **Documentos rápidos** e **Links úteis** têm ícone e nome. Ao passar o mouse ou focar com o teclado, uma prévia mostra até cinco atalhos clicáveis. O clique no botão abre a página completa; seta para baixo acessa os itens e Esc fecha a prévia. Em dispositivos de toque, clique para abrir a página.
- A prévia de documentos começa pela ordem do Admin. Conforme os arquivos são abertos neste navegador, os mais consultados localmente têm prioridade. Essa contagem não é uma estatística compartilhada de todo o setor.
- A página **Links úteis** reúne todos os links publicados, tem pesquisa, ordem alfabética e favoritos primeiro. Estrelas, ordenação e contagens de acesso ficam apenas no navegador, sem acrescentar campos ao JSON compartilhado.
- Os ícones de sino e grade foram retirados dessa barra. Notícias permanecem no quadro lateral; Central de Apoio está no rodapé da prévia de Documentos, e Ajuda/Agentes também podem ser acessados pela busca geral (Ctrl+K).
- O botão de tema indica a **próxima opção**: nuvem para mudar de Manhã para Tarde, lua para mudar de Tarde para Noite e sol para retornar a Manhã. No tema Noite, os agentes ficam dourados sem alterar seu estilo salvo, as estrelas não selecionadas têm fundo cinza-claro e os botões usam hover claro com texto preto, sem azul.
- Links úteis permanece na barra superior e na página completa, sem quadro duplicado na lateral. Em telas de computador, o catálogo e a coluna de Próximos eventos + Previdência em pauta têm a mesma altura total; em telas pequenas seguem empilhados.

### Ajustes de paleta e navegação

- Tarde recupera o azul original do HUB, sem a tonalidade verde adicionada na revisão anterior. Noite usa quadros grafite, textos claros e ícones/detalhes dourados, inclusive nos painéis laterais.
- O calendário fica alinhado ao topo do quadro de eventos; os próximos eventos e a identificação da última publicação permanecem à esquerda.
- No Admin, abra **Personalizar títulos** abaixo da lista de seções para renomear os menus e seus respectivos quadros. Deixe um campo em branco para voltar ao padrão e use **Publicar para todos** para compartilhar. Os nomes são opcionais: apenas quando personalizados é salvo o pequeno objeto `portal.labels`; JSONs antigos continuam funcionando, sem migrar ou substituir os apontamentos.
- Documentos rápidos usa um ícone de documento no cabeçalho. O retorno **Voltar ao início** fica acima do título, com uma seta, separado da pesquisa.

- **Aplicações do Cadastro:** cards, lista e nova opção compacta. Apenas o seletor de visualização permanece no catálogo; favoritos, Abrir e Detalhes continuam funcionando. A busca geral fica centralizada no cabeçalho.
- **Próximos eventos:** coluna auxiliar, acima de Previdência em pauta. Lista dos próximos três à esquerda, calendário marcado à direita e última publicação com data/hora e responsável. Clique nas datas para consultar os títulos e navegue entre os meses pelas setas. Eventos encerrados/cancelados não entram na lista futura.
- **Documentos rápidos:** botão de pasta no cabeçalho e item no menu abrem uma página própria do HUB com os documentos cadastrados, busca e retorno às aplicações. Os arquivos continuam abrindo em uma nova aba.
- **Agentes:** canto inferior esquerdo, expandindo ao passar o mouse ou focar com o teclado. Estilos claro/escuro respeitam o Admin. A edição de cada agente agora pode ser recolhida, sem descartar campos.
- **Aparência:** botão alterna Manhã (claro), Tarde (azul petróleo/verde) e Noite (preto suave/dourado/branco).
- **Posição dos painéis:** botão ao lado do tema alterna esquerda/direita. Em telas estreitas, os painéis ficam abaixo das aplicações para manter a leitura.
- O logo abre o site da Petros em nova aba.

Tema e posição são salvos **neste navegador/perfil**, não no JSON compartilhado. Limpar os dados do navegador ou usar outro perfil redefine essas preferências. Recarregue com **Ctrl+F5** depois de atualizar; publique ou exporte rascunhos antes de fechar uma sessão de edição.

## Verificação

Código validado com testes de sintaxe, navegação, temas, preferências locais, calendário, favoritos e publicação compartilhada em ambiente simulado. Os arquivos JSON/JS deste pacote são idênticos aos anteriores. As notícias continuam dependentes de internet e das permissões das fontes/rede corporativa. A validação visual no seu navegador e monitor deve ser feita antes da publicação no Git.
