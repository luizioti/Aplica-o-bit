# Calendário de Férias da Equipe

Aplicação web corporativa para planejar, acompanhar e visualizar férias de colaboradores entre junho de 2026 e dezembro de 2028.

O sistema substitui a planilha mensal em que cada linha representa um colaborador e cada coluna representa um dia. A versão local usa IndexedDB para desenvolvimento, demonstração e contingência. A integração corporativa está preparada para Microsoft Graph com Excel hospedado no OneDrive ou SharePoint.

## Tecnologias

- HTML5
- CSS3 responsivo
- JavaScript modular sem framework pesado
- IndexedDB no modo local
- Microsoft Graph e MSAL no modo corporativo
- Exportações em JSON, CSV e planilha XML compatível com Excel

## Estrutura

```text
calendario-ferias/
├── index.html
├── config.example.js
├── config.js
├── README.md
├── .gitignore
├── assets/
│   ├── css/
│   │   ├── styles.css
│   │   └── responsive.css
│   ├── js/
│   │   ├── app.js
│   │   ├── calendar.js
│   │   ├── employees.js
│   │   ├── vacations.js
│   │   ├── holidays.js
│   │   ├── reports.js
│   │   ├── validation.js
│   │   ├── utils.js
│   │   └── data/
│   │       ├── data-provider.js
│   │       ├── local-provider.js
│   │       └── graph-excel-provider.js
│   ├── icons/
│   └── vendor/
├── docs/
│   ├── CONFIGURACAO_MICROSOFT_GRAPH.md
│   ├── ESTRUTURA_EXCEL.md
│   └── TESTES_EXECUTADOS.md
├── excel/
│   └── Modelo_Calendario_Ferias.xlsx
├── tests/
│   └── run-tests.mjs
└── tools/
    └── build-modelo-excel.mjs
```

`config.js` foi criado apenas com modo local para evitar erro de carregamento. Ele está no `.gitignore` e deve ser substituído por uma configuração corporativa fora do controle de versão.

## Como executar em modo local

Abra um terminal na pasta `calendario-ferias` e execute um servidor estático:

```powershell
python -m http.server 8080
```

Depois acesse:

```text
http://localhost:8080
```

O primeiro carregamento cria dados de demonstração no IndexedDB. O aviso abaixo confirma que a sincronização corporativa não está ativa:

```text
Modo local: os dados ainda não estão sincronizados com o Excel corporativo.
```

## Funcionalidades locais

- Cadastro, edição e inativação de colaboradores.
- Cadastro, edição, duplicação, cancelamento e exclusão local de férias.
- Cadastro, edição, inativação, exclusão, importação CSV e exportação CSV de feriados.
- Calendário mensal de junho de 2026 a dezembro de 2028.
- Fevereiro de 2028 com 29 dias.
- Colunas fixas para colaborador e equipe/cargo.
- Totais mensais e anuais no final da linha.
- Cálculo de dias corridos e dias úteis.
- Alerta gerencial para ausências simultâneas acima do limite configurado.
- Filtros combinados no calendário.
- Relatórios por colaborador, dia, status, concentração mensal, conflitos e colaboradores sem férias.
- Backup completo em JSON e restauração em modo local.
- Exportação de calendário e relações em formato compatível com Excel.
- Auditoria de operações principais.

## Como configurar o Excel

Use o arquivo:

```text
excel/Modelo_Calendario_Ferias.xlsx
```

Ele contém as abas e tabelas estruturadas:

- `Colaboradores` / `tbColaboradores`
- `Ferias` / `tbFerias`
- `Feriados` / `tbFeriados`
- `Configuracoes` / `tbConfiguracoes`
- `Auditoria` / `tbAuditoria`

Consulte `docs/ESTRUTURA_EXCEL.md` antes de alterar as colunas.

## Como configurar o Microsoft Graph

1. Copie `config.example.js` para `config.js`.
2. Altere `dataProvider` para `"graph"`.
3. Informe `tenantId`, `clientId`, `siteId`, `driveId` e `itemId`.
4. Inclua a biblioteca oficial MSAL no ambiente corporativo.
5. Hospede o app em HTTPS ou origem autorizada no Entra ID.

Detalhes completos estão em `docs/CONFIGURACAO_MICROSOFT_GRAPH.md`.

## Registro no Microsoft Entra ID

Crie um registro de aplicativo do tipo SPA. Configure a Redirect URI com a URL em que o app será hospedado. Não configure Client Secret para o navegador.

Permissões delegadas sugeridas:

- `User.Read`
- `Files.ReadWrite.All`
- `Sites.ReadWrite.All`

Em ambientes mais restritos, prefira permissões equivalentes com escopo limitado ao site/drive por política administrativa.

## Hospedagem

A aplicação é estática e pode ser publicada em:

- SharePoint como arquivos estáticos.
- Servidor interno IIS, Nginx ou Apache.
- Ambiente corporativo com HTTPS e acesso ao Microsoft Graph.

Evite `file://`, pois módulos ES e autenticação Microsoft exigem uma origem HTTP/HTTPS.

## Backup e restauração

No modo local, use a aba `Relatórios`:

- `Backup JSON` exporta todos os dados.
- `Restaurar JSON` substitui os dados locais atuais após confirmação.

No modo Graph, a restauração direta é bloqueada por segurança. Importe dados no Excel modelo com validação administrativa.

## Solução de problemas

- Aviso de modo local: o `config.js` não está configurado para Graph ou a autenticação falhou.
- Erro de sessão Microsoft expirada: clique em `Atualizar dados` para autenticar novamente.
- Dados inválidos no Excel: confira nomes das tabelas, colunas e datas ISO em `YYYY-MM-DD`.
- Exportação abre com aviso do Excel: os arquivos `.xls` gerados pela interface usam XML Spreadsheet 2003 compatível com Excel.
- Feriado não aparece no calendário: confirme se está ativo e dentro do período permitido.
- Férias não salvam: verifique colaborador ativo, intervalo permitido e sobreposição.

## Segurança

- Não há Client Secret no navegador.
- Tokens não são armazenados manualmente pela aplicação.
- Textos são inseridos na tela com `textContent`, reduzindo risco de injeção de HTML.
- `config.js` está ignorado pelo Git.
- Modo local usa IndexedDB, não `localStorage`, como fonte principal.
