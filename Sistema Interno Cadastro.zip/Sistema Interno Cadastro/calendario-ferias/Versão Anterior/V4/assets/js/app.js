import { renderCalendar, exportCalendar } from "./calendar.js";
import { renderEmployeeList, renderEmployeeOptions, resetEmployeeForm, saveEmployeeFromForm } from "./employees.js";
import { exportHolidaysCsv, exportHolidaysExcel, importHolidaysCsv, renderHolidayList, resetHolidayForm, saveHolidayFromForm } from "./holidays.js";
import { renderReports } from "./reports.js";
import { updateVacationCount, fillVacationForm, renderVacationForm, renderVacationList, resetVacationForm, saveVacationFromForm, exportVacations } from "./vacations.js";
import { GraphExcelProvider } from "./data/graph-excel-provider.js";
import { LocalProvider, defaultSettings } from "./data/local-provider.js";
import {
  APP_END,
  APP_START,
  addDays,
  computeVacationCounts,
  debounce,
  downloadJson,
  formatDateTimeBR,
  nowIsoDateTime,
  readFileText
} from "./utils.js";

const app = {
  provider: null,
  selectedYear: 2026,
  filters: {
    month: "",
    employee: "",
    team: "",
    status: "",
    showInactive: false,
    onlyAbsences: false,
    onlyConflicts: false,
    showCanceled: false
  },
  selection: null,
  state: {
    employees: [],
    vacations: [],
    holidays: [],
    settings: defaultSettings(),
    audit: []
  },
  async reloadData() {
    this.setLoading(true);
    try {
      const data = await this.provider.loadAll();
      this.state = {
        employees: data.employees || [],
        vacations: data.vacations || [],
        holidays: data.holidays || [],
        settings: { ...defaultSettings(), ...(data.settings || {}) },
        audit: data.audit || []
      };
      this.updateHeader();
      this.renderAll();
    } catch (error) {
      this.showError(error);
    } finally {
      this.setLoading(false);
    }
  },
  renderAll() {
    syncFormSettings(this);
    renderVacationForm(this);
    renderCalendar(this);
    renderVacationList(this);
    renderEmployeeOptions(this);
    renderEmployeeList(this);
    renderHolidayList(this);
    renderReports(this);
  },
  updateHeader() {
    document.querySelector("#syncStatus").textContent = this.provider.status || "Modo local";
    document.querySelector("#syncStatus").className = statusClass(this.provider.status);
    document.querySelector("#lastUpdated").textContent = `Última atualização: ${formatDateTimeBR(nowIsoDateTime())}`;
    document.querySelector("#currentUser").textContent = `Usuário: ${this.provider.user || "local"}`;
    document.querySelector("#localModeNotice").hidden = !(this.provider instanceof LocalProvider);
  },
  showToast(message) {
    const toast = document.querySelector("#toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => toast.classList.remove("show"), 4200);
  },
  showError(error) {
    if (window.CALENDARIO_FERIAS_CONFIG?.environment === "development") console.error(error);
    this.showToast(error.message || "Ocorreu um erro inesperado.");
  },
  setLoading(value) {
    document.querySelector("#loading").classList.toggle("hidden", !value);
  },
  async recalculateVacations() {
    for (const vacation of this.state.vacations) {
      const recalculated = { ...vacation, ...computeVacationCounts(vacation, this.state.holidays), atualizadoEm: nowIsoDateTime(), atualizadoPor: this.provider.user };
      await this.provider.saveVacation(recalculated);
    }
  },
  handleCalendarCellClick(employeeId, date, vacationId) {
    if (vacationId) {
      const vacation = this.state.vacations.find(item => item.id === vacationId);
      if (vacation) {
        activateTab("vacations");
        fillVacationForm(vacation);
      }
      return;
    }
    if (!this.selection || this.selection.employeeId !== employeeId) {
      this.selection = { employeeId, start: date };
      renderCalendar(this);
      this.showToast("Selecione o último dia do período no mesmo colaborador.");
      return;
    }
    const start = this.selection.start <= date ? this.selection.start : date;
    const end = this.selection.start <= date ? date : this.selection.start;
    this.selection = null;
    activateTab("vacations");
    fillVacationForm({ colaboradorId: employeeId, dataInicio: start, dataFim: end, status: "Planejada", observacao: "" });
  }
};

window.calendarioFeriasApp = app;

init();

async function init() {
  bindEvents();
  app.setLoading(true);
  app.provider = await createProvider();
  await app.reloadData();
  startAutoRefresh();
}

async function createProvider() {
  const config = window.CALENDARIO_FERIAS_CONFIG || { dataProvider: "local" };
  if (config.dataProvider === "graph") {
    try {
      return await new GraphExcelProvider(config).init();
    } catch (error) {
      const local = await new LocalProvider(config).init();
      app.showToast(`Integração Microsoft indisponível: ${error.message}. Modo local ativado.`);
      return local;
    }
  }
  return new LocalProvider(config).init();
}

function bindEvents() {
  document.querySelectorAll(".tab-button").forEach(button => {
    button.addEventListener("click", () => activateTab(button.dataset.tab));
  });

  document.querySelector("#yearSelect").addEventListener("change", event => {
    app.selectedYear = Number(event.target.value);
    app.filters.month = "";
    app.renderAll();
  });

  const filterBindings = [
    ["#calendarMonthFilter", "month", "change"],
    ["#calendarEmployeeFilter", "employee", "input"],
    ["#calendarTeamFilter", "team", "change"],
    ["#calendarStatusFilter", "status", "change"],
    ["#showInactiveFilter", "showInactive", "change", "checked"],
    ["#onlyAbsencesFilter", "onlyAbsences", "change", "checked"],
    ["#onlyConflictsFilter", "onlyConflicts", "change", "checked"],
    ["#showCanceledFilter", "showCanceled", "change", "checked"]
  ];
  filterBindings.forEach(([selector, key, eventName, prop = "value"]) => {
    const handler = () => {
      app.filters[key] = document.querySelector(selector)[prop];
      renderCalendar(app);
      renderReports(app);
    };
    document.querySelector(selector).addEventListener(eventName, eventName === "input" ? debounce(handler) : handler);
  });

  document.querySelector("#clearFiltersBtn").addEventListener("click", () => {
    app.filters = { month: "", employee: "", team: "", status: "", showInactive: false, onlyAbsences: false, onlyConflicts: false, showCanceled: false };
    document.querySelector("#calendarEmployeeFilter").value = "";
    document.querySelector("#calendarStatusFilter").value = "";
    ["#showInactiveFilter", "#onlyAbsencesFilter", "#onlyConflictsFilter", "#showCanceledFilter"].forEach(selector => document.querySelector(selector).checked = false);
    app.renderAll();
  });

  document.querySelector("#vacationForm").addEventListener("submit", event => {
    event.preventDefault();
    saveVacationFromForm(app).catch(error => app.showError(error));
  });
  ["#vacationStart", "#vacationEnd", "#vacationEmployee"].forEach(selector => {
    document.querySelector(selector).addEventListener("input", () => updateVacationCount(app));
  });
  document.querySelector("#resetVacationBtn").addEventListener("click", resetVacationForm);
  document.querySelector("#vacationSearch").addEventListener("input", debounce(() => renderVacationList(app)));

  document.querySelector("#employeeForm").addEventListener("submit", event => {
    event.preventDefault();
    saveEmployeeFromForm(app).catch(error => app.showError(error));
  });
  document.querySelector("#resetEmployeeBtn").addEventListener("click", resetEmployeeForm);
  document.querySelector("#employeeSearch").addEventListener("input", debounce(() => renderEmployeeList(app)));
  document.querySelector("#employeeTeamFilter").addEventListener("change", () => renderEmployeeList(app));

  document.querySelector("#holidayForm").addEventListener("submit", event => {
    event.preventDefault();
    saveHolidayFromForm(app).catch(error => app.showError(error));
  });
  document.querySelector("#resetHolidayBtn").addEventListener("click", resetHolidayForm);
  ["#holidaySearch", "#holidayYearFilter", "#holidayTypeFilter", "#holidayScopeFilter"].forEach(selector => {
    document.querySelector(selector).addEventListener(selector === "#holidaySearch" ? "input" : "change", debounce(() => renderHolidayList(app)));
  });
  document.querySelector("#holidayImport").addEventListener("change", event => {
    const file = event.target.files?.[0];
    if (file) importHolidaysCsv(app, file).catch(error => app.showError(error));
    event.target.value = "";
  });
  document.querySelector("#holidayExport").addEventListener("click", () => exportHolidaysCsv(app));

  document.querySelector("#settingsForm").addEventListener("submit", event => {
    event.preventDefault();
    saveSettings().catch(error => app.showError(error));
  });

  document.querySelector("#refreshBtn").addEventListener("click", () => app.reloadData());
  document.querySelector("#exportBtn").addEventListener("click", () => exportBackup());
  document.querySelector("#helpBtn").addEventListener("click", () => document.querySelector("#helpDialog").showModal());
  document.querySelector("#exportMonthBtn").addEventListener("click", () => exportCalendar(app, "month"));
  document.querySelector("#exportYearBtn").addEventListener("click", () => exportCalendar(app, "year"));
  document.querySelector("#exportVacationsBtn").addEventListener("click", () => exportVacations(app));
  document.querySelector("#exportHolidaysBtn").addEventListener("click", () => exportHolidaysExcel(app));
  document.querySelector("#exportBackupBtn").addEventListener("click", () => exportBackup());
  document.querySelector("#importBackupInput").addEventListener("change", event => {
    const file = event.target.files?.[0];
    if (file) importBackup(file).catch(error => app.showError(error));
    event.target.value = "";
  });
}

function activateTab(name) {
  document.querySelectorAll(".tab-button").forEach(button => button.classList.toggle("active", button.dataset.tab === name));
  document.querySelectorAll(".tab-panel").forEach(panel => panel.classList.toggle("active", panel.id === `tab-${name}`));
}

async function saveSettings() {
  const settings = {
    dataInicial: APP_START,
    dataFinal: APP_END,
    limiteAusenciasSimultaneas: Number(document.querySelector("#settingAbsenceLimit").value),
    intervaloAtualizacaoSegundos: Number(document.querySelector("#settingRefreshInterval").value),
    contarFeriasEmDiasCorridos: document.querySelector("#settingCountCalendarDays").checked
  };
  await app.provider.saveSettings(settings);
  await app.provider.addAudit({ acao: "EDITAR_CONFIGURACOES", entidade: "Configuracoes", registroId: "global", detalheNovo: JSON.stringify(settings) });
  await app.reloadData();
  app.showToast("Configurações salvas.");
}

function syncFormSettings(context) {
  document.querySelector("#settingStart").value = APP_START;
  document.querySelector("#settingEnd").value = APP_END;
  document.querySelector("#settingAbsenceLimit").value = context.state.settings.limiteAusenciasSimultaneas;
  document.querySelector("#settingRefreshInterval").value = context.state.settings.intervaloAtualizacaoSegundos;
  document.querySelector("#settingCountCalendarDays").checked = context.state.settings.contarFeriasEmDiasCorridos !== false;
}

async function exportBackup() {
  const data = await app.provider.exportBackup();
  downloadJson(`backup-calendario-ferias-${new Date().toISOString().slice(0, 10)}.json`, data);
}

async function importBackup(file) {
  if (!confirm("Restaurar o backup substituirá os dados locais atuais. Continuar?")) return;
  const text = await readFileText(file);
  const data = JSON.parse(text);
  await app.provider.importBackup(data);
  await app.reloadData();
  app.showToast("Backup restaurado.");
}

function startAutoRefresh() {
  const seconds = Number(app.state.settings.intervaloAtualizacaoSegundos || 60);
  clearInterval(app.refreshTimer);
  app.refreshTimer = setInterval(() => app.reloadData(), Math.max(15, seconds) * 1000);
}

function statusClass(status = "") {
  const lower = status.toLowerCase();
  const klass = lower.includes("erro") || lower.includes("expirada") ? "status-error"
    : lower.includes("salv") || lower.includes("conect") ? "status-saving"
      : lower.includes("sincronizado") ? "status-ok"
        : "status-local";
  return `status-pill ${klass}`;
}
