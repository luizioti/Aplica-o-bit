import {
  ACTIVE_ABSENCE_STATUSES,
  availableMonthsForYear,
  clearChildren,
  compareISO,
  dateRange,
  downloadExcelXml,
  el,
  formatDateBR,
  getMonthName,
  getWeekdayFull,
  getWeekdayShort,
  isBusinessDay,
  isWeekend,
  monthDates,
  normalizeText,
  overlapRanges,
  todayISO,
  uniqueVacationDates
} from "./utils.js";

export function renderCalendar(app) {
  renderCalendarFilters(app);
  renderLegend();
  const container = document.querySelector("#calendarContainer");
  clearChildren(container);

  const months = app.filters.month === "" ? availableMonthsForYear(app.selectedYear) : [Number(app.filters.month)];
  const employees = filteredEmployees(app);
  if (!employees.length) {
    container.append(el("div", { class: "empty-state", text: "Nenhum colaborador encontrado para os filtros selecionados." }));
    return;
  }

  months.forEach(monthIndex => {
    const block = renderMonthBlock(app, monthIndex, employees);
    if (block) container.append(block);
  });
}

export function renderCalendarFilters(app) {
  const monthSelect = document.querySelector("#calendarMonthFilter");
  const previous = monthSelect.value;
  monthSelect.innerHTML = "";
  monthSelect.append(el("option", { value: "", text: "Todos" }));
  availableMonthsForYear(app.selectedYear).forEach(monthIndex => {
    monthSelect.append(el("option", { value: String(monthIndex), text: getMonthName(monthIndex) }));
  });
  monthSelect.value = availableMonthsForYear(app.selectedYear).includes(Number(previous)) ? previous : "";
  app.filters.month = monthSelect.value;

  const teams = [...new Set(app.state.employees.map(item => item.equipe).filter(Boolean))].sort();
  fillSelect("#calendarTeamFilter", teams, "Todas");
}

export function getCalendarExportRows(app, scope = "month") {
  const rows = [["Ano", "Mês", "Colaborador", "Equipe", "Dia", "Data", "Status", "Feriado/Ponto", "Total mês corridos", "Total mês úteis", "Total ano corridos", "Períodos no ano"]];
  const months = scope === "year" || app.filters.month === "" ? availableMonthsForYear(app.selectedYear) : [Number(app.filters.month)];
  const employees = filteredEmployees(app);
  months.forEach(monthIndex => {
    const dates = visibleDatesForMonth(app, monthIndex);
    employees.forEach(employee => {
      const totals = employeeTotals(app, employee.id, app.selectedYear, monthIndex);
      dates.forEach(date => {
        const vacation = vacationForCell(app, employee.id, date);
        const holiday = holidayForDate(app, date);
        rows.push([
          app.selectedYear,
          getMonthName(monthIndex),
          employee.nome,
          employee.equipe || employee.cargo || "",
          date.slice(-2),
          formatDateBR(date),
          vacation?.status || "",
          holiday ? `${holiday.tipo}: ${holiday.descricao}` : "",
          totals.monthCalendarDays,
          totals.monthBusinessDays,
          totals.yearCalendarDays,
          totals.yearPeriods
        ]);
      });
    });
  });
  return rows;
}

export function exportCalendar(app, scope) {
  const name = scope === "year" ? `calendario-${app.selectedYear}.xls` : `calendario-${app.selectedYear}-${String(Number(app.filters.month) + 1).padStart(2, "0")}.xls`;
  downloadExcelXml(name, "Calendario", getCalendarExportRows(app, scope));
}

export function getAbsenceMap(app, dates) {
  const map = new Map();
  dates.forEach(date => {
    const absent = app.state.vacations
      .filter(item => ACTIVE_ABSENCE_STATUSES.includes(item.status) && compareISO(item.dataInicio, date) <= 0 && compareISO(date, item.dataFim) <= 0)
      .map(item => app.state.employees.find(employee => employee.id === item.colaboradorId))
      .filter(Boolean);
    map.set(date, absent);
  });
  return map;
}

export function employeeTotals(app, employeeId, year, monthIndex) {
  const monthStart = `${year}-${String(monthIndex + 1).padStart(2, "0")}-01`;
  const dates = monthDates(year, monthIndex);
  const monthEnd = dates.at(-1);
  const yearStart = year === 2026 ? "2026-06-01" : `${year}-01-01`;
  const yearEnd = `${year}-12-31`;
  const holidays = app.state.holidays;
  const includeCanceled = app.filters.showCanceled;
  const statuses = app.filters.status ? [app.filters.status] : null;
  const employeeVacations = app.state.vacations.filter(item =>
    item.colaboradorId === employeeId &&
    (includeCanceled || item.status !== "Cancelada") &&
    (!statuses || statuses.includes(item.status))
  );
  const monthSet = uniqueVacationDates(
    employeeVacations.filter(item => overlapRanges(item.dataInicio, item.dataFim, monthStart, monthEnd)),
    monthStart,
    monthEnd,
    includeCanceled
  );
  const yearSet = uniqueVacationDates(
    employeeVacations.filter(item => overlapRanges(item.dataInicio, item.dataFim, yearStart, yearEnd)),
    yearStart,
    yearEnd,
    includeCanceled
  );
  return {
    monthCalendarDays: monthSet.size,
    monthBusinessDays: [...monthSet].filter(date => isBusinessDay(date, holidays)).length,
    yearCalendarDays: yearSet.size,
    yearPeriods: employeeVacations.filter(item => overlapRanges(item.dataInicio, item.dataFim, yearStart, yearEnd)).length
  };
}

function renderMonthBlock(app, monthIndex, employees) {
  const dates = visibleDatesForMonth(app, monthIndex);
  const absenceMap = getAbsenceMap(app, dates);
  const visibleEmployees = app.filters.onlyAbsences
    ? employees.filter(employee => dates.some(date => vacationForCell(app, employee.id, date)))
    : employees;

  const hasConflict = dates.some(date => (absenceMap.get(date)?.length || 0) > Number(app.state.settings.limiteAusenciasSimultaneas || 2));
  if (app.filters.onlyConflicts && !hasConflict) return null;

  const details = el("details", { class: "month-block", open: true });
  const summary = el("summary", { class: "month-summary" }, [
    el("span", { text: `${getMonthName(monthIndex)} de ${app.selectedYear}` }),
    el("span", { class: "month-kpis", text: `${visibleEmployees.length} colaboradores | ${dates.length} dias visíveis` })
  ]);
  const scroll = el("div", { class: "table-scroll" });
  const table = el("table", { class: "calendar-table" });
  const thead = el("thead");
  const header = el("tr");
  header.append(el("th", { class: "sticky-col employee-col", text: "Colaborador" }));
  header.append(el("th", { class: "sticky-col team-col", text: "Equipe/Cargo" }));
  dates.forEach(date => header.append(dayHeader(app, date, absenceMap)));
  ["Dias mês", "Úteis mês", "Dias ano", "Períodos"].forEach(text => header.append(el("th", { class: "total-col", text })));
  thead.append(header);
  table.append(thead);

  const tbody = el("tbody");
  visibleEmployees.forEach(employee => {
    const row = el("tr");
    row.append(el("th", { class: "sticky-col employee-col", text: employee.nome, title: employee.email || employee.nome }));
    row.append(el("td", { class: "sticky-col team-col", text: employee.equipe || employee.cargo || "" }));
    dates.forEach(date => row.append(dayCell(app, employee, date, absenceMap)));
    const totals = employeeTotals(app, employee.id, app.selectedYear, monthIndex);
    row.append(el("td", { class: "total-col", text: String(totals.monthCalendarDays) }));
    row.append(el("td", { class: "total-col", text: String(totals.monthBusinessDays) }));
    row.append(el("td", { class: "total-col", text: String(totals.yearCalendarDays) }));
    row.append(el("td", { class: "total-col", text: String(totals.yearPeriods) }));
    tbody.append(row);
  });
  table.append(tbody);
  scroll.append(table);
  details.append(summary, scroll);
  return details;
}

function dayHeader(app, date, absenceMap) {
  const absent = absenceMap.get(date) || [];
  const limit = Number(app.state.settings.limiteAusenciasSimultaneas || 2);
  const holiday = holidayForDate(app, date);
  const classes = ["day-header", dayClass(date, holiday)];
  if (date === todayISO()) classes.push("day-today");
  if (absent.length > limit) classes.push("day-conflict");
  const title = [
    `${formatDateBR(date)} - ${getWeekdayFull(date)}`,
    holiday ? `${holiday.tipo}: ${holiday.descricao}` : "",
    absent.length > limit ? `Alerta: ${absent.length} ausentes (${absent.map(item => item.nome).join(", ")})` : ""
  ].filter(Boolean).join("\n");
  return el("th", { class: classes.join(" "), title }, [
    el("span", { class: "day-number", text: date.slice(-2) }),
    el("span", { class: "weekday", text: getWeekdayShort(date) }),
    absent.length > limit ? el("span", { text: "!" }) : document.createTextNode("")
  ]);
}

function dayCell(app, employee, date, absenceMap) {
  const holiday = holidayForDate(app, date);
  const vacation = vacationForCell(app, employee.id, date);
  const absent = absenceMap.get(date) || [];
  const limit = Number(app.state.settings.limiteAusenciasSimultaneas || 2);
  const classes = ["calendar-day", dayClass(date, holiday)];
  if (date === todayISO()) classes.push("day-today");
  if (absent.length > limit) classes.push("day-conflict");
  if (vacation) classes.push("vacation-cell", `vacation-${normalizeText(vacation.status)}`);
  if (app.selection?.employeeId === employee.id && app.selection?.start === date) classes.push("selected-cell");

  const title = [
    `${formatDateBR(date)} - ${getWeekdayFull(date)}`,
    `Colaborador: ${employee.nome}`,
    holiday ? `${holiday.tipo}: ${holiday.descricao}` : (isWeekend(date) ? "Fim de semana" : "Dia útil"),
    vacation ? `Férias ${vacation.status}: ${formatDateBR(vacation.dataInicio)} a ${formatDateBR(vacation.dataFim)}` : "Sem férias",
    vacation?.observacao ? `Observação: ${vacation.observacao}` : "",
    absent.length > limit ? `Alerta: ${absent.length} ausentes no dia` : ""
  ].filter(Boolean).join("\n");

  const cell = el("td", {
    class: classes.join(" "),
    title,
    tabIndex: 0,
    dataset: { employeeId: employee.id, date, vacationId: vacation?.id || "" },
    aria: { label: title.replaceAll("\n", ". ") }
  }, [document.createTextNode(vacation ? statusMarker(vacation.status) : "")]);

  cell.addEventListener("click", () => app.handleCalendarCellClick(employee.id, date, vacation?.id));
  cell.addEventListener("keydown", event => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      app.handleCalendarCellClick(employee.id, date, vacation?.id);
    }
  });
  return cell;
}

export function holidayForDate(app, date) {
  return app.state.holidays.find(item => item.ativo !== false && item.data === date);
}

export function vacationForCell(app, employeeId, date) {
  const statuses = app.filters.status ? [app.filters.status] : null;
  return app.state.vacations.find(item =>
    item.colaboradorId === employeeId &&
    (app.filters.showCanceled || item.status !== "Cancelada") &&
    (!statuses || statuses.includes(item.status)) &&
    compareISO(item.dataInicio, date) <= 0 &&
    compareISO(date, item.dataFim) <= 0
  );
}

function visibleDatesForMonth(app, monthIndex) {
  const dates = monthDates(app.selectedYear, monthIndex);
  if (!app.filters.onlyAbsences && !app.filters.onlyConflicts) return dates;
  const absenceMap = getAbsenceMap(app, dates);
  const limit = Number(app.state.settings.limiteAusenciasSimultaneas || 2);
  return dates.filter(date => {
    if (app.filters.onlyConflicts) return (absenceMap.get(date)?.length || 0) > limit;
    return app.state.vacations.some(item => item.status !== "Cancelada" && compareISO(item.dataInicio, date) <= 0 && compareISO(date, item.dataFim) <= 0);
  });
}

function filteredEmployees(app) {
  const query = normalizeText(app.filters.employee || "");
  return app.state.employees
    .filter(item => app.filters.showInactive || item.ativo !== false)
    .filter(item => !query || normalizeText(item.nome).includes(query))
    .filter(item => !app.filters.team || item.equipe === app.filters.team)
    .sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR"));
}

function dayClass(date, holiday) {
  if (holiday?.tipo === "Feriado") return "day-holiday";
  if (holiday?.tipo === "Ponto facultativo") return "day-optional";
  if (holiday?.tipo === "Folga institucional" || holiday?.tipo === "Outro dia não útil") return "day-institutional";
  const weekday = new Date(`${date}T00:00:00`).getDay();
  if (weekday === 6) return "day-saturday";
  if (weekday === 0) return "day-sunday";
  return "day-weekday";
}

function statusMarker(status) {
  return {
    Planejada: "P",
    Solicitada: "S",
    Aprovada: "A",
    Cancelada: "C"
  }[status] || "";
}

function renderLegend() {
  const legend = document.querySelector("#legend");
  if (legend.children.length) return;
  [
    ["Dia útil", "#ffffff"],
    ["Sábado", "var(--saturday)"],
    ["Domingo", "var(--sunday)"],
    ["Feriado", "var(--holiday)"],
    ["Ponto facultativo", "var(--optional)"],
    ["Folga institucional", "var(--institutional)"],
    ["Planejada (P)", "var(--planned)"],
    ["Solicitada (S)", "var(--requested)"],
    ["Aprovada (A)", "var(--approved)"],
    ["Cancelada (C)", "var(--canceled)"],
    ["Conflito", "#ffffff"]
  ].forEach(([label, color]) => {
    const swatch = el("span", { class: "legend-swatch" });
    swatch.style.background = color;
    if (label === "Conflito") swatch.style.boxShadow = "inset 0 -4px 0 #dc2626";
    legend.append(el("span", { class: "legend-item" }, [swatch, document.createTextNode(label)]));
  });
}

function fillSelect(selector, values, allLabel) {
  const select = document.querySelector(selector);
  const previous = select.value;
  select.innerHTML = "";
  select.append(el("option", { value: "", text: allLabel }));
  values.forEach(value => select.append(el("option", { value, text: value })));
  select.value = values.includes(previous) ? previous : "";
}
