export class DataProvider {
  constructor(config = {}) {
    this.config = config;
    this.status = "Desconectado";
    this.user = "local";
  }

  async init() { throw new Error("init não implementado"); }
  async loadAll() { throw new Error("loadAll não implementado"); }
  async saveEmployee() { throw new Error("saveEmployee não implementado"); }
  async saveVacation() { throw new Error("saveVacation não implementado"); }
  async saveHoliday() { throw new Error("saveHoliday não implementado"); }
  async saveSettings() { throw new Error("saveSettings não implementado"); }
  async deleteVacation() { throw new Error("deleteVacation não implementado"); }
  async deleteHoliday() { throw new Error("deleteHoliday não implementado"); }
  async addAudit() { throw new Error("addAudit não implementado"); }
  async exportBackup() { throw new Error("exportBackup não implementado"); }
  async importBackup() { throw new Error("importBackup não implementado"); }
}
