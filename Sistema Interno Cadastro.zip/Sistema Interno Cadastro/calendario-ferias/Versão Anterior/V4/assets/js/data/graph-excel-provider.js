import { DataProvider } from "./data-provider.js";
import { nowIsoDateTime, uuid } from "../utils.js";

const GRAPH_ROOT = "https://graph.microsoft.com/v1.0";

export class GraphExcelProvider extends DataProvider {
  constructor(config = {}) {
    super(config);
    this.status = "Conectando";
    this.account = null;
    this.msalClient = null;
  }

  async init() {
    if (!this.config?.graph?.tenantId || !this.config?.graph?.clientId) {
      throw new Error("Configuração Microsoft Graph incompleta.");
    }
    if (!window.msal?.PublicClientApplication) {
      throw new Error("Biblioteca MSAL não carregada. Inclua a versão oficial da MSAL no HTML corporativo.");
    }

    this.msalClient = new window.msal.PublicClientApplication({
      auth: {
        clientId: this.config.graph.clientId,
        authority: `https://login.microsoftonline.com/${this.config.graph.tenantId}`,
        redirectUri: window.location.origin + window.location.pathname
      },
      cache: { cacheLocation: "sessionStorage", storeAuthStateInCookie: false }
    });
    await this.msalClient.initialize?.();
    const result = await this.msalClient.loginPopup({ scopes: this.config.graph.scopes });
    this.account = result.account;
    this.user = this.account?.username || this.account?.name || "Microsoft";
    this.status = "Sincronizado";
    return this;
  }

  async loadAll() {
    this.status = "Conectando";
    const [employees, vacations, holidays, settingsRows, audit] = await Promise.all([
      this.readTable("colaboradores"),
      this.readTable("ferias"),
      this.readTable("feriados"),
      this.readTable("configuracoes"),
      this.readTable("auditoria")
    ]);
    this.status = "Sincronizado";
    return {
      employees,
      vacations,
      holidays,
      settings: Object.fromEntries(settingsRows.map(item => [item.chave, parseSettingValue(item.valor)])),
      audit
    };
  }

  async saveEmployee(employee) {
    return this.upsertRow("colaboradores", employee, "id");
  }

  async saveVacation(vacation) {
    return this.upsertRow("ferias", vacation, "id");
  }

  async saveHoliday(holiday) {
    return this.upsertRow("feriados", holiday, "id");
  }

  async saveSettings(settings) {
    const rows = Object.entries(settings).map(([chave, valor]) => ({ chave, valor: String(valor), descricao: "" }));
    await this.replaceTable("configuracoes", rows);
    return settings;
  }

  async deleteVacation(id) {
    const rows = await this.readTable("ferias");
    const target = rows.find(item => item.id === id);
    if (!target) return;
    target.status = "Cancelada";
    target.atualizadoPor = this.user;
    target.atualizadoEm = nowIsoDateTime();
    await this.upsertRow("ferias", target, "id");
  }

  async deleteHoliday(id) {
    const rows = await this.readTable("feriados");
    const target = rows.find(item => item.id === id);
    if (!target) return;
    target.ativo = false;
    target.atualizadoEm = nowIsoDateTime();
    await this.upsertRow("feriados", target, "id");
  }

  async addAudit(record) {
    const row = { id: uuid(), dataHora: nowIsoDateTime(), usuario: this.user, ...record };
    await this.appendRow("auditoria", row);
    return row;
  }

  async exportBackup() {
    return this.loadAll();
  }

  async importBackup() {
    throw new Error("Restauração direta de backup no Graph não é automática por segurança. Use o modo local ou importe as tabelas com validação administrativa.");
  }

  async readTable(logicalName) {
    const tableName = this.tableName(logicalName);
    const result = await this.graphFetch(`/drives/${this.config.graph.driveId}/items/${this.config.graph.itemId}/workbook/tables/${tableName}/rows`);
    const rows = result.value || [];
    const columns = await this.getColumns(tableName);
    return rows.map(row => Object.fromEntries(columns.map((col, index) => [col, normalizeExcelValue(row.values?.[0]?.[index])])));
  }

  async getColumns(tableName) {
    const result = await this.graphFetch(`/drives/${this.config.graph.driveId}/items/${this.config.graph.itemId}/workbook/tables/${tableName}/columns`);
    return (result.value || []).map(item => item.name);
  }

  async appendRow(logicalName, row) {
    this.status = "Salvando";
    const tableName = this.tableName(logicalName);
    const columns = await this.getColumns(tableName);
    await this.graphFetch(`/drives/${this.config.graph.driveId}/items/${this.config.graph.itemId}/workbook/tables/${tableName}/rows/add`, {
      method: "POST",
      body: JSON.stringify({ values: [columns.map(col => row[col] ?? "")] })
    });
    this.status = "Sincronizado";
    return row;
  }

  async upsertRow(logicalName, row, keyField) {
    const existing = await this.readTable(logicalName);
    const index = existing.findIndex(item => item[keyField] === row[keyField]);
    if (index < 0) return this.appendRow(logicalName, row);
    await this.replaceTable(logicalName, existing.map(item => item[keyField] === row[keyField] ? row : item));
    return row;
  }

  async replaceTable(logicalName, rows) {
    this.status = "Salvando";
    const tableName = this.tableName(logicalName);
    const columns = await this.getColumns(tableName);
    await this.graphFetch(`/drives/${this.config.graph.driveId}/items/${this.config.graph.itemId}/workbook/tables/${tableName}/rows/clear`, { method: "POST" });
    if (rows.length) {
      await this.graphFetch(`/drives/${this.config.graph.driveId}/items/${this.config.graph.itemId}/workbook/tables/${tableName}/rows/add`, {
        method: "POST",
        body: JSON.stringify({ values: rows.map(row => columns.map(col => row[col] ?? "")) })
      });
    }
    this.status = "Sincronizado";
  }

  tableName(logicalName) {
    return this.config.graph.tableNames[logicalName];
  }

  async graphFetch(path, options = {}) {
    const token = await this.getToken();
    const response = await fetch(`${GRAPH_ROOT}${path}`, {
      ...options,
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json",
        ...(options.headers || {})
      }
    });
    if (response.status === 401) {
      this.status = "Sessão expirada";
      throw new Error("Sessão Microsoft expirada. Atualize os dados para autenticar novamente.");
    }
    if (!response.ok) {
      this.status = "Erro de sincronização";
      throw new Error(`Erro Microsoft Graph ${response.status}: ${await response.text()}`);
    }
    return response.status === 204 ? {} : response.json();
  }

  async getToken() {
    const request = { scopes: this.config.graph.scopes, account: this.account };
    try {
      const result = await this.msalClient.acquireTokenSilent(request);
      return result.accessToken;
    } catch {
      const result = await this.msalClient.acquireTokenPopup(request);
      return result.accessToken;
    }
  }
}

function normalizeExcelValue(value) {
  if (typeof value === "string" && value.startsWith("'")) return value.slice(1);
  if (value === "true") return true;
  if (value === "false") return false;
  return value;
}

function parseSettingValue(value) {
  if (value === "true") return true;
  if (value === "false") return false;
  if (!Number.isNaN(Number(value)) && value !== "") return Number(value);
  return value;
}
