import { DataProvider } from "./data-provider.js";
import { APP_END, APP_START, computeVacationCounts, nowIsoDateTime, uuid } from "../utils.js";

const DB_NAME = "calendario-ferias-db";
const DB_VERSION = 1;
const STORES = ["employees", "vacations", "holidays", "settings", "audit"];

export class LocalProvider extends DataProvider {
  constructor(config = {}) {
    super(config);
    this.status = "Modo local";
    this.user = "local";
    this.db = null;
  }

  async init() {
    this.db = await openDatabase();
    await this.seedIfEmpty();
    return this;
  }

  async loadAll() {
    const [employees, vacations, holidays, settingsRows, audit] = await Promise.all([
      this.getAll("employees"),
      this.getAll("vacations"),
      this.getAll("holidays"),
      this.getAll("settings"),
      this.getAll("audit")
    ]);
    return {
      employees,
      vacations,
      holidays,
      settings: Object.fromEntries(settingsRows.map(item => [item.chave, item.valor])),
      audit
    };
  }

  async saveEmployee(employee) {
    await this.put("employees", employee);
    return employee;
  }

  async saveVacation(vacation) {
    await this.put("vacations", vacation);
    return vacation;
  }

  async deleteVacation(id) {
    await this.delete("vacations", id);
  }

  async saveHoliday(holiday) {
    await this.put("holidays", holiday);
    return holiday;
  }

  async deleteHoliday(id) {
    await this.delete("holidays", id);
  }

  async saveSettings(settings) {
    const rows = Object.entries(settings).map(([chave, valor]) => ({
      chave,
      valor,
      descricao: settingsDescription(chave)
    }));
    await this.replaceAll("settings", rows);
    return settings;
  }

  async addAudit(record) {
    const row = { id: uuid(), dataHora: nowIsoDateTime(), usuario: this.user, ...record };
    await this.put("audit", row);
    return row;
  }

  async exportBackup() {
    return this.loadAll();
  }

  async importBackup(data) {
    await Promise.all(STORES.map(store => this.clear(store)));
    await this.replaceAll("employees", data.employees || []);
    await this.replaceAll("vacations", data.vacations || []);
    await this.replaceAll("holidays", data.holidays || []);
    const settings = data.settings && !Array.isArray(data.settings)
      ? Object.entries(data.settings).map(([chave, valor]) => ({ chave, valor, descricao: settingsDescription(chave) }))
      : (data.settings || []);
    await this.replaceAll("settings", settings);
    await this.replaceAll("audit", data.audit || []);
    await this.addAudit({ acao: "IMPORTAR_BACKUP", entidade: "Sistema", registroId: "backup", detalheNovo: "Backup JSON restaurado" });
  }

  async seedIfEmpty() {
    const employees = await this.getAll("employees");
    if (employees.length) return;

    const now = nowIsoDateTime();
    const employeeRows = [
      ["Ana Martins", "Atendimento", "Analista", "ana.martins@example.com"],
      ["Bruno Silva", "Operações", "Especialista", "bruno.silva@example.com"],
      ["Carla Souza", "Operações", "Coordenadora", "carla.souza@example.com"],
      ["Diego Lima", "Financeiro", "Analista", "diego.lima@example.com"],
      ["Elisa Rocha", "Tecnologia", "Product Owner", "elisa.rocha@example.com"]
    ].map(([nome, equipe, cargo, email]) => ({ id: uuid(), nome, equipe, cargo, email, ativo: true, dataInclusao: now, atualizadoEm: now }));

    const holidays = [
      { id: uuid(), data: "2026-09-07", descricao: "Independência do Brasil", tipo: "Feriado", abrangencia: "Nacional", ativo: true, criadoEm: now, atualizadoEm: now },
      { id: uuid(), data: "2026-12-24", descricao: "Véspera de Natal", tipo: "Ponto facultativo", abrangencia: "Empresa", ativo: true, criadoEm: now, atualizadoEm: now },
      { id: uuid(), data: "2027-01-01", descricao: "Confraternização Universal", tipo: "Feriado", abrangencia: "Nacional", ativo: true, criadoEm: now, atualizadoEm: now },
      { id: uuid(), data: "2028-02-28", descricao: "Recesso institucional", tipo: "Folga institucional", abrangencia: "Empresa", ativo: true, criadoEm: now, atualizadoEm: now }
    ];

    const vacationSeeds = [
      { colaboradorId: employeeRows[0].id, dataInicio: "2026-07-01", dataFim: "2026-07-15", status: "Aprovada", observacao: "Período principal" },
      { colaboradorId: employeeRows[1].id, dataInicio: "2026-07-10", dataFim: "2026-07-20", status: "Solicitada", observacao: "Aguardando aprovação" },
      { colaboradorId: employeeRows[2].id, dataInicio: "2028-02-28", dataFim: "2028-03-05", status: "Planejada", observacao: "Cruza mês e ano bissexto" }
    ].map(item => {
      const vacation = {
        id: uuid(),
        ...item,
        criadoPor: this.user,
        criadoEm: now,
        atualizadoPor: this.user,
        atualizadoEm: now
      };
      return { ...vacation, ...computeVacationCounts(vacation, holidays) };
    });

    await this.replaceAll("employees", employeeRows);
    await this.replaceAll("holidays", holidays);
    await this.replaceAll("vacations", vacationSeeds);
    await this.saveSettings(defaultSettings());
    await this.addAudit({ acao: "SEED", entidade: "Sistema", registroId: "inicial", detalheNovo: "Dados iniciais de demonstração criados" });
  }

  transaction(storeName, mode = "readonly") {
    return this.db.transaction(storeName, mode).objectStore(storeName);
  }

  getAll(storeName) {
    return requestToPromise(this.transaction(storeName).getAll());
  }

  put(storeName, value) {
    return requestToPromise(this.transaction(storeName, "readwrite").put(value));
  }

  delete(storeName, key) {
    return requestToPromise(this.transaction(storeName, "readwrite").delete(key));
  }

  clear(storeName) {
    return requestToPromise(this.transaction(storeName, "readwrite").clear());
  }

  async replaceAll(storeName, rows) {
    const tx = this.db.transaction(storeName, "readwrite");
    const store = tx.objectStore(storeName);
    store.clear();
    rows.forEach(row => store.put(row));
    await transactionDone(tx);
  }
}

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains("employees")) db.createObjectStore("employees", { keyPath: "id" });
      if (!db.objectStoreNames.contains("vacations")) db.createObjectStore("vacations", { keyPath: "id" });
      if (!db.objectStoreNames.contains("holidays")) db.createObjectStore("holidays", { keyPath: "id" });
      if (!db.objectStoreNames.contains("settings")) db.createObjectStore("settings", { keyPath: "chave" });
      if (!db.objectStoreNames.contains("audit")) db.createObjectStore("audit", { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function requestToPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function transactionDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export function defaultSettings() {
  return {
    dataInicial: APP_START,
    dataFinal: APP_END,
    limiteAusenciasSimultaneas: 2,
    intervaloAtualizacaoSegundos: 60,
    contarFeriasEmDiasCorridos: true
  };
}

function settingsDescription(key) {
  return {
    dataInicial: "Data inicial permitida pela aplicação",
    dataFinal: "Data final permitida pela aplicação",
    limiteAusenciasSimultaneas: "Limite gerencial de colaboradores ausentes no mesmo dia",
    intervaloAtualizacaoSegundos: "Intervalo da atualização automática",
    contarFeriasEmDiasCorridos: "Define a contagem principal de férias"
  }[key] || "";
}
