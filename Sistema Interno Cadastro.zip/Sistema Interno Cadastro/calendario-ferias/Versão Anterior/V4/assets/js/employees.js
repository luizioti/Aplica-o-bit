import { employeeTotals } from "./calendar.js";
import { filterBySearch, validateEmployee } from "./validation.js";
import { clearChildren, el, formatDateBR, nowIsoDateTime, sortByName, uuid } from "./utils.js";

export function renderEmployeeOptions(app) {
  const teams = [...new Set(app.state.employees.map(item => item.equipe).filter(Boolean))].sort();
  fillSelect("#employeeTeamFilter", teams, "Todas as equipes");
}

export function renderEmployeeList(app) {
  renderEmployeeOptions(app);
  const container = document.querySelector("#employeeList");
  clearChildren(container);
  const query = document.querySelector("#employeeSearch").value;
  const team = document.querySelector("#employeeTeamFilter").value;
  const rows = app.state.employees
    .filter(item => filterBySearch(item.nome, query))
    .filter(item => !team || item.equipe === team)
    .sort(sortByName);
  if (!rows.length) {
    container.append(el("div", { class: "empty-state", text: "Nenhum colaborador cadastrado." }));
    return;
  }
  const table = el("table", { class: "data-table" });
  table.append(header(["Nome", "Equipe", "Cargo", "E-mail", "Ativo", "Férias no ano", "Próximo período", "Ações"]));
  const tbody = el("tbody");
  rows.forEach(employee => {
    const tr = el("tr");
    const totals = employeeTotals(app, employee.id, app.selectedYear, 0);
    const next = app.state.vacations
      .filter(item => item.colaboradorId === employee.id && item.status !== "Cancelada")
      .sort((a, b) => a.dataInicio.localeCompare(b.dataInicio))[0];
    [
      employee.nome,
      employee.equipe,
      employee.cargo || "",
      employee.email || "",
      employee.ativo === false ? "Não" : "Sim",
      `${totals.yearCalendarDays} dia(s)`,
      next ? `${formatDateBR(next.dataInicio)} a ${formatDateBR(next.dataFim)}` : "-"
    ].forEach(value => tr.append(el("td", { text: String(value) })));
    const actions = el("td", { class: "actions" });
    actions.append(actionButton("Editar", () => fillEmployeeForm(employee)));
    actions.append(actionButton(employee.ativo === false ? "Ativar" : "Inativar", () => toggleEmployee(app, employee), "secondary"));
    tr.append(actions);
    tbody.append(tr);
  });
  table.append(tbody);
  container.append(table);
}

export function fillEmployeeForm(employee) {
  document.querySelector("#employeeId").value = employee.id || "";
  document.querySelector("#employeeName").value = employee.nome || "";
  document.querySelector("#employeeTeam").value = employee.equipe || "";
  document.querySelector("#employeeRole").value = employee.cargo || "";
  document.querySelector("#employeeEmail").value = employee.email || "";
  document.querySelector("#employeeActive").checked = employee.ativo !== false;
  document.querySelector("#employeeForm").scrollIntoView({ behavior: "smooth", block: "start" });
}

export async function saveEmployeeFromForm(app) {
  const saveButton = document.querySelector("#saveEmployeeBtn");
  saveButton.disabled = true;
  try {
    const id = document.querySelector("#employeeId").value || uuid();
    const existing = app.state.employees.find(item => item.id === id);
    const now = nowIsoDateTime();
    const employee = {
      id,
      nome: document.querySelector("#employeeName").value.trim(),
      equipe: document.querySelector("#employeeTeam").value.trim(),
      cargo: document.querySelector("#employeeRole").value.trim(),
      email: document.querySelector("#employeeEmail").value.trim(),
      ativo: document.querySelector("#employeeActive").checked,
      dataInclusao: existing?.dataInclusao || now,
      atualizadoEm: now
    };
    const errors = validateEmployee(employee);
    if (errors.length) {
      app.showToast(errors.join(" "));
      return;
    }
    await app.provider.saveEmployee(employee);
    await app.provider.addAudit({
      acao: existing ? "EDITAR_COLABORADOR" : "CRIAR_COLABORADOR",
      entidade: "Colaboradores",
      registroId: employee.id,
      detalheAnterior: existing ? JSON.stringify(existing) : "",
      detalheNovo: JSON.stringify(employee)
    });
    await app.reloadData();
    resetEmployeeForm();
    app.showToast("Colaborador salvo.");
  } finally {
    saveButton.disabled = false;
  }
}

export function resetEmployeeForm() {
  document.querySelector("#employeeId").value = "";
  document.querySelector("#employeeForm").reset();
  document.querySelector("#employeeActive").checked = true;
}

async function toggleEmployee(app, employee) {
  const updated = { ...employee, ativo: employee.ativo === false, atualizadoEm: nowIsoDateTime() };
  await app.provider.saveEmployee(updated);
  await app.provider.addAudit({
    acao: updated.ativo ? "ATIVAR_COLABORADOR" : "INATIVAR_COLABORADOR",
    entidade: "Colaboradores",
    registroId: employee.id,
    detalheAnterior: JSON.stringify(employee),
    detalheNovo: JSON.stringify(updated)
  });
  await app.reloadData();
  app.showToast(updated.ativo ? "Colaborador ativado." : "Colaborador inativado.");
}

function fillSelect(selector, values, allLabel) {
  const select = document.querySelector(selector);
  const previous = select.value;
  select.innerHTML = "";
  select.append(el("option", { value: "", text: allLabel }));
  values.forEach(value => select.append(el("option", { value, text: value })));
  select.value = values.includes(previous) ? previous : "";
}

function header(values) {
  const thead = el("thead");
  const tr = el("tr");
  values.forEach(value => tr.append(el("th", { text: value })));
  thead.append(tr);
  return thead;
}

function actionButton(text, handler, tone = "secondary") {
  const button = el("button", { type: "button", class: `btn ${tone}`, text });
  button.addEventListener("click", handler);
  return button;
}
