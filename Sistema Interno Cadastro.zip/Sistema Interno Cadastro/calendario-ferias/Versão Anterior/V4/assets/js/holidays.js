import { validateHoliday } from "./validation.js";
import { YEARS, clearChildren, downloadCsv, downloadExcelXml, el, formatDateBR, nowIsoDateTime, normalizeText, parseCsv, readFileText, uuid } from "./utils.js";

export function renderHolidayFilters() {
  fillSelect("#holidayYearFilter", YEARS.map(String), "Todos os anos");
  fillSelect("#holidayTypeFilter", ["Feriado", "Ponto facultativo", "Folga institucional", "Outro dia não útil"], "Todos os tipos");
  fillSelect("#holidayScopeFilter", ["Nacional", "Estadual", "Municipal", "Empresa"], "Todas as abrangências");
}

export function renderHolidayList(app) {
  renderHolidayFilters();
  const container = document.querySelector("#holidayList");
  clearChildren(container);
  const query = normalizeText(document.querySelector("#holidaySearch").value);
  const year = document.querySelector("#holidayYearFilter").value;
  const type = document.querySelector("#holidayTypeFilter").value;
  const scope = document.querySelector("#holidayScopeFilter").value;
  const rows = app.state.holidays
    .filter(item => !query || normalizeText(`${item.descricao} ${item.tipo} ${item.abrangencia}`).includes(query))
    .filter(item => !year || item.data.startsWith(year))
    .filter(item => !type || item.tipo === type)
    .filter(item => !scope || item.abrangencia === scope)
    .sort((a, b) => a.data.localeCompare(b.data));

  if (!rows.length) {
    container.append(el("div", { class: "empty-state", text: "Nenhum feriado ou ponto facultativo cadastrado." }));
    return;
  }

  const table = el("table", { class: "data-table" });
  table.append(header(["Data", "Descrição", "Tipo", "Abrangência", "Ativo", "Ações"]));
  const tbody = el("tbody");
  rows.forEach(holiday => {
    const tr = el("tr");
    [formatDateBR(holiday.data), holiday.descricao, holiday.tipo, holiday.abrangencia, holiday.ativo === false ? "Não" : "Sim"].forEach(value => tr.append(el("td", { text: value })));
    const actions = el("td", { class: "actions" });
    actions.append(actionButton("Editar", () => fillHolidayForm(holiday)));
    actions.append(actionButton(holiday.ativo === false ? "Ativar" : "Inativar", () => toggleHoliday(app, holiday)));
    actions.append(actionButton("Excluir", () => deleteHoliday(app, holiday), "danger"));
    tr.append(actions);
    tbody.append(tr);
  });
  table.append(tbody);
  container.append(table);
}

export function fillHolidayForm(holiday) {
  document.querySelector("#holidayId").value = holiday.id || "";
  document.querySelector("#holidayDate").value = holiday.data || "";
  document.querySelector("#holidayDescription").value = holiday.descricao || "";
  document.querySelector("#holidayType").value = holiday.tipo || "Feriado";
  document.querySelector("#holidayScope").value = holiday.abrangencia || "Nacional";
  document.querySelector("#holidayActive").checked = holiday.ativo !== false;
  document.querySelector("#holidayForm").scrollIntoView({ behavior: "smooth", block: "start" });
}

export async function saveHolidayFromForm(app) {
  const saveButton = document.querySelector("#saveHolidayBtn");
  saveButton.disabled = true;
  try {
    const id = document.querySelector("#holidayId").value || uuid();
    const existing = app.state.holidays.find(item => item.id === id);
    const now = nowIsoDateTime();
    const holiday = {
      id,
      data: document.querySelector("#holidayDate").value,
      descricao: document.querySelector("#holidayDescription").value.trim(),
      tipo: document.querySelector("#holidayType").value,
      abrangencia: document.querySelector("#holidayScope").value,
      ativo: document.querySelector("#holidayActive").checked,
      criadoEm: existing?.criadoEm || now,
      atualizadoEm: now
    };
    const errors = validateHoliday(holiday);
    if (errors.length) {
      app.showToast(errors.join(" "));
      return;
    }
    await app.provider.saveHoliday(holiday);
    await app.provider.addAudit({
      acao: existing ? "EDITAR_FERIADO" : "CRIAR_FERIADO",
      entidade: "Feriados",
      registroId: holiday.id,
      detalheAnterior: existing ? JSON.stringify(existing) : "",
      detalheNovo: JSON.stringify(holiday)
    });
    await app.recalculateVacations();
    await app.reloadData();
    resetHolidayForm();
    app.showToast("Registro salvo.");
  } finally {
    saveButton.disabled = false;
  }
}

export function resetHolidayForm() {
  document.querySelector("#holidayId").value = "";
  document.querySelector("#holidayForm").reset();
  document.querySelector("#holidayType").value = "Feriado";
  document.querySelector("#holidayScope").value = "Nacional";
  document.querySelector("#holidayActive").checked = true;
}

export async function importHolidaysCsv(app, file) {
  const text = await readFileText(file);
  const rows = parseCsv(text);
  const headerRow = rows.shift()?.map(item => normalizeText(item)) || [];
  const now = nowIsoDateTime();
  for (const row of rows) {
    const data = getCsvValue(headerRow, row, "data");
    const holiday = {
      id: uuid(),
      data,
      descricao: getCsvValue(headerRow, row, "descricao") || getCsvValue(headerRow, row, "descrição"),
      tipo: getCsvValue(headerRow, row, "tipo") || "Feriado",
      abrangencia: getCsvValue(headerRow, row, "abrangencia") || getCsvValue(headerRow, row, "abrangência") || "Empresa",
      ativo: true,
      criadoEm: now,
      atualizadoEm: now
    };
    const errors = validateHoliday(holiday);
    if (!errors.length) await app.provider.saveHoliday(holiday);
  }
  await app.provider.addAudit({ acao: "IMPORTAR_FERIADOS_CSV", entidade: "Feriados", registroId: "csv", detalheNovo: file.name });
  await app.recalculateVacations();
  await app.reloadData();
  app.showToast("Importação concluída.");
}

export function getHolidayExportRows(app) {
  return [
    ["id", "data", "descricao", "tipo", "abrangencia", "ativo", "criadoEm", "atualizadoEm"],
    ...app.state.holidays.map(item => [item.id, item.data, item.descricao, item.tipo, item.abrangencia, item.ativo !== false, item.criadoEm || "", item.atualizadoEm || ""])
  ];
}

export function exportHolidaysCsv(app) {
  downloadCsv("feriados.csv", getHolidayExportRows(app));
}

export function exportHolidaysExcel(app) {
  downloadExcelXml("relacao-feriados.xls", "Feriados", getHolidayExportRows(app));
}

async function toggleHoliday(app, holiday) {
  const updated = { ...holiday, ativo: holiday.ativo === false, atualizadoEm: nowIsoDateTime() };
  await app.provider.saveHoliday(updated);
  await app.provider.addAudit({ acao: updated.ativo ? "ATIVAR_FERIADO" : "INATIVAR_FERIADO", entidade: "Feriados", registroId: updated.id, detalheAnterior: JSON.stringify(holiday), detalheNovo: JSON.stringify(updated) });
  await app.recalculateVacations();
  await app.reloadData();
  app.showToast(updated.ativo ? "Registro ativado." : "Registro inativado.");
}

async function deleteHoliday(app, holiday) {
  if (!confirm("Excluir este registro?")) return;
  await app.provider.deleteHoliday(holiday.id);
  await app.provider.addAudit({ acao: "EXCLUIR_FERIADO", entidade: "Feriados", registroId: holiday.id, detalheAnterior: JSON.stringify(holiday) });
  await app.recalculateVacations();
  await app.reloadData();
  app.showToast("Registro excluído ou inativado conforme o provedor.");
}

function getCsvValue(headers, row, key) {
  const index = headers.indexOf(normalizeText(key));
  return index >= 0 ? String(row[index] || "").trim() : "";
}

function fillSelect(selector, values, allLabel) {
  const select = document.querySelector(selector);
  const previous = select.value;
  select.innerHTML = "";
  select.append(el("option", { value: "", text: allLabel }));
  values.forEach(value => select.append(el("option", { value, text: value })));
  select.value = values.includes(previous) ? previous : "";
}

function header(values) {
  const thead = el("thead");
  const tr = el("tr");
  values.forEach(value => tr.append(el("th", { text: value })));
  thead.append(tr);
  return thead;
}

function actionButton(text, handler, tone = "secondary") {
  const button = el("button", { type: "button", class: `btn ${tone}`, text });
  button.addEventListener("click", handler);
  return button;
}
