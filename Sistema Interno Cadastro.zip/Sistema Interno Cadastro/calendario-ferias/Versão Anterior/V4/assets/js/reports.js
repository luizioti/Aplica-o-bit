import { employeeTotals } from "./calendar.js";
import { getHolidayExportRows } from "./holidays.js";
import { getVacationExportRows } from "./vacations.js";
import {
  ACTIVE_ABSENCE_STATUSES,
  availableMonthsForYear,
  clearChildren,
  downloadExcelXml,
  el,
  formatDateBR,
  getMonthName,
  monthDates,
  sortByName
} from "./utils.js";

export function renderReports(app) {
  const container = document.querySelector("#reportContainer");
  clearChildren(container);
  container.append(
    panel("Total de férias por colaborador", table(["Colaborador", "Equipe", "Dias corridos", "Dias úteis", "Períodos"], vacationTotalsRows(app))),
    panel("Colaboradores ausentes por dia", table(["Data", "Ausentes", "Nomes"], dailyAbsencesRows(app))),
    panel("Períodos por status", table(["Status", "Quantidade"], statusRows(app))),
    panel("Meses com maior concentração", table(["Mês", "Dias com ausência", "Ausências registradas"], concentrationRows(app))),
    panel("Datas acima do limite", table(["Data", "Quantidade", "Nomes"], conflictRows(app))),
    panel("Colaboradores sem férias no ano", table(["Colaborador", "Equipe"], noVacationRows(app)))
  );
}

export function exportReport(app, kind) {
  if (kind === "vacations") downloadExcelXml("relacao-ferias.xls", "Ferias", getVacationExportRows(app));
  if (kind === "holidays") downloadExcelXml("relacao-feriados.xls", "Feriados", getHolidayExportRows(app));
}

function vacationTotalsRows(app) {
  return app.state.employees.slice().sort(sortByName).map(employee => {
    const totals = employeeTotals(app, employee.id, app.selectedYear, 0);
    return [employee.nome, employee.equipe || "", totals.yearCalendarDays, totals.yearCalendarDays ? yearBusinessDays(app, employee.id) : 0, totals.yearPeriods];
  });
}

function dailyAbsencesRows(app) {
  const rows = [];
  yearDates(app).forEach(date => {
    const names = activeAbsencesForDate(app, date).map(item => item.nome);
    if (names.length) rows.push([formatDateBR(date), names.length, names.join(", ")]);
  });
  return rows;
}

function statusRows(app) {
  return ["Planejada", "Solicitada", "Aprovada", "Cancelada"].map(status => [
    status,
    app.state.vacations.filter(item => item.status === status && item.dataInicio.startsWith(String(app.selectedYear))).length
  ]);
}

function concentrationRows(app) {
  return availableMonthsForYear(app.selectedYear).map(monthIndex => {
    const dates = monthDates(app.selectedYear, monthIndex);
    let daysWithAbsence = 0;
    let absenceRecords = 0;
    dates.forEach(date => {
      const count = activeAbsencesForDate(app, date).length;
      if (count) daysWithAbsence += 1;
      absenceRecords += count;
    });
    return [getMonthName(monthIndex), daysWithAbsence, absenceRecords];
  }).sort((a, b) => b[2] - a[2]);
}

function conflictRows(app) {
  const limit = Number(app.state.settings.limiteAusenciasSimultaneas || 2);
  return yearDates(app).map(date => {
    const names = activeAbsencesForDate(app, date).map(item => item.nome);
    return [date, names];
  }).filter(([, names]) => names.length > limit)
    .map(([date, names]) => [formatDateBR(date), names.length, names.join(", ")]);
}

function noVacationRows(app) {
  return app.state.employees
    .filter(employee => !app.state.vacations.some(vacation => vacation.colaboradorId === employee.id && vacation.status !== "Cancelada" && vacation.dataInicio.startsWith(String(app.selectedYear))))
    .sort(sortByName)
    .map(employee => [employee.nome, employee.equipe || ""]);
}

function yearBusinessDays(app, employeeId) {
  const dates = new Set();
  app.state.vacations
    .filter(item => item.colaboradorId === employeeId && item.status !== "Cancelada")
    .forEach(item => {
      yearDates(app).forEach(date => {
        if (item.dataInicio <= date && date <= item.dataFim) dates.add(date);
      });
    });
  return [...dates].filter(date => businessDate(app, date)).length;
}

function businessDate(app, date) {
  const day = new Date(`${date}T00:00:00`).getDay();
  const holiday = app.state.holidays.find(item => item.ativo !== false && item.data === date);
  return day !== 0 && day !== 6 && !holiday;
}

function activeAbsencesForDate(app, date) {
  return app.state.vacations
    .filter(item => ACTIVE_ABSENCE_STATUSES.includes(item.status) && item.dataInicio <= date && date <= item.dataFim)
    .map(item => app.state.employees.find(employee => employee.id === item.colaboradorId))
    .filter(Boolean);
}

function yearDates(app) {
  return availableMonthsForYear(app.selectedYear).flatMap(monthIndex => monthDates(app.selectedYear, monthIndex));
}

function panel(title, content) {
  return el("section", { class: "report-panel" }, [
    el("h3", { text: title }),
    content
  ]);
}

function table(headers, rows) {
  const tableElement = el("table", { class: "data-table" });
  const thead = el("thead");
  const headRow = el("tr");
  headers.forEach(header => headRow.append(el("th", { text: header })));
  thead.append(headRow);
  const tbody = el("tbody");
  rows.forEach(row => {
    const tr = el("tr");
    row.forEach(value => tr.append(el("td", { text: String(value) })));
    tbody.append(tr);
  });
  if (!rows.length) {
    const tr = el("tr");
    tr.append(el("td", { text: "Sem registros", colSpan: headers.length }));
    tbody.append(tr);
  }
  tableElement.append(thead, tbody);
  return tableElement;
}
