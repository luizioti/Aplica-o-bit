export const APP_START = "2026-06-01";
export const APP_END = "2028-12-31";
export const YEARS = [2026, 2027, 2028];
export const STATUSES = ["Planejada", "Solicitada", "Aprovada", "Cancelada"];
export const ACTIVE_ABSENCE_STATUSES = ["Solicitada", "Aprovada"];

const WEEKDAYS = ["DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SAB"];
const WEEKDAYS_FULL = ["domingo", "segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado"];
const MONTHS = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];

export function uuid() {
  if (crypto?.randomUUID) return crypto.randomUUID();
  return "id-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2);
}

export function nowIsoDateTime() {
  return new Date().toISOString();
}

export function parseISO(value) {
  if (!value) return null;
  const [year, month, day] = value.split("-").map(Number);
  return new Date(year, month - 1, day);
}

export function toISODate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function todayISO() {
  return toISODate(new Date());
}

export function formatDateBR(value) {
  if (!value) return "";
  const [year, month, day] = value.split("-");
  return `${day}/${month}/${year}`;
}

export function formatDateTimeBR(value) {
  if (!value) return "--";
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "short" }).format(new Date(value));
}

export function addDays(value, amount) {
  const date = typeof value === "string" ? parseISO(value) : new Date(value);
  date.setDate(date.getDate() + amount);
  return toISODate(date);
}

export function compareISO(a, b) {
  return a.localeCompare(b);
}

export function isWithinAppRange(dateISO) {
  return compareISO(dateISO, APP_START) >= 0 && compareISO(dateISO, APP_END) <= 0;
}

export function daysBetweenInclusive(startISO, endISO) {
  if (!startISO || !endISO || compareISO(startISO, endISO) > 0) return 0;
  let count = 0;
  for (let cursor = startISO; compareISO(cursor, endISO) <= 0; cursor = addDays(cursor, 1)) count += 1;
  return count;
}

export function dateRange(startISO, endISO) {
  const dates = [];
  if (!startISO || !endISO || compareISO(startISO, endISO) > 0) return dates;
  for (let cursor = startISO; compareISO(cursor, endISO) <= 0; cursor = addDays(cursor, 1)) dates.push(cursor);
  return dates;
}

export function getMonthName(monthIndex) {
  return MONTHS[monthIndex];
}

export function getWeekdayShort(dateISO) {
  return WEEKDAYS[parseISO(dateISO).getDay()];
}

export function getWeekdayFull(dateISO) {
  return WEEKDAYS_FULL[parseISO(dateISO).getDay()];
}

export function isWeekend(dateISO) {
  const day = parseISO(dateISO).getDay();
  return day === 0 || day === 6;
}

export function daysInMonth(year, monthIndex) {
  return new Date(year, monthIndex + 1, 0).getDate();
}

export function monthDates(year, monthIndex) {
  const total = daysInMonth(year, monthIndex);
  return Array.from({ length: total }, (_, index) => toISODate(new Date(year, monthIndex, index + 1)));
}

export function availableMonthsForYear(year) {
  const start = year === 2026 ? 5 : 0;
  return Array.from({ length: 12 - start }, (_, index) => start + index);
}

export function overlapRanges(aStart, aEnd, bStart, bEnd) {
  return compareISO(aStart, bEnd) <= 0 && compareISO(bStart, aEnd) <= 0;
}

export function normalizeText(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

export function sortByName(a, b) {
  return String(a.nome || "").localeCompare(String(b.nome || ""), "pt-BR");
}

export function activeHolidayForDate(holidays, dateISO) {
  return holidays.find(item => item.ativo !== false && item.data === dateISO);
}

export function isBusinessDay(dateISO, holidays = []) {
  return !isWeekend(dateISO) && !activeHolidayForDate(holidays, dateISO);
}

export function countBusinessDays(startISO, endISO, holidays = []) {
  return dateRange(startISO, endISO).filter(date => isBusinessDay(date, holidays)).length;
}

export function computeVacationCounts(vacation, holidays = []) {
  return {
    quantidadeDiasCorridos: daysBetweenInclusive(vacation.dataInicio, vacation.dataFim),
    quantidadeDiasUteis: countBusinessDays(vacation.dataInicio, vacation.dataFim, holidays)
  };
}

export function uniqueVacationDates(vacations, rangeStart, rangeEnd, includeCanceled = false) {
  const dates = new Set();
  vacations
    .filter(item => includeCanceled || item.status !== "Cancelada")
    .forEach(item => {
      dateRange(
        compareISO(item.dataInicio, rangeStart) < 0 ? rangeStart : item.dataInicio,
        compareISO(item.dataFim, rangeEnd) > 0 ? rangeEnd : item.dataFim
      ).forEach(date => dates.add(date));
    });
  return dates;
}

export function downloadBlob(filename, content, type) {
  const blob = content instanceof Blob ? content : new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export function downloadJson(filename, data) {
  downloadBlob(filename, JSON.stringify(data, null, 2), "application/json;charset=utf-8");
}

export function toCsv(rows) {
  return rows.map(row => row.map(value => {
    const text = String(value ?? "");
    return /[",\n;]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
  }).join(";")).join("\n");
}

export function parseCsv(text) {
  const rows = [];
  let row = [];
  let value = "";
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];
    if (quoted && char === '"' && next === '"') {
      value += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (!quoted && (char === ";" || char === ",")) {
      row.push(value);
      value = "";
    } else if (!quoted && (char === "\n" || char === "\r")) {
      if (char === "\r" && next === "\n") index += 1;
      row.push(value);
      rows.push(row);
      row = [];
      value = "";
    } else {
      value += char;
    }
  }
  if (value || row.length) {
    row.push(value);
    rows.push(row);
  }
  return rows.filter(item => item.some(cell => cell.trim() !== ""));
}

export function downloadCsv(filename, rows) {
  downloadBlob(filename, "\ufeff" + toCsv(rows), "text/csv;charset=utf-8");
}

export function tableToExcelXml(sheetName, rows) {
  const xmlEscape = value => String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
  const data = rows.map(row => `<Row>${row.map(value => `<Cell><Data ss:Type="String">${xmlEscape(value)}</Data></Cell>`).join("")}</Row>`).join("");
  return `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <Worksheet ss:Name="${xmlEscape(sheetName).slice(0, 31)}">
  <Table>${data}</Table>
 </Worksheet>
</Workbook>`;
}

export function downloadExcelXml(filename, sheetName, rows) {
  downloadBlob(filename, tableToExcelXml(sheetName, rows), "application/vnd.ms-excel;charset=utf-8");
}

export function readFileText(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsText(file, "utf-8");
  });
}

export function clearChildren(element) {
  while (element.firstChild) element.removeChild(element.firstChild);
}

export function el(tag, options = {}, children = []) {
  const node = document.createElement(tag);
  Object.entries(options).forEach(([key, value]) => {
    if (key === "class") node.className = value;
    else if (key === "text") node.textContent = value;
    else if (key === "dataset") Object.assign(node.dataset, value);
    else if (key === "aria") Object.entries(value).forEach(([ariaKey, ariaValue]) => node.setAttribute(`aria-${ariaKey}`, ariaValue));
    else if (key in node) node[key] = value;
    else node.setAttribute(key, value);
  });
  children.forEach(child => node.append(child));
  return node;
}

export function debounce(fn, wait = 200) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}
