import { employeeTotals, getAbsenceMap } from "./calendar.js";
import { validateVacation } from "./validation.js";
import {
  ACTIVE_ABSENCE_STATUSES,
  clearChildren,
  compareISO,
  computeVacationCounts,
  dateRange,
  downloadExcelXml,
  el,
  formatDateBR,
  nowIsoDateTime,
  normalizeText,
  sortByName,
  uuid
} from "./utils.js";

export function renderVacationForm(app) {
  const select = document.querySelector("#vacationEmployee");
  const previous = select.value;
  select.innerHTML = "";
  app.state.employees.filter(item => item.ativo !== false).sort(sortByName).forEach(employee => {
    select.append(el("option", { value: employee.id, text: `${employee.nome} - ${employee.equipe}` }));
  });
  if (previous) select.value = previous;
  updateVacationCount(app);
}

export function renderVacationList(app) {
  const container = document.querySelector("#vacationList");
  clearChildren(container);
  const query = normalizeText(document.querySelector("#vacationSearch").value);
  const rows = app.state.vacations
    .map(vacation => ({ vacation, employee: app.state.employees.find(item => item.id === vacation.colaboradorId) }))
    .filter(item => item.employee)
    .filter(item => !query || normalizeText(`${item.employee.nome} ${item.vacation.status} ${item.vacation.observacao}`).includes(query))
    .sort((a, b) => compareISO(a.vacation.dataInicio, b.vacation.dataInicio));

  if (!rows.length) {
    container.append(el("div", { class: "empty-state", text: "Nenhum período cadastrado." }));
    return;
  }

  const table = el("table", { class: "data-table" });
  table.append(row("thead", ["Colaborador", "Início", "Fim", "Corridos", "Úteis", "Status", "Observação", "Ações"], "th"));
  const tbody = el("tbody");
  rows.forEach(({ vacation, employee }) => {
    const tr = el("tr");
    [
      employee.nome,
      formatDateBR(vacation.dataInicio),
      formatDateBR(vacation.dataFim),
      vacation.quantidadeDiasCorridos,
      vacation.quantidadeDiasUteis,
      vacation.status,
      vacation.observacao || ""
    ].forEach(value => tr.append(el("td", { text: String(value) })));
    const actions = el("td", { class: "actions" });
    actions.append(actionButton("Editar", () => fillVacationForm(vacation)));
    actions.append(actionButton("Duplicar", () => duplicateVacation(app, vacation)));
    actions.append(actionButton("Cancelar", () => cancelVacation(app, vacation), "danger"));
    actions.append(actionButton("Excluir", () => deleteVacation(app, vacation), "danger"));
    tr.append(actions);
    tbody.append(tr);
  });
  table.append(tbody);
  container.append(table);
}

export function fillVacationForm(vacation) {
  document.querySelector("#vacationId").value = vacation.id || "";
  document.querySelector("#vacationEmployee").value = vacation.colaboradorId || "";
  document.querySelector("#vacationStart").value = vacation.dataInicio || "";
  document.querySelector("#vacationEnd").value = vacation.dataFim || "";
  document.querySelector("#vacationStatus").value = vacation.status || "Planejada";
  document.querySelector("#vacationNote").value = vacation.observacao || "";
  document.querySelector("#vacationForm").scrollIntoView({ behavior: "smooth", block: "start" });
  document.querySelector("#vacationStart").dispatchEvent(new Event("input"));
}

export async function saveVacationFromForm(app) {
  const saveButton = document.querySelector("#saveVacationBtn");
  saveButton.disabled = true;
  try {
    const id = document.querySelector("#vacationId").value || uuid();
    const existing = app.state.vacations.find(item => item.id === id);
    const now = nowIsoDateTime();
    const vacation = {
      id,
      colaboradorId: document.querySelector("#vacationEmployee").value,
      dataInicio: document.querySelector("#vacationStart").value,
      dataFim: document.querySelector("#vacationEnd").value,
      status: document.querySelector("#vacationStatus").value,
      observacao: document.querySelector("#vacationNote").value.trim(),
      criadoPor: existing?.criadoPor || app.provider.user,
      criadoEm: existing?.criadoEm || now,
      atualizadoPor: app.provider.user,
      atualizadoEm: now
    };
    Object.assign(vacation, computeVacationCounts(vacation, app.state.holidays));
    const errors = validateVacation(vacation, app.state, existing?.id || "");
    if (errors.length) {
      app.showToast(errors.join(" "));
      return;
    }
    await app.provider.saveVacation(vacation);
    await app.provider.addAudit({
      acao: existing ? "EDITAR_FERIAS" : "CRIAR_FERIAS",
      entidade: "Ferias",
      registroId: vacation.id,
      detalheAnterior: existing ? JSON.stringify(existing) : "",
      detalheNovo: JSON.stringify(vacation)
    });
    await app.reloadData();
    resetVacationForm();
    app.showToast("Férias salvas com sucesso.");
  } finally {
    saveButton.disabled = false;
  }
}

export function resetVacationForm() {
  document.querySelector("#vacationId").value = "";
  document.querySelector("#vacationForm").reset();
  document.querySelector("#vacationStatus").value = "Planejada";
  document.querySelector("#vacationCount").textContent = "Dias corridos: 0 | Dias úteis: 0";
  document.querySelector("#vacationAlert").textContent = "";
}

export function updateVacationCount(app) {
  const start = document.querySelector("#vacationStart").value;
  const end = document.querySelector("#vacationEnd").value;
  const employeeId = document.querySelector("#vacationEmployee").value;
  const output = document.querySelector("#vacationCount");
  const alert = document.querySelector("#vacationAlert");
  alert.textContent = "";
  if (!start || !end || compareISO(start, end) > 0) {
    output.textContent = "Dias corridos: 0 | Dias úteis: 0";
    return;
  }
  const counts = computeVacationCounts({ dataInicio: start, dataFim: end }, app.state.holidays);
  output.textContent = `Dias corridos: ${counts.quantidadeDiasCorridos} | Dias úteis: ${counts.quantidadeDiasUteis}`;

  const dates = dateRange(start, end);
  const absenceMap = getAbsenceMap(app, dates);
  const limit = Number(app.state.settings.limiteAusenciasSimultaneas || 2);
  const conflicts = dates.filter(date => {
    const ids = new Set((absenceMap.get(date) || []).map(item => item.id));
    if (employeeId) ids.add(employeeId);
    return ids.size > limit;
  });
  if (conflicts.length) {
    alert.textContent = `Aviso gerencial: ${conflicts.length} dia(s) ultrapassam o limite de ausências simultâneas.`;
  }
}

export function getVacationExportRows(app) {
  return [
    ["id", "colaborador", "equipe", "dataInicio", "dataFim", "quantidadeDiasCorridos", "quantidadeDiasUteis", "status", "observacao", "criadoPor", "criadoEm", "atualizadoPor", "atualizadoEm"],
    ...app.state.vacations.map(vacation => {
      const employee = app.state.employees.find(item => item.id === vacation.colaboradorId);
      return [
        vacation.id,
        employee?.nome || "",
        employee?.equipe || "",
        vacation.dataInicio,
        vacation.dataFim,
        vacation.quantidadeDiasCorridos,
        vacation.quantidadeDiasUteis,
        vacation.status,
        vacation.observacao || "",
        vacation.criadoPor || "",
        vacation.criadoEm || "",
        vacation.atualizadoPor || "",
        vacation.atualizadoEm || ""
      ];
    })
  ];
}

export function exportVacations(app) {
  downloadExcelXml("relacao-ferias.xls", "Ferias", getVacationExportRows(app));
}

async function duplicateVacation(app, vacation) {
  const copy = {
    ...vacation,
    id: uuid(),
    status: "Planejada",
    observacao: `${vacation.observacao || ""} (cópia)`.trim(),
    criadoPor: app.provider.user,
    criadoEm: nowIsoDateTime(),
    atualizadoPor: app.provider.user,
    atualizadoEm: nowIsoDateTime()
  };
  const errors = validateVacation(copy, app.state);
  if (errors.length) {
    app.showToast(errors.join(" "));
    return;
  }
  await app.provider.saveVacation(copy);
  await app.provider.addAudit({ acao: "DUPLICAR_FERIAS", entidade: "Ferias", registroId: copy.id, detalheNovo: JSON.stringify(copy) });
  await app.reloadData();
  app.showToast("Período duplicado.");
}

async function cancelVacation(app, vacation) {
  if (!confirm("Cancelar este período de férias?")) return;
  const updated = { ...vacation, status: "Cancelada", atualizadoPor: app.provider.user, atualizadoEm: nowIsoDateTime() };
  await app.provider.saveVacation(updated);
  await app.provider.addAudit({ acao: "CANCELAR_FERIAS", entidade: "Ferias", registroId: updated.id, detalheAnterior: JSON.stringify(vacation), detalheNovo: JSON.stringify(updated) });
  await app.reloadData();
  app.showToast("Período cancelado.");
}

async function deleteVacation(app, vacation) {
  if (!confirm("Excluir definitivamente este período no modo local? No Graph, a exclusão será lógica quando configurada.")) return;
  await app.provider.deleteVacation(vacation.id);
  await app.provider.addAudit({ acao: "EXCLUIR_FERIAS", entidade: "Ferias", registroId: vacation.id, detalheAnterior: JSON.stringify(vacation) });
  await app.reloadData();
  app.showToast("Período excluído ou cancelado conforme o provedor.");
}

function actionButton(text, handler, tone = "secondary") {
  const button = el("button", { type: "button", class: `btn ${tone}`, text });
  button.addEventListener("click", handler);
  return button;
}

function row(sectionTag, values, cellTag) {
  const section = el(sectionTag);
  const tr = el("tr");
  values.forEach(value => tr.append(el(cellTag, { text: value })));
  section.append(tr);
  return section;
}
