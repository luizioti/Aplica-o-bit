import { APP_END, APP_START, STATUSES, compareISO, isWithinAppRange, normalizeText, overlapRanges } from "./utils.js";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function validateEmployee(data) {
  const errors = [];
  if (!String(data.nome || "").trim()) errors.push("Informe o nome do colaborador.");
  if (!String(data.equipe || "").trim()) errors.push("Informe a equipe.");
  if (data.email && !EMAIL_RE.test(data.email)) errors.push("Informe um e-mail válido.");
  return errors;
}

export function validateHoliday(data) {
  const errors = [];
  if (!data.data || !isWithinAppRange(data.data)) errors.push(`A data deve estar entre ${APP_START} e ${APP_END}.`);
  if (!String(data.descricao || "").trim()) errors.push("Informe a descrição.");
  if (!data.tipo) errors.push("Informe o tipo.");
  if (!data.abrangencia) errors.push("Informe a abrangência.");
  return errors;
}

export function validateVacation(data, state, editingId = "") {
  const errors = [];
  const employee = state.employees.find(item => item.id === data.colaboradorId);
  if (!employee) errors.push("Selecione um colaborador válido.");
  if (employee && employee.ativo === false) errors.push("O colaborador selecionado está inativo.");
  if (!data.dataInicio || !data.dataFim) errors.push("Informe a data inicial e final.");
  if (data.dataInicio && data.dataFim && compareISO(data.dataInicio, data.dataFim) > 0) errors.push("A data inicial deve ser menor ou igual à data final.");
  if (data.dataInicio && !isWithinAppRange(data.dataInicio)) errors.push(`A data inicial deve estar entre ${APP_START} e ${APP_END}.`);
  if (data.dataFim && !isWithinAppRange(data.dataFim)) errors.push(`A data final deve estar entre ${APP_START} e ${APP_END}.`);
  if (!STATUSES.includes(data.status)) errors.push("Informe um status válido.");

  if (data.colaboradorId && data.dataInicio && data.dataFim && data.status !== "Cancelada") {
    const overlapping = state.vacations.find(item =>
      item.id !== editingId &&
      item.colaboradorId === data.colaboradorId &&
      item.status !== "Cancelada" &&
      overlapRanges(data.dataInicio, data.dataFim, item.dataInicio, item.dataFim)
    );
    if (overlapping) {
      errors.push(`Sobreposição encontrada com período de ${overlapping.dataInicio} a ${overlapping.dataFim}.`);
    }
  }

  return errors;
}

export function filterBySearch(value, query) {
  if (!query) return true;
  return normalizeText(value).includes(normalizeText(query));
}
