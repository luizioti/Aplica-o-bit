window.CALENDARIO_FERIAS_CONFIG = {
  environment: "development",
  dataProvider: "local",
  graph: {
    tenantId: "INFORME_TENANT_ID",
    clientId: "INFORME_CLIENT_ID",
    siteId: "INFORME_SITE_ID",
    driveId: "INFORME_DRIVE_ID",
    itemId: "INFORME_ITEM_ID_DO_EXCEL",
    scopes: ["User.Read", "Files.ReadWrite.All", "Sites.ReadWrite.All"],
    tableNames: {
      colaboradores: "tbColaboradores",
      ferias: "tbFerias",
      feriados: "tbFeriados",
      configuracoes: "tbConfiguracoes",
      auditoria: "tbAuditoria"
    }
  }
};
