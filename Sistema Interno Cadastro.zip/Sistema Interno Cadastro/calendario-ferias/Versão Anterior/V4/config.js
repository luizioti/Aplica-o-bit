window.CALENDARIO_FERIAS_CONFIG = {
  environment: "development",
  dataProvider: "local"
};
