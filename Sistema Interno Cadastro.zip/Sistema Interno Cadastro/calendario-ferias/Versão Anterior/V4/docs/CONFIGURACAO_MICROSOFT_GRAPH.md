# Configuração Microsoft Graph

Este app está preparado para ler e gravar tabelas estruturadas em um arquivo Excel hospedado no OneDrive ou SharePoint por meio do Microsoft Graph.

## 1. Preparar o Excel

1. Publique `excel/Modelo_Calendario_Ferias.xlsx` em uma biblioteca do SharePoint ou no OneDrive corporativo.
2. Mantenha os nomes das abas e tabelas estruturadas.
3. Não remova nem renomeie colunas obrigatórias.
4. Garanta que as datas estejam em `YYYY-MM-DD`.

## 2. Registrar o aplicativo no Entra ID

1. Acesse Microsoft Entra ID.
2. Crie um novo registro de aplicativo.
3. Tipo de plataforma: SPA.
4. Redirect URI: URL HTTPS em que o app será publicado.
5. Não crie Client Secret.
6. Copie o `Application (client) ID`.
7. Copie o `Directory (tenant) ID`.

## 3. Permissões delegadas

Permissões sugeridas:

- `User.Read`
- `Files.ReadWrite.All`
- `Sites.ReadWrite.All`

O administrador pode exigir consentimento. Em ambientes com política mais restritiva, use escopos equivalentes limitados ao site e ao drive do arquivo.

## 4. Obter IDs do arquivo

O GraphExcelProvider usa:

- `tenantId`
- `clientId`
- `siteId`
- `driveId`
- `itemId`

Esses valores podem ser obtidos por Microsoft Graph Explorer, scripts administrativos ou página de detalhes do arquivo no SharePoint.

## 5. Criar config.js

Copie:

```text
config.example.js
```

para:

```text
config.js
```

Exemplo:

```js
window.CALENDARIO_FERIAS_CONFIG = {
  environment: "production",
  dataProvider: "graph",
  graph: {
    tenantId: "00000000-0000-0000-0000-000000000000",
    clientId: "00000000-0000-0000-0000-000000000000",
    siteId: "contoso.sharepoint.com,site-id,web-id",
    driveId: "drive-id",
    itemId: "excel-item-id",
    scopes: ["User.Read", "Files.ReadWrite.All", "Sites.ReadWrite.All"],
    tableNames: {
      colaboradores: "tbColaboradores",
      ferias: "tbFerias",
      feriados: "tbFeriados",
      configuracoes: "tbConfiguracoes",
      auditoria: "tbAuditoria"
    }
  }
};
```

O arquivo real está no `.gitignore`.

## 6. MSAL

Inclua a biblioteca oficial MSAL no HTML publicado ou no pacote corporativo autorizado:

```html
<script src="https://alcdn.msauth.net/browser/2.38.0/js/msal-browser.min.js"></script>
```

Use uma versão aprovada pela TI. A aplicação não armazena token manualmente; a biblioteca MSAL gerencia a sessão.

## 7. Status de sincronização

Status previstos:

- Conectando
- Sincronizado
- Salvando
- Atualização disponível
- Sem conexão
- Erro de sincronização
- Modo local
- Sessão expirada

Quando Graph não está configurado ou falha no início, o app entra em modo local e exibe o aviso correspondente.

## 8. Limitações da integração preparada

O provedor Graph foi implementado para ler tabelas e gravar linhas via Microsoft Graph. A validação completa depende do ambiente real:

- Consentimento administrativo.
- CORS e origem HTTPS permitida.
- Arquivo Excel acessível ao usuário autenticado.
- Tabelas estruturadas com os nomes corretos.
- Políticas corporativas de sessão e MFA.

Não há dependência de abrir o Excel no computador do usuário, caminhos locais ou `file://`.
