# Estrutura do Excel

Todas as datas devem ser registradas em ISO `YYYY-MM-DD`. Na interface, elas são exibidas em `DD/MM/AAAA`.

## Aba Colaboradores

Tabela: `tbColaboradores`

| Coluna | Tipo | Obrigatório | Observação |
|---|---|---:|---|
| id | texto UUID | sim | Não alterar manualmente depois de criado. |
| nome | texto | sim | Nome exibido no calendário. |
| equipe | texto | sim | Usado em filtros e agrupamentos. |
| cargo | texto | não | Informação complementar. |
| email | texto | não | Usado para identificação. |
| ativo | booleano | sim | `true` ou `false`. |
| dataInclusao | data/hora ISO | sim | Preenchido pelo sistema. |
| atualizadoEm | data/hora ISO | sim | Preenchido pelo sistema. |

## Aba Ferias

Tabela: `tbFerias`

| Coluna | Tipo | Obrigatório | Observação |
|---|---|---:|---|
| id | texto UUID | sim | Identificador do período. |
| colaboradorId | texto UUID | sim | Deve existir em `tbColaboradores[id]`. |
| dataInicio | data ISO | sim | Início do período. |
| dataFim | data ISO | sim | Fim do período. |
| quantidadeDiasCorridos | número | sim | Calculado pelo sistema. |
| quantidadeDiasUteis | número | sim | Calculado pelo sistema conforme feriados ativos. |
| status | texto | sim | Planejada, Solicitada, Aprovada ou Cancelada. |
| observacao | texto | não | Comentário livre. |
| criadoPor | texto | sim | Usuário do registro. |
| criadoEm | data/hora ISO | sim | Preenchido pelo sistema. |
| atualizadoPor | texto | sim | Usuário da última alteração. |
| atualizadoEm | data/hora ISO | sim | Preenchido pelo sistema. |

## Aba Feriados

Tabela: `tbFeriados`

| Coluna | Tipo | Obrigatório | Observação |
|---|---|---:|---|
| id | texto UUID | sim | Identificador do registro. |
| data | data ISO | sim | Data do feriado ou dia não útil. |
| descricao | texto | sim | Nome do evento. |
| tipo | texto | sim | Feriado, Ponto facultativo, Folga institucional ou Outro dia não útil. |
| abrangencia | texto | sim | Nacional, Estadual, Municipal ou Empresa. |
| ativo | booleano | sim | Registros inativos ficam no histórico. |
| criadoEm | data/hora ISO | sim | Preenchido pelo sistema. |
| atualizadoEm | data/hora ISO | sim | Preenchido pelo sistema. |

## Aba Configuracoes

Tabela: `tbConfiguracoes`

| Coluna | Tipo | Obrigatório | Observação |
|---|---|---:|---|
| chave | texto | sim | Identificador da configuração. |
| valor | texto | sim | Valor serializado. |
| descricao | texto | não | Ajuda administrativa. |

Configurações iniciais:

| chave | valor |
|---|---|
| dataInicial | 2026-06-01 |
| dataFinal | 2028-12-31 |
| limiteAusenciasSimultaneas | 2 |
| intervaloAtualizacaoSegundos | 60 |
| contarFeriasEmDiasCorridos | true |

## Aba Auditoria

Tabela: `tbAuditoria`

| Coluna | Tipo | Obrigatório | Observação |
|---|---|---:|---|
| id | texto UUID | sim | Identificador do evento. |
| dataHora | data/hora ISO | sim | Momento da operação. |
| usuario | texto | sim | Usuário local ou Microsoft. |
| acao | texto | sim | Operação executada. |
| entidade | texto | sim | Área afetada. |
| registroId | texto | sim | Identificador do registro afetado. |
| detalheAnterior | texto JSON | não | Estado anterior. |
| detalheNovo | texto JSON | não | Estado novo. |

## Campos que não devem ser alterados manualmente

- `id`
- `colaboradorId`, exceto em carga administrativa controlada.
- `quantidadeDiasCorridos`
- `quantidadeDiasUteis`
- `criadoPor`
- `criadoEm`
- `atualizadoPor`
- `atualizadoEm`
- Registros de `tbAuditoria`
