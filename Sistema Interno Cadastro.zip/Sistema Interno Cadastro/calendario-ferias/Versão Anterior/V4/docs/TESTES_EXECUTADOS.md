# Testes Executados

Data de execução: 2026-06-15

Ambiente: aplicação estática em navegador local, regras testadas por `tests/run-tests.mjs` e verificação visual em servidor HTTP local.

| # | Teste realizado | Resultado esperado | Resultado obtido | Situação | Correção aplicada |
|---:|---|---|---|---|---|
| 1 | Junho de 2026 começar corretamente | Primeiro mês exibido para 2026 é junho | Validado por regra de meses | Aprovado | Não aplicável |
| 2 | Dezembro de 2028 ser o último mês permitido | Último mês de 2028 é dezembro | Validado | Aprovado | Não aplicável |
| 3 | Fevereiro de 2028 possuir 29 dias | 29 dias | Validado | Aprovado | Não aplicável |
| 4 | Sábados e domingos identificados | Finais de semana marcados | Validado | Aprovado | Não aplicável |
| 5 | Feriados alterarem identificação visual | Classe de feriado e dia não útil | Validado | Aprovado | Não aplicável |
| 6 | Pontos facultativos diferentes de feriados | Classe própria | Validado | Aprovado | Não aplicável |
| 7 | Férias de um único dia | 1 dia corrido | Validado | Aprovado | Não aplicável |
| 8 | Férias atravessando final de semana | Dias corridos incluem sábado/domingo | Validado | Aprovado | Não aplicável |
| 9 | Férias atravessando feriado | Corridos incluem feriado; úteis excluem | Validado | Aprovado | Não aplicável |
| 10 | Férias atravessando dois meses | Cada mês conta apenas seus dias | Validado | Aprovado | Não aplicável |
| 11 | Férias atravessando dois anos | Cada ano conta apenas seus dias | Validado | Aprovado | Não aplicável |
| 12 | Período invertido | Validação bloqueia | Validado | Aprovado | Não aplicável |
| 13 | Período fora do intervalo | Validação bloqueia | Validado | Aprovado | Não aplicável |
| 14 | Períodos sobrepostos | Validação informa sobreposição | Validado | Aprovado | Não aplicável |
| 15 | Cálculo de dias corridos | Contagem inclusiva | Validado | Aprovado | Não aplicável |
| 16 | Cálculo de dias úteis | Exclui fim de semana e feriados ativos | Validado | Aprovado | Não aplicável |
| 17 | Total mensal no final da linha | Conta apenas mês atual | Validado | Aprovado | Não aplicável |
| 18 | Total anual no final da linha | Conta ano selecionado sem duplicidade | Validado | Aprovado | Não aplicável |
| 19 | Inativação de colaborador | Registro permanece histórico | Validado na interface | Aprovado | Não aplicável |
| 20 | Atualização de feriado usado no cálculo | Recalcula dias úteis | Validado por função de recalculo | Aprovado | Não aplicável |
| 21 | Filtros individuais e combinados | Atualizam calendário e relatórios | Validado na interface | Aprovado | Não aplicável |
| 22 | Limpeza de filtros | Retorna ao estado padrão | Validado na interface | Aprovado | Não aplicável |
| 23 | Exportação para Excel | Arquivo compatível com Excel | Validado por geração XML Spreadsheet | Aprovado | Não aplicável |
| 24 | Backup e restauração em JSON | Exporta e restaura dados locais | Validado por fluxo local | Aprovado | Não aplicável |
| 25 | Falha de internet | Graph indisponível cai para modo local | Validado por ausência de configuração Graph | Aprovado | Não aplicável |
| 26 | Sessão Microsoft expirada | Erro tratado e orienta autenticação | Tratamento implementado | Pendente ambiente real | Depende do tenant |
| 27 | Dados inválidos retornados pelo Excel | Erros tratados em mensagem | Tratamento implementado | Pendente ambiente real | Depende do arquivo real |
| 28 | Visualização em resolução de notebook | Layout responsivo e rolagem horizontal | CSS responsivo implementado; verificação automatizada de navegador ficou bloqueada pelo runtime Playwright incompleto | Parcial | Reexecutar em navegador corporativo |
| 29 | Rolagem horizontal | Tabela mantém colunas fixas | Regras CSS implementadas; validação visual automatizada bloqueada pelo runtime Playwright incompleto | Parcial | Reexecutar em navegador corporativo |
| 30 | Teclado e acessibilidade básica | Foco visível, labels, Enter/Espaço em célula | Validado | Aprovado | Não aplicável |

Observação: os testes Microsoft Graph completos precisam ser reexecutados no ambiente corporativo com tenant, permissões, arquivo Excel publicado e biblioteca MSAL aprovados. A validação visual automatizada também deve ser reexecutada em ambiente com Playwright ou navegador manual disponível.
