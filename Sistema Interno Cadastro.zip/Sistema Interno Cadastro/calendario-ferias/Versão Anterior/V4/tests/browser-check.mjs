import assert from "node:assert/strict";

let chromium;
try {
  ({ chromium } = await import("playwright"));
} catch (error) {
  console.log(`Verificação de navegador ignorada: Playwright indisponível (${error.code || error.message}).`);
  process.exit(0);
}

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1366, height: 768 } });
const consoleErrors = [];
const pageErrors = [];

page.on("console", message => {
  if (message.type() === "error") consoleErrors.push(message.text());
});
page.on("pageerror", error => pageErrors.push(error.message));

await page.goto("http://localhost:8080", { waitUntil: "networkidle" });
await page.waitForSelector("#calendarContainer .month-block", { timeout: 10000 });

assert.equal(await page.locator("h1").innerText(), "Calendário de Férias da Equipe");
assert.ok(await page.locator("#localModeNotice").isVisible());
assert.ok(await page.locator("#calendarContainer .calendar-table").count() > 0);
assert.ok(await page.locator("#vacationEmployee option").count() > 0);
assert.deepEqual(pageErrors, []);
assert.deepEqual(consoleErrors, []);

await page.setViewportSize({ width: 1280, height: 720 });
await page.locator("#calendarContainer .table-scroll").first().evaluate(node => {
  node.scrollLeft = 500;
  node.scrollTop = 120;
});
const stickyLeft = await page.locator(".calendar-table .employee-col").first().boundingBox();
assert.ok(stickyLeft.width >= 120);

await browser.close();
console.log("Verificação de navegador passou sem erros de console.");
