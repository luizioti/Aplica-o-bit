import assert from "node:assert/strict";
import {
  APP_END,
  APP_START,
  availableMonthsForYear,
  computeVacationCounts,
  countBusinessDays,
  daysBetweenInclusive,
  daysInMonth,
  isBusinessDay,
  isWeekend,
  uuid
} from "../assets/js/utils.js";
import { validateVacation } from "../assets/js/validation.js";
import { employeeTotals } from "../assets/js/calendar.js";

const employeeId = uuid();
const state = {
  employees: [{ id: employeeId, nome: "Teste", equipe: "Equipe", ativo: true }],
  holidays: [
    { id: uuid(), data: "2026-07-09", descricao: "Feriado teste", tipo: "Feriado", abrangencia: "Municipal", ativo: true },
    { id: uuid(), data: "2026-07-10", descricao: "Ponto teste", tipo: "Ponto facultativo", abrangencia: "Empresa", ativo: true }
  ],
  vacations: [
    { id: "v1", colaboradorId: employeeId, dataInicio: "2026-07-01", dataFim: "2026-07-15", status: "Aprovada" },
    { id: "v2", colaboradorId: employeeId, dataInicio: "2028-12-28", dataFim: "2029-01-03", status: "Planejada" }
  ],
  settings: { limiteAusenciasSimultaneas: 2 }
};

const app = {
  selectedYear: 2026,
  filters: { showCanceled: false, status: "" },
  state
};

assert.equal(APP_START, "2026-06-01");
assert.equal(APP_END, "2028-12-31");
assert.deepEqual(availableMonthsForYear(2026), [5, 6, 7, 8, 9, 10, 11]);
assert.equal(availableMonthsForYear(2028).at(-1), 11);
assert.equal(daysInMonth(2028, 1), 29);
assert.equal(isWeekend("2026-07-04"), true);
assert.equal(isWeekend("2026-07-05"), true);
assert.equal(isBusinessDay("2026-07-09", state.holidays), false);
assert.equal(isBusinessDay("2026-07-10", state.holidays), false);
assert.equal(daysBetweenInclusive("2026-07-01", "2026-07-01"), 1);
assert.equal(daysBetweenInclusive("2026-07-01", "2026-07-15"), 15);
assert.equal(countBusinessDays("2026-07-01", "2026-07-15", state.holidays), 9);
assert.deepEqual(computeVacationCounts({ dataInicio: "2026-07-01", dataFim: "2026-07-15" }, state.holidays), {
  quantidadeDiasCorridos: 15,
  quantidadeDiasUteis: 9
});

assert.ok(validateVacation({ colaboradorId: employeeId, dataInicio: "2026-07-20", dataFim: "2026-07-01", status: "Planejada" }, state).some(message => message.includes("data inicial")));
assert.ok(validateVacation({ colaboradorId: employeeId, dataInicio: "2026-05-30", dataFim: "2026-06-02", status: "Planejada" }, state).some(message => message.includes("data inicial")));
assert.ok(validateVacation({ colaboradorId: employeeId, dataInicio: "2026-07-10", dataFim: "2026-07-20", status: "Planejada" }, state).some(message => message.includes("Sobreposição")));

const julyTotals = employeeTotals(app, employeeId, 2026, 6);
assert.equal(julyTotals.monthCalendarDays, 15);
assert.equal(julyTotals.monthBusinessDays, 9);
assert.equal(julyTotals.yearCalendarDays, 15);
assert.equal(julyTotals.yearPeriods, 1);

app.selectedYear = 2028;
const decemberTotals = employeeTotals(app, employeeId, 2028, 11);
assert.equal(decemberTotals.monthCalendarDays, 4);
assert.equal(decemberTotals.yearCalendarDays, 4);

console.log("Todos os testes automatizados passaram.");
