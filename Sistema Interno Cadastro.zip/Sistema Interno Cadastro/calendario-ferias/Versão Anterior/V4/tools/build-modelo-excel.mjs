import fs from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const workbook = Workbook.create();
const now = "'" + new Date().toISOString();

addTableSheet("Colaboradores", "tbColaboradores", [
  "id",
  "nome",
  "equipe",
  "cargo",
  "email",
  "ativo",
  "dataInclusao",
  "atualizadoEm"
], [[
  "00000000-0000-4000-8000-000000000001",
  "Exemplo Colaborador",
  "Equipe Exemplo",
  "Analista",
  "colaborador@example.com",
  true,
  now,
  now
]]);

addTableSheet("Ferias", "tbFerias", [
  "id",
  "colaboradorId",
  "dataInicio",
  "dataFim",
  "quantidadeDiasCorridos",
  "quantidadeDiasUteis",
  "status",
  "observacao",
  "criadoPor",
  "criadoEm",
  "atualizadoPor",
  "atualizadoEm"
], [[
  "00000000-0000-4000-8000-000000000101",
  "00000000-0000-4000-8000-000000000001",
  "2026-07-01",
  "2026-07-15",
  15,
  11,
  "Planejada",
  "Linha de exemplo; pode ser removida após validação.",
  "modelo",
  now,
  "modelo",
  now
]]);

addTableSheet("Feriados", "tbFeriados", [
  "id",
  "data",
  "descricao",
  "tipo",
  "abrangencia",
  "ativo",
  "criadoEm",
  "atualizadoEm"
], [[
  "00000000-0000-4000-8000-000000000201",
  "2026-09-07",
  "Independência do Brasil",
  "Feriado",
  "Nacional",
  true,
  now,
  now
]]);

addTableSheet("Configuracoes", "tbConfiguracoes", [
  "chave",
  "valor",
  "descricao"
], [
  ["dataInicial", "2026-06-01", "Data inicial permitida pela aplicação"],
  ["dataFinal", "2028-12-31", "Data final permitida pela aplicação"],
  ["limiteAusenciasSimultaneas", "2", "Limite gerencial de colaboradores ausentes no mesmo dia"],
  ["intervaloAtualizacaoSegundos", "60", "Intervalo de atualização automática"],
  ["contarFeriasEmDiasCorridos", "true", "Define a contagem principal de férias"]
]);

addTableSheet("Auditoria", "tbAuditoria", [
  "id",
  "dataHora",
  "usuario",
  "acao",
  "entidade",
  "registroId",
  "detalheAnterior",
  "detalheNovo"
], [[
  "00000000-0000-4000-8000-000000000301",
  now,
  "modelo",
  "CRIAR_MODELO",
  "Sistema",
  "Modelo_Calendario_Ferias.xlsx",
  "",
  "Arquivo modelo criado"
]]);

for (const sheetName of ["Colaboradores", "Ferias", "Feriados", "Configuracoes", "Auditoria"]) {
  await workbook.render({ sheetName, autoCrop: "all", scale: 1, format: "png" });
}

const outputPath = fileURLToPath(new URL("../excel/Modelo_Calendario_Ferias.xlsx", import.meta.url));
await fs.mkdir(new URL("../excel/", import.meta.url), { recursive: true });
const file = await SpreadsheetFile.exportXlsx(workbook);
await file.save(outputPath);
await fs.rm(`${outputPath}.inspect.ndjson`, { force: true });

console.log(`Modelo criado em ${outputPath}`);

function addTableSheet(name, tableName, headers, rows) {
  const sheet = workbook.worksheets.add(name);
  sheet.showGridLines = false;
  const data = [headers, ...rows];
  const range = sheet.getRangeByIndexes(0, 0, data.length, headers.length);
  range.format.numberFormat = "@";
  range.values = data;
  range.format.borders = { preset: "all", style: "thin", color: "#D9E1EA" };
  sheet.getRangeByIndexes(0, 0, 1, headers.length).format = {
    fill: "#005B8F",
    font: { bold: true, color: "#FFFFFF" }
  };
  sheet.getRangeByIndexes(0, 0, data.length, headers.length).format.autofitColumns();
  sheet.freezePanes.freezeRows(1);
  const table = sheet.tables.add(`A1:${columnName(headers.length)}${data.length}`, true, tableName);
  table.style = "TableStyleMedium2";
  table.showFilterButton = true;
}

function columnName(index) {
  let name = "";
  let value = index;
  while (value > 0) {
    const modulo = (value - 1) % 26;
    name = String.fromCharCode(65 + modulo) + name;
    value = Math.floor((value - modulo) / 26);
  }
  return name;
}
