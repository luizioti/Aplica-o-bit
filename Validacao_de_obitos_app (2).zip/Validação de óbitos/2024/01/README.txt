Coloque aqui a base corporativa deste mês (XLSX, XLS ou CSV).
O BI tentará ler este arquivo automaticamente quando o ano/mês for selecionado.
