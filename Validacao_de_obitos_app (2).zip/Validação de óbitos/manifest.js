// Manifesto: registre aqui o nome do arquivo de base de cada ano/mes.
// Ex.: "2026": { "06": "30062026 - Sem I-Petros.xlsx", "07": "arquivo_julho.xlsx" }
window.OBITOS_MANIFEST = {
  "2026": {
    "06": "30062026 - Sem I-Petros.xlsx"
  }
};
